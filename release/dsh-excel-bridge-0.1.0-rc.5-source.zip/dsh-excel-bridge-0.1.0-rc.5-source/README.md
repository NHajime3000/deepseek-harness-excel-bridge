# DSH Excel Bridge

面向 DeepSeek Harness 的本地 Excel 工作流插件：大型 XLSX 语义检索、安全写回、持久 Outbox，以及可选的历史 Recipe 复用和 Word/Markdown SOP 分步执行。当前为 **0.1.0-rc.5 发布候选版本**，不是通用 Office 自动化平台或分布式事务系统。复杂 SOP 自动编译仍为实验功能，默认关闭；不能把通过 Plan schema 校验等同于业务规则正确。

## 功能状态

- Stable / Tested：Large Excel Query、Large Excel Patch、WeKnora RAG、Incremental Sync、Outbox Recovery、Safe Write-back。RC3 基线 95 项已冻结；RC4 对批量写入增加独立管理员审批。
- Experimental：Recipe reuse、Procedure、Word SOP Compiler、Automatic Recipe Routing。具体模型与自然语言的可靠性以本版本验收报告为准，不承诺任意 SOP 自动编译成功。

## 为什么不把整表交给模型

Excel 是事实源。Python 建立 SQLite 定位库，WeKnora 只召回语义候选；模型只接收少量结果与摘要。计算、写入、检查点和失败恢复不依赖聊天历史。

```text
DSH / 小模型
  └─ excel_index / excel_query / excel_patch / 可选 procedure_run
       └─ Node Cordis → UTF-8 JSON → Python Bridge
            ├─ SQLite：定位、Recipe、Plan、检查点、Outbox
            ├─ WeKnora：每文件独立 FAQ 语义索引
            └─ 原 XLSX：备份 → 安全写入 → Outbox 最终同步
```

## 安装

需要 Node.js 20.11+、Python 3.11+、DSH、WeKnora FAQ 服务及 Embedding 模型。本轮核对的 DSH 为 0.1.1-rc.2，使用正式 dsh.bundle.patch 与 dsh.client contract，无自动 postinstall 脚本。

```powershell
# 安装 checkout；pnpm 可能建立目录 link
dsh plugin --profile web add ./dsh-excel-bridge

# 或在源码根目录打包，安装独立 tarball
npm pack --ignore-scripts
dsh plugin --profile web add ./dsh-excel-bridge-0.1.0-rc.5.tgz --ignore-scripts
```

未填入不存在的 GitHub 地址，也未宣称已提交 dsh.pub。拥有远程仓库后可用 DSH 支持的 github:<owner>/<repo> 形式安装。

### Python 依赖

在 checkout 或解包目录使用已有解释器执行：

```powershell
python -m pip install -r requirements.txt
```

或者审阅辅助脚本后创建独立环境：

```powershell
./scripts/setup-python.ps1
./scripts/setup-python.ps1 -Python python -Install
```

不带 -Install 只说明操作。带参数会创建新的 .venv 并从配置的 pip 索引下载 openpyxl、python-docx，不修改系统 Python；目标已存在时拒绝覆盖。macOS/Linux 可使用 python3 -m venv .venv，再用 .venv/bin/python 安装依赖。推荐把虚拟环境放在用户管理的稳定目录，升级插件时无需重建。

## WeKnora 前置条件

管理员配置一个租户/API Key 和可用 Embedding 模型。自动 FAQ 建库需要 manage_kbs，写入和查询需要 ingest / retrieve；KB allow-list 不能只限定一个旧库。日常操作不会创建租户或更改模型。

不填 knowledgeBaseId 时一文件自动绑定一个 KB；填入旧 KB ID 保留兼容模式。不上传整表给 DocReader，不以 Summary/Ask 为核心链路。

## 插件配置

进入 **DSH 设置 → 插件 → Excel Bridge**，填写 Python executable、工作区绝对路径及私有连接文件。其他空白项继承连接文件；禁用后注销本插件全部工具。

```json
{
  "baseUrl": "http://localhost:8080/api/v1",
  "apiKey": "<your-private-key>",
  "tenantId": "<your-tenant>",
  "embeddingModelId": "<your-embedding-model-id>",
  "autoCreateKb": true,
  "autoIndexOnQuery": true,
  "defaultQueryLimit": 5,
  "batchSize": 200,
  "recipeEnabled": false,
  "procedureEnabled": false
}
```

工作区下 .excel_bridge/index.db 保存定位、Outbox、Recipe 和 Procedure。不同租户使用不同工作区，不能把旧任务改投新库。API Key 输入为 password；本地配置不是加密保险库，需用户专用文件权限，不要粘贴到聊天或提交 Git。

| 设置 | 用途 |
| --- | --- |
| pythonPath / workspaceRoot / connectionFile | 解释器、SQLite/备份根目录、私有连接 |
| baseUrl / apiKey / tenantId / embeddingModelId | WeKnora 服务与一次性管理员配置 |
| autoCreateKb / autoIndexOnQuery | 自动文件 KB 与查询索引 |
| defaultQueryLimit / batchSize | 默认返回 5 条，最多 20；远端批量默认 200，范围 100–500 |
| outboxMaxAttempts / outboxImmediateSeconds | 失败尝试上限、调用内同步预算 |
| recoveryEnabled / recoveryIntervalSeconds | 可选后台有界恢复，默认关闭 |
| recipeEnabled / procedureEnabled | 模板记忆与统一工作流工具，默认关闭 |
| previewThreshold | 默认达到 20 行的批量写入要求管理员审批；所有 Procedure 始终审批 |
| procedureMaxRecords / procedureStepsPerCall | 默认最多 100000 条输入，每次最多推进 8 步 |
| compilerBaseUrl / compilerModel / compilerApiKey | SOP 编译的 OpenAI-compatible 服务，独立于 WeKnora |
| compilerProvider | current_dsh_model / openai_compatible / local_openai_compatible_endpoint / disabled / manual_review |

## 使用示例

### 普通查询和 Patch

“帮我找这个 Excel 中像圣诞装饰品的商品，最多两条。”

“把这两条的 ReviewStatus 标记为待评估。”

“再找出 ReviewStatus 已经是待评估的商品。”

语义搜索用 query；精确列值用 filters 和空 query。新小表自动建 KB/索引。大表首次或变化时超过 1000 行、2 MB 压缩/8 MB 解压门槛则返回 indexing_required，继续调用原 excel_index，避免 60 秒查询超时。

### 历史 Recipe

启用 Recipe 后，成功的“语义查找 → 对返回记录统一标记状态”可生成 draft。

“这个新表按照上次物流投诉的处理方式处理，先让我看预览。”

模型只传 instruction 和 files。后端最多检索三个方案，以意图相似度和字段覆盖度排序，第一名至少 0.7 且与第二名相差至少 0.1 才继续。角色优先使用当前 schema 的已确认映射，其次使用唯一精确别名。旧文件行号、record_id、KB 不属于模板。无历史命中、低置信度、歧义或缺字段均停止，不自动猜测。没有引用历史的新任务可尝试生成一次性草稿，但仍要经过完整编译、校验和审批。

### Word SOP

启用 Procedure 并配置编译模型端点：

“按照这个 Word 的流程处理这个 Excel，先给出预览。”

工具输入示例：`{"instruction":"按照 SOP 处理销售表","files":["销售表.xlsx","处理规范.docx"]}`。禁止传入 recipe_id、run_id、映射、Plan JSON 或 confirm。

编译顺序为文档分块、规则抽取、精确去重与依赖检查、逐规则 Plan 组装、规则覆盖交叉检查、严格 Plan Validator。每次只新增一个块或一条规则的编译结果；完整规则及来源段落保存在 SQLite。组装阶段不重读全文。`compiling/running/syncing` 时提交完全相同的 instruction 和 files，由可信 DSH 会话标识关联进度。改动任务说明或 SOP 将使未完成任务的审批失效，需新会话重新预览。

current_dsh_model 从可信 DSH Agent 与 llm-pi-ai 设置中解析当前 OpenAI-completions 模型；无法解析时停止，请显式配置独立端点。插件不修改用户默认模型，不下载模型。local_openai_compatible_endpoint 仅允许回环地址；远程端点使用 openai_compatible。disabled/manual_review 不发送 SOP 编译请求。

### 管理员审批

所有 Procedure，以及达到阈值或跨 Sheet 的直接 patch，必须批准冻结的 plan_hash。`confirm=true` 无法批准。审批绑定 Plan、角色映射、源文件版本及冻结行/操作；修改后旧审批失效。审批与进度保存在 SQLite，重启不会丢失。

从安装了本包的 Python 环境或源码根目录运行：

```powershell
'{}' | python -m excel_bridge.workflow_cli approvals --workspace '<插件配置的工作区>'
# 核对返回的 preview，再复制该条记录的真实 approval_id 与 plan_hash：
'{"approval_id":"<列表中的审批编号>","plan_hash":"<对应哈希>"}' | python -m excel_bridge.workflow_cli approve --workspace '<同一工作区>'
```

批准后让 Agent 以原任务说明和文件继续。批量 patch 批准后重复相同 patch 参数。审批命令不是 DSH Tool，四工具预设不能调用它。OS 管理员、任意 shell 执行与直接 SQLite 写权限属于可信边界，本机制不是同账户任意代码的安全沙箱。中断且无法证明完成的批量直接 patch 会要求对账，不盲目重复数值操作。

建议 Agent 短规则：

> 普通 XLSX 查询/修改优先 Excel Bridge；按历史方法或 SOP 处理用 procedure_run，先展示预览，只有用户明确确认后再执行。不要整表读取。

## 备份与 Outbox 安全

写回先备份，再保存同目录临时 XLSX 并替换。SQLite intent 与 Outbox 保留未完成动作；恢复先核验源文件和版本，不盲目重复 POST 或算术 patch。新 Procedure 始终先生成冻结预览，模型参数不具备授权能力。

多步骤写入、数值/金额修改、大批量和跨 Sheet 会标记风险。运行中源文件变化或身份不唯一会停止；此前已完成步骤不会自动回滚。后台恢复只处理 Outbox，不自动批准 Procedure。

详见 [使用指南](docs/user-guide.md) 和 [Plan IR](docs/plan-ir.md)。workspace-delete 是明确的破坏性维护操作；源文件缺失只标 orphaned，不自动删远端 KB。

## 隐私和当前限制

小模型建议单独选择 [精简 Excel Agent 预设](docs/compact-agent.cordis.yml)：将其复制为 `DSH_HOME/.agent-presets/excel-bridge/agent.cordis.yml`，在 DSH 中手动选择该预设。它不修改默认模型，也不自动替换既有 Agent。DSH 全量工具集可能超过 8K；四个 Bridge 工具较小，不代表整个默认 Agent 都适合 8K。

- 全行数据、运行快照存在本机 SQLite；语义文本发送到配置的 WeKnora，SOP 块发送到配置的编译模型。选择远端服务前确认隐私要求。
- 无 shell、eval 或任意代码步骤。Procedure 不支持删除行/列、新增列、宏、公式计算或保证复杂 Excel 对象无损。
- 每 run 一个 XLSX，最多 64 步；不一致多 Sheet schema 需先整理。数据留在 Python/SQLite，不进入 LLM Context。
- 语义步骤最多 top-50 候选，不保证全表召回。Procedure 还会通过配置的编译模型按每批最多 8 段字段文本复核候选；无法复核则不写入。普通 excel_query 保持原有召回接口。计划 schema 合法不等于业务语义正确，用户须检查预览。
- SOP 分段预算、未解析指代和不确定规则可能要求人工审阅；小模型成功样本不代表所有表达都稳定正确。
- 本机文件锁不是多主机分布式锁。外部 Excel 占用、磁盘/权限错误、未知远端提交可能需要人工介入。
- 备份、执行记录和草稿不自动清理，需要规划保留空间。本版没有 marketplace 审核或生产级安全认证。

## 测试和卸载

源码 checkout 安装依赖后运行 npm test，包含 Node/Python、身份、中文、Outbox、Workspace、Recipe 与 Procedure。真实集成脚本仅用于明确准备的测试文件，勿直接对业务表执行。

```powershell
dsh plugin --profile web remove dsh-excel-bridge
```

卸载不自动删除 Excel、备份、SQLite、Recipe 或远端 KB。先备份数据，再明确处理不需要的工作区。MIT License。
