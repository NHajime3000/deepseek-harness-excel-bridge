<!-- Public export: operator-local paths redacted; original evidence stays outside this release. -->
# Excel Bridge MVP：实施、验证与方法论报告

日期：2026-09-05。项目：`<operator-local-path>`。本报告区分真实服务结果、模拟测试、故障复盘和未验收边界。

2026-09-06 更新：已增加持久 Outbox、跨进程恢复和有限对账。最新实现、测试数量及恢复边界请见 [Outbox 交付报告](outbox-recovery-report.md)。下文保留 9 月 5 日 MVP 的历史证据，其中“尚无 Outbox”等状态不再代表当前版本。

## 1. 结论与证据范围

轻量级 Excel Bridge 的核心 MVP 已实现。真实 WeKnora、SQLite、50,000 行 XLSX 的直接工具链路通过；DSH 本地 Qwen 4B 的精确状态调用和更新 schema 后的全新中文语义会话通过。扩展语义会话的早期失败另行保留，不把有限样本成功当作所有模型行为均已稳定。

- 只有 `excel_index`、`excel_query`、`excel_patch` 三个新增工具；没有替换 Home、ToolDoc、dafeiyu 或默认模型配置。
- 实表最终验收：425 行价格批量修改，独立检查 50,000 行，误改 0 行；随后强制重扫新增/更新/删除均为 0，远端 FAQ 仍为 50,000 条。
- 原始 `<operator-local-path>` 未修改。验收在项目内副本完成。
- 最新完整回归：Node 3/3、Python 19/19，共 22 项通过。Python 总耗时 65.239 秒，其中 50,000 行模拟服务索引 46.488 秒。模拟服务时间不能替代真实向量化时间。
- DSH 实际使用原有 Local LLM Controller 启动 Qwen 4B，执行了中文精确状态查询；自然语言后续问题也正确选择了空 query + filters。
- 加载严格短 schema 后，全新 DSH 会话中文语义查询返回 2 条记录：1 个工具调用、2 个模型步骤，模型耗时 13.023 秒、工具耗时 1.226 秒，上下文压力 3,809/8,192 tokens。
- 页面视觉/点击验收未完成：当时 Browser 技能要求的受支持通道缺失对应版本的浏览器服务组件。正式会话 API 验收不能冒充 UI 视觉验收。

主要本地证据（路径相对项目根目录；文件均不含本报告刻意省略的 API Key）：

| 证据 | 路径 |
| --- | --- |
| 初次真实 50,000 行索引结果 | `.real_validation/live-chain-20260904165027/validation-report.json` |
| 修复后完整实表复验 | `.real_validation/live-chain-20260904165027/final-validation-report.json` |
| DSH 模型调用、工具结果与上下文统计 | `.real_validation/live-chain-20260904165027/dsh-agent-validation.json` |
| 重启后语义会话回归 | `.real_validation/live-chain-20260904165027/dsh-semantic-validation.json` |
| 模型虚构列名的失败记录 | `.real_validation/live-chain-20260904165027/dsh-semantic-validation.failed-attempt.json` |
| 阈值对照实验 | `.real_validation/live-chain-20260904165027/search-threshold-probe.json` |
| 浮点问题的失败记录 | `.real_validation/live-chain-20260904165027/float-roundtrip-failure.json` |
| 失败后恢复测试价格的记录 | `.real_validation/live-chain-20260904165027/float-recovery.json` |
| 无主键重建阶段内存测量 | `.real_validation/identity-memory-benchmark.json` |

初次报告中的中文工具返回曾受跨进程编码影响，不能单独作为中文返回正确性的证据；以修复后的最终报告及 Node 往返测试为准。初次索引耗时沿用原始证据，未为了报告重新执行 42 分钟的全量向量化。

## 2. 技术选型与职责分离

| 组件 | 选型 | 职责与理由 |
| --- | --- | --- |
| DSH 入口 | JavaScript ESM + Cordis bundle patch | 遵循现有插件注册方式，提供短 schema，启动 Python 子进程 |
| Excel 索引 | Python + openpyxl `read_only=True` | 逐工作表逐行迭代，不用 pandas，不把整表变成 JSON 工具返回 |
| 定位与精确数据 | Python 标准库 sqlite3，WAL、临时表、索引 | 保存完整行及定位信息，执行去重、身份匹配和差异计算 |
| 语义召回 | WeKnora FAQ 批量导入与 FAQ search | 每行一条语义记录，绕开 WeKnora 整表解析与 Ask/Summary |
| Embedding | llama.cpp + Qwen3-Embedding-0.6B GGUF | 独立 55556 端口；容器通过 `host.docker.internal` 访问宿主模型 |
| 意图与工具调用 | 现有 Local LLM Controller + Qwen3 4B GGUF | 55555 端口；模型只选择工具与条件，不逐行处理 50,000 条数据 |
| 安全写回 | openpyxl 普通模式、备份、同目录临时文件、`os.replace` | 一次加载，一次保存，短时 Windows 文件占用重试，保留恢复入口 |

调用关系：DSH 模型 → 三个短工具 → UTF-8 JSON 子进程协议 → Python；语义候选走 WeKnora，精确条件和数据回填走 SQLite，最终写入只发生在 Excel。

Embedding 与生成模型不是同一项依赖。WeKnora 的 FAQ 索引/检索需要前者；DSH 自主调用工具需要后者。已分别启动并核对，未把原有默认生成模型改成 Embedding 模型。

## 3. 文件与接口

关键实现文件：

- `src/index.js`：配置合并、连接文件、三个工具 schema、UTF-8 子进程与输出上限。
- `excel_bridge/config.py`、`service.py`、`cli.py`：配置、参数校验、工具分发和 JSON 协议。
- `storage.py`、`indexer.py`：定位库、流式暂存、业务键发现/保持、SQL 身份映射、增量同步。
- `query.py`、`utils.py`：语义命中回填、精确筛选、字段裁剪、数值/指纹规范化。
- `patcher.py`：唯一定位、预览、批量修改、备份与替换、局部 RAG 同步。
- `weknora_client.py`：FAQ 批量接口、进度轮询、删除、召回和返回 ID 绑定。
- `scripts/`：测试入口、真实验收、故障恢复、模型会话验证、服务恢复与登录任务安装。
- `tests/test_bridge.py`、`tests/test_regressions.py`、`tests/node_plugin.test.mjs`：主流程与边界回归。

工具参数摘要（完整 JSON schema 以 `src/index.js` 为准）：

| 工具 | 参数 |
| --- | --- |
| `excel_index` | `file` 必填；`force_reindex` 可选 |
| `excel_query` | `file`、`query` 必填；`filters`、`limit` 可选；默认 5，最多 20 |
| `excel_patch` | `file` 必填；`operations[]` 或 `selector + operation`；可选 `dry_run` |

精确操作字段：`record_id`、`column`、`operation`、`value`。批量 operation 使用 `column`、`type`、`value`。操作类型为 `set`、`numeric_add`、`numeric_multiply`、`append_column`。

filters 支持 `eq/ne/lt/lte/gt/gte/between/in/contains`。语义描述放 query；状态、国家、价格等确定条件放 filters。只有精确条件时 query 传空字符串，而不是把“找出待评估”全部交给向量检索。

返回值最多 12,000 字符，query 最多 20 条，每条至多 8 个展示字段（定位键单独返回），长字符串裁剪。实测中文语义查询 5 条结果共 1,661 字符。字符数不等于 token 数，不能用它宣称固定 token 上限。

## 4. SQLite 定位模型与稳定身份

`files` 表：`file_id`、`file_path`、`file_name`、`file_size`、`modified_time_ns`、`indexed_at`、`status`、`primary_key_json`。

`records` 表：`record_id`、`file_id`、`sheet`、`row_hint`、`record_key_json`、`record_key_hash`、`fingerprint`、`data_json`、`content`、`weknora_document_id`、`weknora_chunk_id`、`weknora_entry_id`、`rag_status`、`rag_error`、`updated_at`。

建立 file、file+sheet、fingerprint、file+sheet+fingerprint、业务键哈希、远端 entry_id 索引。完整 DDL 见 `storage.py`。FAQ 批量进度提供 seq_id 和 knowledge_id；chunk_id 字段允许为空，不假装 API 返回了它。

身份规则：

1. 首次检查候选业务字段的非空性和唯一性，可组合最多 4 个字段；候选总数最多 8 个。
2. 业务键一旦建立，后续重扫保持它，不因删行后更短字段恰好唯一而改换身份规则。原键缺失、重复或变空则拒绝静默重映射。
3. 无业务键时，身份基于规范化行指纹及重复出现序号。旧指纹与新指纹通过 SQLite 窗口函数排名并关联，复用已有 record_id。
4. Bridge 自己的 patch 保持 record_id，更新对应指纹；旧内容再次出现时，不允许新行抢占已修改行的 ID。
5. 行号只是提示，不能证明身份。无键记录被外部改变内容时不能可靠知道“是否还是同一条”，按旧记录删除、新记录加入处理，而不猜旧行号。
6. 写回时键或指纹必须唯一；重复键、重复指纹和跨文件 record_id 均拒绝。selector 也检查筛选范围以外的重复键。

## 5. 为什么每 1,000 行写 SQLite，是否属于流式？

当前流程本身是“边读边存”：读取一行、规范化一行，最多暂存 1,000 行，用 `executemany` 写入 SQLite 临时表，再清空缓冲继续读取。不是把 50,000 行读完后才保存。

这里要区分三个概念：

- **读取粒度**：逐行，来自 openpyxl 的只读迭代器。
- **提交给 SQLite 的粒度**：固定上限的 1,000 行，减少 Python/SQLite 调用次数；可改逐行 `execute`，但不改变总体身份匹配和一致性设计。
- **持久化事务边界**：正式定位库在完整流程成功后切换；每读一行就 COMMIT 并不是当前方案，也不等于“更流式”。

临时表让全局键唯一性、重复指纹、删除检测在 SQLite 中完成。每行立即持久 COMMIT 会增加事务开销，并把半成品索引暴露给查询；真正的可断点续传需要持久 staging、任务状态和恢复协议，不能只把 1,000 改成 1。

WeKnora 批量大小是另一个参数：允许 100–500，默认 200。它用于减少 HTTP/导入任务开销，与 SQLite 的 1,000 行缓冲不是一个概念。

内存验证专门测量“已有定位库的无键重建身份阶段”：10,000 行 Python 分配峰值 571,614 字节；50,000 行 473,503 字节，所有 ID 保持。数据量 5 倍没有造成 Python 全表字典增长。这不是整进程峰值：不含 SQLite 原生内存、XLSX 共享字符串/样式，也不代表普通模式 patch 恒定内存。

## 6. 实际 WeKnora API 与检索经验

| 用途 | 已验证接口 |
| --- | --- |
| FAQ 知识库检查 | `GET /api/v1/knowledge-bases/{kb}` |
| 批量导入 | `POST /api/v1/knowledge-bases/{kb}/faq/entries` |
| 异步导入状态 | `GET /api/v1/faq/import/progress/{task_id}` |
| 删除旧条目 | `DELETE /api/v1/knowledge-bases/{kb}/faq/entries`，body 为 ids |
| 语义候选 | `POST /api/v1/knowledge-bases/{kb}/faq/search` |
| 独立条目计数 | `GET /api/v1/knowledge-bases/{kb}/faq/entries?page=1&page_size=1` |

行文本仅保留 Description、Country、ReviewStatus 等有语义价值的字段，完整数据留在 SQLite。FAQ question 需要唯一，因此附带稳定的短 `_rid` 后缀；answers 保存完整 `record_id=rec_...`。导入结果通过输入 index 和 seq_id 绑定本地记录，查询支持答案 record_id 和 entry_id 回填。

调试时两个反例尤其重要：

- 新建租户 API Key 的返回 `.token` 才是可用明文；`.api_key` 可能是加密存储值。不能看到“有值”就当成可用凭证。
- 本地 WeKnora 源码的 `knowledge_faq.go` 明确把 `VectorThreshold <= 0` 改成 0.7，且 `MatchCount > 50` 改成 50。不能只读 HTTP handler 的 200 上限，也不能假定传 0 是关闭阈值。

真实阈值对照：中文圣诞查询在 0（实际默认 0.7）下返回 44 个候选，0.3 下返回 50；特定中文状态查询在前者返回 0，在后者返回的前 50 仍没有目标。降低阈值解决不了结构化筛选，且会增加不相关结果。FAQ 这个路径关闭关键词匹配，不能声称它已做了关键词+向量混合召回。

因此采用：语义 top-50 → SQLite 精确过滤 → 返回少量记录；纯状态条件直接 SQLite。语义候选经过过滤为空不代表全表不存在；工具对此给出提示。当前没有穷尽分页或服务端逐字段过滤，不保证混合查询全召回。

## 7. 真实 50,000 行测试结果

初次全量向量化耗时 **2,562.043 秒，约 42 分 42 秒**。以下是修复后在已有索引上的完整复验，不是另一轮全量向量化：

| 验收项 | 结果 | 实测耗时 |
| --- | --- | --- |
| B 中文“圣诞装饰品”语义查询 | 5 条相关商品，1,661 字符 | 1.080 秒 |
| C 单行中文状态 patch | 修改 1，重索引 1，失败 0 | 22.456 秒 |
| D 精确状态复查 | 找到同一 record_id | 3.307 秒 |
| D 语义描述 + 状态 filters | 找到同一 record_id | 1.554 秒 |
| E 插入 3 个空行后数量 +1 | 同一 record_id 定位到 row_hint+3 | 21.498 秒 |
| F France 且 Price<5 预览 | 425 行，工作簿哈希不变 | 25.987 秒 |
| G 批量 Price×1.1 | 修改 425，重索引 425，失败 0 | 69.590 秒 |
| 独立工作簿对照 | 检查 50,000 行，仅预期 425 行价格变化 | 单独校验，不混入工具耗时 |
| H 强制差异复查 | 新增 0、更新 0、删除 0、未变化 50,000 | 40.046 秒 |
| 远端独立计数 | 50,000 个 FAQ 条目 | 校验通过 |

原文件 SHA-256 前后相同：`DBA380ECC779288DE64F23B32A563399490D46C63A566B3333B37900BD29622C`。

测试副本包含多轮测试的状态/数量修改及两次插入空行，不应当作原始业务数据。第一次失败的批量价格已恢复，然后重新执行最终批量测试；没有将业务原件作为恢复目标。

## 8. 故障复盘：为什么必须闭环验证

### 中文跨进程损坏

Excel 和 SQLite 的中文正确，不代表工具返回正确。Python 默认控制台编码与 Node 的 UTF-8 解码不一致，会将已正确保存的中文变成替换字符。修复为子进程环境与 CLI 输出显式 UTF-8，并在测试中刻意把父环境设为 GBK，再验证文件名、工作表、状态和返回值。

### 浮点保存后指纹漂移

真实批量测试一开始修改了正确的 425 行，但强制重扫产生 30 条新增和 30 条删除。openpyxl 的数值写出采用 `%.16g`；Python 内存乘法结果可能多出尾数。缓存指纹与文件重新打开后的值不一致，导致无键记录身份漂移。

修复：数值结果及 JSON/指纹规范化对齐 XLSX 写出精度，并统一整数化的等价值；增加 `2.95×1.1` 等实际回归。修复后的真实复验达到 0 差异。失败测试中已重建的 30 个临时测试 ID 不追溯宣称被保留；证据保留在失败报告中。

### 错误同步状态被“文件未变化”掩盖

patch 后 Excel 已保存、远端暂时不可用时返回 partial，并保存 `rag_status=error`。旧的快速跳过逻辑只看 mtime/size，会让重试永远跳过。现在 `excel_index` 同时检查未同步状态，修复 error/local_only 记录，已覆盖远端失联后重试及后启用 WeKnora 的测试。

### Windows 短时文件占用

完整回归曾在临时中文文件的 `os.replace` 遇到一次访问拒绝，单测重跑通过；无法据此确定是哪个进程占用。现仅对 PermissionError 做最多 4 次短时尝试，总等待约 0.9 秒，每次重新检查源文件是否变化。长期 Excel 锁仍然失败，不能以重试绕过并发修改保护。

### 小模型参数错误不能伪装成空数据

追加的重启后语义会话暴露两个模型行为：把 `contains` 写成数组，以及虚构不存在的 `category`、`product_name` 列。原有宽松处理把错误条件当成“无匹配”，模型随后误判索引为空；第一条会话的第三轮耗尽 token，另一条新会话也没有找到真实存在的商品。原始失败事件保留。

补救：短 schema 明确 contains 为字符串、in 为数组；Python 在检索前验证参数类型和实际列名。未知列直接报错，并返回最多 40 个真实列名和“纯语义查询不传 filters”的提示。新增列名与类型回归，同时加强验收采集器：必须检查最新一轮正常结束且存在非空查询结果，不能因为历史轮次成功就把最新失败标成 passed。重新运行模型会话的结果以对应语义验证 JSON 为准。

运行中的 DSH 必须重启才能加载新的 JavaScript 工具描述/schema，仅修改 Python 后端并不能更新模型看到的约束。重启并创建全新会话后，中文原始意图通过；最终会话为 `session-19c60d79-58b5-4e78-bee2-f70621f322ae`。三个工具的 name+description+parameters JSON 总计 2,488 字符，仍保持短接口。早期会话的失败没有从历史证据中抹掉。

## 9. 部署、恢复与 DSH 上下文

保留原 DSH Home：`<operator-local-path>`；原 agent 工作目录仍为 `<operator-local-path>`。只在 web profile 的 `excel-bridge` 行配置连接文件、Python 和本次验证 locator workspace。插件为 link 本项目的 Cordis bundle。

测试使用独立 tenant 10004、独立 FAQ KB `147438f5-df70-4fc1-8f43-5a9da6c22278`；Key 仅授权本 KB 的 retrieve/ingest，不使用原业务 KB。早期失败实验留下的独立测试资源未冒充正式数据，也没有删除原有知识库。

恢复入口 `scripts/start-local-stack.ps1`：健康检查、Docker/Embedding 启动、日志和互斥启动文件；`-StartHarness` 可启动原 web profile。登录任务名为 `DSH Excel Bridge - Local Embedding`，限定当前用户 Interactive/非提权级别，不自动启动生成 LLM。

初次登录任务退出 1 的原因是 Windows PowerShell 默认 Restricted 拒绝运行脚本。已改为任务进程自身的 `RemoteSigned`，不修改系统/用户持久策略；2026-09-05 18:43 的试运行最终 `LastTaskResult=0`。实际重启后，8080、55556、55555 和 3080 四个服务均已核对 HTTP 200。完整电脑重启后的自动登录触发尚未再做一次验收，不能把手动 Run 的成功等同于整机重启验收。

DSH 会话为 `session-310b71ab-fc3b-4380-84f8-b2d3a4348823`，模型保持原 Qwen3 4B。前两轮调用共 4 个模型步骤，调用了精确状态工具，没有把整表送入 LLM；第二轮上下文压力报告 3,832 tokens，窗口 8,192。DSH 工具区统计 2,348 tokens 是当时全部启用工具的统计，不能误写成 Bridge 独占开销。实际工具/模型事件见 DSH 验证 JSON。

API Key 未写入代码、报告或打包清单，连接文件位于忽略目录。当前仍是本地明文文件；收紧 ACL 的尝试未成功（一次授予沙箱的方案被安全审查拒绝，改为仅当前用户/系统/管理员后又被文件权限拒绝），没有通过取所有权或扩大权限绕过。生产部署前需由文件所有者完成用户专用 ACL 或接入凭证管理。

## 10. 可复用的方法论

1. **先分清事实源与派生索引。** Excel 是事实，SQLite 是可验证定位/精确数据，WeKnora 是召回候选；模型不是数据处理引擎。
2. **把流式、批量和事务分开讨论。** 分别测内存、SQLite 开销和远端吞吐，不用“每行提交”替代一致性设计。
3. **检索质量用反例检验。** 中文、混合语言、状态变更、重复商品描述都必须出现；不能只测试精确英文标题。
4. **阅读服务层，不只看入口 schema。** 实际默认值、上限、去重、异步完成和凭证字段含义均以真实响应及实现交叉验证。
5. **身份永远比行号优先。** 移行、插行、删行、重复键和无键外部编辑都要有明确行为；宁可拒绝歧义，也不自动猜测写入。
6. **保存之后重新打开再比对。** 预览正确、内存数据正确和 Excel 落盘正确是三次不同的检查；最后再重建差异应为零。
7. **验收必须穿过语言边界。** Python 单测不能证明 Node 插件无乱码；直接调用插件不能证明模型会选工具；模型 API 不能证明 UI。
8. **失败证据保留，成功指标不拼接。** 全量索引、增量复验和模拟服务耗时标明来源；记录失败的 30 条漂移，不回填伪造历史成功。
9. **恢复能力是功能的一部分。** 同时检查错误状态重试、配置持久化、进程恢复和计划任务退出码，不能以“服务启动过一次”交付。
10. **限定权限与数据副作用。** 独立测试库、独立副本、最小 Key 权限、备份和明确清理范围；权限受阻不以关闭安全机制解决。

## 11. MVP 边界与下一步

- 支持 `.xlsx`；不支持 `.xls`、宏、公式计算、保证高级 Excel 对象完全无损。patch 使用普通 openpyxl 模式，仍需整本工作簿内存。
- SQLite+Excel+WeKnora 不是分布式事务。中途崩溃或远端批次部分成功可能需要对账；当前没有持久 outbox、导入任务断点恢复或远端全量幂等清扫。
- 无键且外部修改内容无法无歧义保持原身份；重复指纹拒绝写回。文件路径或工作表名变化也需要显式迁移/重建。
- 同一个文件的多进程并发写入不属于已支持模式。保存前后 stat 检查缩小风险，但不提供跨编辑器的严格排他锁。
- `.xlsx` 共享字符串、样式等元数据仍可能线性增长；本次内存测量只证明身份关联阶段消除了 Python 全表字典。
- 语义 top-50 + filters 不保证完整召回；精确条件应单独查询或 selector 批量处理。
- UI 视觉验收、整机重启后的登录触发实测、凭证文件 ACL 加固仍需补充。它们未被标为已完成。

推荐的后续工程重点：持久同步任务/outbox与对账 → 跨进程写锁与冲突报告 → 更大工作簿内存测试 → UI 验收与凭证部署加固。不要在这些边界尚未补齐时把 MVP 宣称为生产级事务系统。
