<!-- Public export: operator-local paths redacted; original evidence stays outside this release. -->
# Excel Bridge 持久 Outbox、失败恢复与对账报告

实施日期：2026-09-06；最终回归复核：2026-09-07。此报告补充原 MVP 报告，取代其中“无持久 Outbox / 进程中断不能续传”的限制描述。

## 1. 交付范围

已实现可运行的 Python + SQLite Outbox。Excel 是事实源；SQLite 保存定位、版本和恢复动作；WeKnora 是派生索引。没有分布式事务，也没有引入 Redis、Celery、Kafka 等 Bridge 依赖。WeKnora 原有 Redis 不属于本次新增组件。

DSH 仍只有 `excel_index`、`excel_query`、`excel_patch`。三者名称、说明和参数 schema 共 **2,488 个字符**，本次未增加 Tool Schema。Local LLM Controller、ToolDoc、DSH 原模型配置未修改。

## 2. 新增及修改文件

新增生产模块：

- `excel_bridge/outbox.py`：幂等入队、任务领取、批量执行、异步续查、状态统计。
- `excel_bridge/reconcile.py`：保存前 intent、实际 XLSX 核验、本地及有限远端对账。
- `excel_bridge/locking.py`：跨本机进程文件锁，串行化写文件和 Worker。
- `excel_bridge/faults.py`：仅测试启用的进程终止检查点。
- `excel_bridge/maintenance.py`：内部维护 CLI，不注册到 DSH。

新增验证文件：`tests/test_outbox.py`、`scripts/live-outbox-validation.py`、`scripts/verify-outbox-migration.py`、本报告。

修改：`storage.py`、`config.py`、`indexer.py`、`patcher.py`、`service.py`、`weknora_client.py`、`utils.py`、`tests/mock_weknora.py`、`tests/test_regressions.py`、`scripts/start-local-stack.ps1`、`README.md`，以及原 MVP 报告的新版提示。

原回归中模拟旧 `replace_records` 的故障注入改到实际 Worker 的远端预检入口，并显式推进测试重试时间；没有取消“失败后恢复”的断言。

## 3. SQLite schema 与迁移

`PRAGMA user_version` 从 0 升至 1。幂等 `CREATE TABLE/INDEX IF NOT EXISTS`，保留已有 `files`、`records` 原行、主键、远端绑定。连接使用 WAL、`synchronous=FULL`、60 秒 SQLite 等待超时。

| 表 | 内容 |
| --- | --- |
| `outbox_tasks` | `id`、`task_type`、`record_id`、`file_id`、`sheet`、唯一 `operation_key`、`payload_json`、`status`、`attempt_count`、`max_attempts`、`next_retry_at`、`last_error`、`error_category`、`remote_task_id`、`remote_entry_id`、`created_at`、`updated_at`、`completed_at`、`locked_at`、`worker_id` |
| `patch_intents` | 保存前持久日志：文件、原文件 SHA-256、目标记录快照、状态、错误、创建/更新时间 |
| `bridge_meta` | 固定本工作区远端目的地（URL / tenant / KB）；不含 API Key |

Outbox 不设指向 records 的级联删除外键，因此本地记录删除后，远端删除任务和旧 entry ID 仍存在。索引包含待运行状态/时间、记录、文件、远端任务 ID 和按创建时间排序的 pending/retry 部分索引。

原真实 50,000 行定位库已经备份并原地升级，**files 1 行、records 50,000 行，全字段有序摘要升级前后相同**：

- records SHA-256：`fc3277fd40afd166c6b5e9f35e1e214ac68cc21f634e43087a56ea169969fddc`。
- [迁移证据](<operator-local-path>)。
- 备份：`<operator-local-path>`。

## 4. 修改和索引事务边界

Patch 顺序：

```text
定位、校验、准备目标版本
  → SQLite 持久保存 prepared intent
  → 写前备份 → 同目录临时 XLSX → os.replace
  → 重新以 read_only 打开实际文件，核对唯一目标 fingerprint
  → 同一 SQLite 事务：更新 records + 写 Outbox + 完成 intent
  → COMMIT
  → Worker 尝试批量同步
```

如果进程在 Excel 保存后退出，intent 仍然存在。恢复时读取实际 Excel：原文件未改变则取消未执行 intent；全部目标唯一匹配则完成 SQLite 和 Outbox；缺失/歧义则保留 blocked intent，报告问题。不用行号猜测，不重新执行加法/乘法，也不回滚已保存 Excel。无业务键记录的已知 patch 同样能通过该日志保留 record_id。

index 流式扫描差异，在一个本地事务内更新 Locator、为新增/更新入队、为删除建立 tombstone，再提交。HTTP 不在扫描事务内。未变化文件仅尝试已有队列恢复，不必为远端重试重扫整张表。

每 1,000 行是 SQLite staging 的批量写缓冲，不是把整个文件读完再存。它与远端每 200 条导入、持久 Outbox 的提交边界是三个不同概念。

## 5. 状态机、锁与错误分类

```text
pending / 到期 retry → processing → completed
                         ├─ 过时且已安全处理远端结果 → superseded
                         ├─ 暂时错误 → retry → 达到上限 → failed
                         └─ 权限/配置/歧义/无法确认远端结果 → blocked
processing 租约超时 → retry
```

领取使用 `BEGIN IMMEDIATE`；持久记录 `worker_id`、`locked_at`。本机 OS 锁同时阻止仍存活的慢 Worker 被另一进程“超时接管”，进程死亡后 OS 释放锁。锁只覆盖本工作区，不支持网络文件系统或多主机分布式 Worker。

默认最多 8 次失败。退避为 5、15、60、300、900 秒，之后保持 900 秒。连接拒绝、超时、429、5xx、异步未完成进入 retry；401/403、KB 不存在、目的地配置不一致、定位歧义和严重冲突进入 blocked。达到上限进入 failed，不无限重试。

整批连接/服务失败后结束本轮，剩余任务保留 pending，避免离线时遍历大队列持续请求。日志包含 task_id、record_id、attempt、category、status；不输出请求头、服务器原始错误正文或 API Key。

## 6. 幂等、过时版本和异步恢复

`operation_key = SHA256(record_id + fingerprint + sync/delete)`，数据库唯一约束阻止等价活动任务重复生成。工作区目的地另外持久固定，配置变更不能把旧 entry ID 用到新 KB。A → B → A 或发现远端条目缺失时，可重置已完成的同版本任务；活动/失败/blocked 任务的检查点不会被重置丢弃。

每次执行先比较当前记录与 expected_fingerprint。旧任务不提交旧内容；标记 superseded。若旧版本已经获得远端 task_id，必须先续查并清理它的结果，再放行新版本。每条记录只能执行最早的未终结任务；不确定的旧 POST 会阻挡新版本，防止远端乱序覆盖。

批量 POST 前持久记录 `phase=posting` 和输入位置；POST 返回后立刻提交 `remote_task_id`；之后才轮询。重启发现 task_id 就 GET 已有 progress，不重复 POST。成功条目按 `success_entries.index` 回填各自绑定，部分失败仅重试对应记录。

FAQ answers 携带完整 record_id 和 fingerprint；embedding 的标准问题保持语义文本。通过已验证的 FAQ 列表 `keyword + search_field=answers` 可以限量定位一个 record，核对其完整身份、版本及文本，不下载整库。

DELETE 成功后中断可重复删除已知旧 ID，然后补建。POST 应答丢失或 progress 过期时，若找到唯一匹配条目则回收绑定；如果无法确认，进入 blocked，**不把“没查到”误当成“之前一定没提交”**。

## 7. 对账与有限性

`reconcile()` 默认重新扫描 Excel fingerprint，恢复 intent，补齐 rag_status 非 synced / 本地 entry ID 缺失记录的任务。Worker 普通恢复先比较文件大小和 mtime，只有文件变化才增量扫描；显式 reconcile 可检测统计信息未变化的内容差异。

远端默认只核验最多 20 个已知 entry ID，优先异常记录，并读取 FAQ count 作为诊断。核对答案中的 record_id、可用的 fingerprint 和标准问题；缺失/内容漂移重新入队；绑定到不同记录则 blocked。count 不等于本文件行数并不直接证明错误，因为 KB 可以包含其他文件。

真实对账发现原 index 与 patch 的字段顺序不同，可能造成语义文本假漂移。现在统一排序生成文本，并新增“patch 后完整对账为零差异”的测试；首次发现过程保存在早期验证目录，没有隐藏该问题。

## 8. 启动恢复及运行方法

`start-local-stack.ps1` 保持原登录任务不变，可恢复明确命名的已停止 WeKnora 容器，保留现有 Embedding / Harness 启动逻辑。之后隐藏启动维护子进程，默认最多 1,000 条任务 / 45 秒，不等待队列清空再打开 Harness。已经实际执行启动脚本，后台日志显示原 50,000 行工作区 `processed=0`、所有活动/错误状态为 0。

```powershell
# 在 <operator-local-path> 下执行；连接文件应使用自己的真实路径
.\.venv\Scripts\python.exe -m excel_bridge.maintenance stats --connection-file <operator-local-path>
.\.venv\Scripts\python.exe -m excel_bridge.maintenance recover --connection-file <operator-local-path> --max-tasks 1000 --max-seconds 45
.\.venv\Scripts\python.exe -m excel_bridge.maintenance reconcile --connection-file <operator-local-path> --remote-limit 20
```

修正权限或文件问题后，操作者可以执行 `retry-blocked`；保留远端检查点，不盲目重新 POST。环境变量：`EXCEL_BRIDGE_OUTBOX_MAX_ATTEMPTS`、`EXCEL_BRIDGE_OUTBOX_RETRY_DELAYS`、`EXCEL_BRIDGE_OUTBOX_LOCK_TIMEOUT`、`EXCEL_BRIDGE_OUTBOX_IMMEDIATE_SECONDS`。配置含义及默认值见 README。

## 9. 故障注入与回归结果

测试不是仅模拟一个成功返回值：使用真实 XLSX、真实 SQLite、HTTP 测试服务、独立 Python 进程，调用 `os._exit(86)` 终止后再启动新进程恢复。测试故障开关要求同时设置 `EXCEL_BRIDGE_TEST_FAULTS=1` 和 `EXCEL_BRIDGE_FAIL_AT`；不在 DSH schema 中。

| 场景 | 核验内容 |
| --- | --- |
| A 正常 | records 和 FAQ 为新版本，Outbox completed，无活动任务 |
| B 完全离线 | 关闭 HTTP 服务，Excel/SQLite 成功，retry 持久化；新进程恢复后可查询 |
| C Excel 保存后退出 | SQLite 仍是旧版本；新进程通过 intent 核对落盘内容并补齐 |
| D POST 返回后退出 | 持久 task_id；恢复先 GET 原 progress，POST 数不变 |
| E processing 崩溃 | 过期锁重置 retry 并完成 |
| F 版本乱序 | 旧 retry superseded，仅新版本提交；另测旧任务已在远端执行的情况 |
| G 删除后退出 | 旧 FAQ 确实消失；重启补建，不永久缺失 |
| H 两个真实 Worker | 同一任务只发生一次实际 POST |
| I 401 | blocked，重复 Worker 不再增加尝试次数 |
| J 500 | attempt、退避时间正确，第 8 次失败终止自动重试 |
| 批量 425 | 3 次 POST：200 / 200 / 25；逐记录 completed |
| 部分导入失败 | 2 条成功、1 条 retry，恢复只提交失败的 1 条 |
| POST 应答未持久化 / progress 过期 | 通过精确 record + fingerprint 找回唯一条目，不重新 POST |
| 无法确认的 POST | blocked，不盲目补建重复 FAQ |
| 空队列但 Excel 丢失 | 返回 local_reconcile.blocked_files 及错误，持久记录 reconcile_blocked，不静默报告无待办 |
| 删除 / 迁移 / 外部修改 / 无业务键 | tombstone 保留旧 ID，v0 数据不变，Excel 更新优先，无业务键 patch 崩溃可保留身份 |

最终全量运行和性能数字在本报告末尾的验收记录中给出。历史回归包括中文、浮点、行号变化、选择器、批量修改和 50,000 行索引；没有重新全量向量化现有 50,000 行真实 KB。

## 10. 真实服务完整闭环（非 mock）

最终证据：[outbox-live-report.json](<operator-local-path>)。独立测试工作簿、SQLite、租户及 FAQ KB，使用已运行的真实 qwen3-embedding。

真实操作 `docker stop WeKnora-app`，不是修改返回值、不是改到假 URL：

1. 在线初始索引 3 条，远端 count=3。
2. 停止后端容器，修改 ReviewStatus 为“Outbox真实恢复验收通过”。
3. 返回 `partial / modified=1 / pending=1`；重新读取 XLSX 和 SQLite 均为新值。
4. `docker start WeKnora-app`，用新的维护进程执行恢复，无须重做原 patch。
5. 语义 query + 新 ReviewStatus 精确过滤命中 1 条。
6. 同 record 仅 1 份 FAQ，全 KB 仍 3 条；再次 Worker processed=0。
7. 显式 Excel/SQLite/远端对账：缺失=0、冲突=0、pending/retry/processing/failed/blocked 全为 0。
8. Worker 前后 Excel SHA-256 相同，证明恢复没有再次写 Excel。

最终真实记录耗时：离线 patch 验证 4.343 秒，恢复进程及查询/对账验证 2.171 秒。两者不包含人工安排停服/启动及等待的间隔。

原 `<operator-local-path>` 未改，SHA-256 仍为 `DBA380ECC779288DE64F23B32A563399490D46C63A566B3333B37900BD29622C`。WeKnora、Embedding、DSH Web 最后健康检查均为 HTTP 200。测试租户/KB、工作簿、备份和证据保留，没有清理原有用户数据。

## 11. 仍然不能无条件自动恢复的边界

- **无远端幂等键时不能承诺跨系统 exactly-once。** POST 被受理但没有可用 task_id、限量查询也无法证明结果时，blocked 并要求人工核查。存在多个匹配 FAQ 时也不擅自猜测/合并。
- progress 保存期有限。找到唯一条目可恢复 FAQ 绑定，但条目可见不构成对所有内部向量存储的完整审计；语义召回仍依赖 WeKnora/Embedding 健康。对所有向量完整性的强审计不在此 MVP 范围。
- 缺失或被外部继续修改的 Excel、重复业务键、保存结果不唯一、损坏文件、权限和磁盘故障可能要求人工处理。不会为了远端一致性回滚 Excel。
- Worker 使用本机 OS 锁和 SQLite。网络文件系统、多主机分布式 Worker，以及外部 Excel 程序不遵守锁时的所有竞争，均不能保证。已有保存前 stat 复核和歧义保护继续有效。
- 45 秒是调度/HTTP 预算；正在执行的一次 XLSX 扫描或原子本地步骤有完成粒度，不能当作操作系统硬实时终止保证。恢复子进程不阻塞 Harness。
- 这是有界 Worker，不是常驻守护服务。超出预算、未到退避时间或租约仍有效的任务等待下次恢复；failed/blocked 需要明确修复后再触发。没有实测整个电脑重启/登录触发，只实测了进程退出、新进程恢复和启动脚本。
- 完成任务和 intent 暂不自动清理，便于诊断但数据库会增长；长期运行需另定保留策略。连接文件仍依赖宿主 Windows ACL，忽略打包/不写报告不等于完成了凭证保险库建设。

## 12. 方法论总结

先固定事实源，再画清持久化边界；先落日志再做不可跨库回滚的动作；将“已知失败”和“结果未知”分开；持久跟踪每条记录但批量传输；先证明身份与版本再重试；用进程真实退出证明恢复，用真实服务停机证明集成，用对账证明终态而不是只看返回成功。最后再依据 profiling 优化队列扫描，不以减少恢复证据换性能。

## 最终验收记录

2026-09-07 重新执行的最终 `npm test`：**Node 3/3，Python 42/42，共 45/45 通过**。Python 全套 139.376 秒；包含 23 个新增 Outbox 测试，全部原有回归保留。[完整日志](<operator-local-path>)。

- 50,000 行 HTTP 测试服务索引：**84.876 秒**，250 批、每批 200 条，50,000 条均完成。不是 50,000 行真实向量化耗时。
- 425 条 patch：**0.897 秒**，3 次批量 POST、3 次批量 DELETE，425 条独立 completed，活动任务 0。此数字是本地测试服务，不冒充真实 Embedding 性能。
- 调优前本轮 50,000 行曾为 173.801 / 210.681 秒；检查执行计划发现队列领取重复使用临时排序。使用有序 pending/retry 部分索引、保持 Worker 的 WAL 连接以及减少重复正则后改善。新增持久日志、FULL 同步仍有本地成本，不宣称与旧无日志版本零开销。
- 最终真实小型测试库：租户 **10006**，KB **10e1c780-e1f3-4da8-ac10-ca33156bc701**，3 条实际 FAQ；真实停服后的 1 条 patch 由新进程恢复，重复数 **0**，最终完整对账差异 **0**。
- 原 50,000 行数据库迁移前后全字段摘要相同；原 Excel SHA-256 未变。
- 三个 DSH 工具 schema 总字符数仍 **2,488**；未改模型配置，启动脚本恢复与后台有界 Worker 已实测。
- 2026-09-07 续验：重新运行全部 45 项回归并落日志；启动脚本恢复当天离线的 Docker/WeKnora 和 DSH Web。三个端口 8080 / 55556 / 3080 均为 HTTP 200。真实测试库再次核验 3 个 entry：缺失 0、冲突 0、活动/失败任务 0；语义 query + 新状态过滤仍命中 1 条。原 50,000 行工作区后台恢复 processed=0、blocked_files=0、全部活动/错误任务为 0。
