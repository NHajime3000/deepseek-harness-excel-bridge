# Plan IR v1

Recipe 与 Procedure 使用同一数据结构，执行器不支持 eval、shell、任意导入或自定义代码。

```json
{
  "ir_version": 1,
  "name": "投诉状态复核",
  "intent": "物流投诉复核",
  "required_roles": ["complaint_text", "review_status"],
  "parameters": {"status": "需要复核"},
  "steps": [
    {"id":"find","type":"semantic_query","role":"complaint_text","query":"物流延迟、配送异常、快递问题"},
    {"id":"mark","type":"patch","source":"find","role":"review_status","operation":"set","value":"${status}"},
    {"id":"count","type":"aggregate","source":"mark","metric":"count"}
  ]
}
```

计划不包含 file、row、record_id、KB ID 或 Sheet 坐标。运行时才绑定真实文件和当前记录。字段角色必须声明；精确别名或同 schema 的已确认历史映射可自动使用，多个候选或低相似度只返回建议。

步骤 source 默认为 input（当前表全行），或此前步骤 ID；数组表示去重并集。顺序必须拓扑有序，不允许向前引用或循环。branch 的 then/else 指定下游步骤 ID，下游必须分别引用 `分支ID.then`、`分支ID.else`。条件支持 all、any、not，以及角色字段的 eq/ne/lt/lte/gt/gte/between/in/contains；数值比较遇到非数值数据会报错，不退化为字符串排序。

| 类型 | 行为 |
| --- | --- |
| filter | 精确条件筛选当前集合 |
| semantic_query | 当前文件 KB 召回并与输入集合相交，最多 50 候选；配置的模型再按每批至多 8 段角色文本判定，不直接把召回视为命中 |
| select | 选择有限行/展示角色，不修改原文件 |
| aggregate | count、sum、min、max、mean |
| branch | 按条件划分 then 和 else 两个互斥集合 |
| patch | 已有列的 set、numeric_add、numeric_multiply |
| verify | 检查条件和 min_count/max_count |
| export_summary | 写入固定内部目录下的 JSON 汇总，无任意输出路径 |
| user_confirm | 把确认要求纳入预览；初始批准冻结的全计划包含此要求 |

所有步骤先模拟，得到有界预览和外置运行数据；确认批准整个冻结计划。user_confirm 不表示执行到中间再次弹窗。更改来源或计划需新预览，不能复用原批准。

状态主要为 preview → running → syncing/completed，冲突为 blocked。步骤为 pending → running → completed；每个步骤保存摘要和定位符，写入目标保存 before/after。中断后若磁盘数据和持久证据无法证明 before 或 after，则停止，不以“重试”重复加法。当前输入行集另存 SQLite 用于恢复时发现未涉及字段的外部修改。
