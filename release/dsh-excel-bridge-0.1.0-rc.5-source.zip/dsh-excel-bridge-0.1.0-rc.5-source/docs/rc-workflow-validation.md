# Excel Bridge RC3：实施、验收与未完成项

日期：2026-09-08。版本：0.1.0-rc.3。结论：发行包装、Recipe/Procedure 后端及安全恢复已落地；**本轮全部验收尚未完成，不能作为稳定版发布**。当前本地 Qwen 4B 的普通查询/写回通过，历史复用的自主参数构造不可靠，复杂 Word SOP 编译多次被校验器或输出预算拦截。

本报告区分代码实现、模拟测试、真实后端测试和真实 DSH 会话。历史 MVP、Outbox、Workspace 报告保留各自日期的证据，不用其旧统计替代本轮测试。

## 插件发布（1–8）

1. 仓库结构保留 `src/`、`excel_bridge/`、`scripts/`、`tests/`、`docs/`，补充 MIT LICENSE、Python pyproject、公开 README、用户指南、Plan IR 文档和可选精简 Agent 预设。新增工作流模块而非重写 Bridge。
2. 按实际 DSH 0.1.1-rc.2 的 `dsh.bundle.patch` 与 `dsh.client.inject` contract 注册；未创建虚构 manifest。发布约定参见 [DSH 官方 publish 文档](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md)。本机独立 tarball 安装已使用真实 DSH CLI；未创建 GitHub 远端、未推送 npm 或 marketplace。
3. 真实浏览器的“设置 → 插件”可见 Excel Bridge 配置卡、启用开关和 Recipe/Procedure 配置。独立 profile 重启后配置仍存在。旧 3 工具保持默认，Procedure 显式启用才增加第 4 个。
4. 可配置 Python、workspace/SQLite 根目录、连接文件、WeKnora URL/凭证/tenant、自动建库/索引、结果数/批次、Outbox 恢复、Recipe/Procedure 开关和编译端点。SQLite 固定为配置 workspace 下的 `.excel_bridge/index.db`，不另设任意 DB 路径；辅助安装脚本默认不安装，需 `-Install` 明确启用。
5. 运行代码使用包根目录与配置，不依赖本机开发目录 link。真实验证使用本机显式配置路径，这是测试输入，不是运行代码常量。用户旧模型、Local LLM Controller、ToolDoc、主 DSH profile 未被替换。
6. Python 依赖为 openpyxl、python-docx；可配置现有 Python 或独立虚拟环境。没有自动全局 pip、系统 PATH 修改或不透明 postinstall。
7. npm tarball 使用 36 文件的 allowlist，不含 Excel、SQLite、Outbox 数据、凭证、虚拟环境或 node_modules。源码发布目录由 `build-source-release.mjs` 单独产生，历史报告中的操作者绝对路径在导出副本中脱敏；原始报告不被覆盖。
8. 干净安装是真实验证：新建独立 DSH_HOME，经 `dsh plugin --profile web add <本地 tarball> --ignore-scripts` 安装，在 3081 启动，出现配置卡、注册工具、调用包内 Python 并完成真实 WeKnora 查询。原 DSH 3080 未重启。发现 pnpm 会保留被覆盖的同版本包后，递增 RC 版本并核对安装文件哈希，不再用“Already up to date”作为新代码生效证明。没有远程公开发布验收。

## Recipe（9–16）

9. SQLite 增量迁移至 v3，新增 recipes、recipe_versions、recipe_runs、field_roles、field_mappings、recipe_query_context，以及 Procedure 表；保留全部既有表和数据。
10. 成功普通 query → 同范围、同列、同值 set 写回可以生成参数化 history 草稿；有过滤器、非统一操作、部分失败、过期查询上下文等情形不自动沉淀。同步成功的 SOP run 可以生成 sop 草稿，单次完成重试不会重复创建。
11. 新模板始终为 draft。可以管理员明确激活；Procedure 在至少两个不同文件完成同步后可激活。历史普通操作的来源本身不伪造成一次 Procedure run，因此本轮 B 表一次复用后仍为 draft，success_count=1。
12. Recipe 从统一 Procedure 入口加载版本、绑定当前表、重新检索、预览、确认、执行。模板保存角色和参数，不保存旧 Excel 坐标；一次 run 保存真实文件、记录 ID、快照和映射。
13. 检索选择无需新服务的 SQLite 最近 2000 个模板，使用英文词项/中文二元组和字段覆盖评分，返回至多 3 条；只有高分且与次名有差距时自动选择，选择也只进入预览。未建立混杂 Excel 数据的 Recipe KB。
14. 字段映射依次使用显式映射、同 schema 的已确认历史、唯一精确别名。相似度仅用于建议，歧义或缺列停止写入。新增投诉/反馈语义字段识别，修复英文 ComplaintText 被状态字段掩盖的问题。
15. 真实后端验证通过：A 表的 ComplaintText/ReviewStatus 经实际 DSH query/patch 生成草稿；B 表的客诉描述/处理标记正确映射。真实 WeKnora 召回 4 条，当前 4B 小批量相关性判断保留 2 条；确认后仅 ID 101、103 变成“需要复核”，ID 102、104 仍为“未处理”。Outbox pending/processing/retry/failed/blocked 均为 0，completed=6。
16. A/B 的业务 ID 和内部 record_id 不同，执行重新定位当前 B。测试检查模板不含来源路径或 rec_ 标识，不以旧 row_hint 写新文件。不会把每次聊天自动保存为 Recipe。

## Procedure（17–24）

17. Plan IR v1 顶层仅允许 ir_version、name、intent、required_roles、parameters、steps，步骤 1–64。source 为当前输入、此前步骤或互斥分支；并集去重。详细结构见 [Plan IR](plan-ir.md)。
18. python-docx 按 Word 正文顺序提取标题/段落和表格行；Markdown/TXT 按非空行读取。限制输入 8 MB、DOCX 解压总大小 32 MB。真实 DOCX 解析有测试；Word 视觉渲染因当前受支持运行时缺少 LibreOffice 未完成，未把解析通过冒充视觉验收。
19. SOP 按段落分块，默认 1800 字符/块，最多 128 块/20 万字符。提取、规则覆盖校验、独立交叉检查、分段保存；不把整份 Word、整个 Excel 或中间完整行集送进 DSH 对话。语义复核最多 8 段角色文本/批、1200 字符/段，超限或判断缺失停止。字符预算不是通用 tokenizer 的严格 8K 证明。
20. 白名单：filter、semantic_query、select、aggregate、branch、patch、verify、export_summary、user_confirm。语义步骤必须在写步骤之前。只支持现有列 set/numeric_add/numeric_multiply，不新增 SOP 编程语言。
21. 校验未知字段、未知步骤、角色、条件、循环/向前引用、分支目标、数值条件和公式载荷；段落需要完整覆盖，每个规则/步骤均应有对应关系。不把 schema 合法等同业务规则正确，交叉检查失败进入 needs_review。
22. procedure_runs、procedure_step_runs、procedure_items 保存步骤、摘要、定位符、冻结前后值和文件哈希。每调用默认推进 8 步，可按 run_id 继续；状态不依赖聊天历史。
23. 恢复先处理原有 patch intent，再检查文件哈希和整个冻结行集。真实子进程在 6 步加法流程第 4 次写后以 86 退出，重启后第一行价格从 6.95 续至 8.95，总共 6 个备份，未重复前三步或第 4 步算术。额外修改未涉及记录会被拦截，不用目标后值匹配掩盖外部改动。
24. **复杂 Word SOP 真实编译未通过。** 测试包含圣诞语义、France 条件作用域、Quantity<5、Price>10 分支和计数。当前 4B 多轮出现覆盖遗漏、重复 ID、错误条件、只输出 select 或超出输出预算。系统保留诊断并停止；没有写死该 SOP 的生产逻辑，也没有手工替换 Plan 后宣称自动编译成功。该测试表尚未获准执行编译结果。

## DSH / Context（25–31）

25. Bridge 最终 4 个工具（默认仅 3 个）；新增仅 procedure_run。编译模型内部的结构化输出调用不是另一个 DSH 工具。
26. 4 个工具的 name+description+parameters 紧凑 JSON 共 3383 字符；原 3 工具 schema 保持原样。输出保留原有 12K 字符后端边界及 Node 16K 字符 stdout 上限，不把全量运行快照返回聊天。
27. 实测精简 Agent 的工具上下文约 850 tokens（早期短说明版为 822）；这来自 DSH contextBreakdown 统计，不是 chars/4 的伪精确值。
28. 干净默认 DSH 共有 29 个工具，其 toolsTokens=7586，加系统/消息后压力超过 9K，不能声称满足 8K。单独精简预设只保留 Bridge 工具，所测会话压力约 1.3K–2.9K。当前模型服务实际 n_ctx=16384，**本轮未完成真实 n_ctx=8192 验收**，未更改原模型窗口。
29. Qwen 4B 简单任务通过：真实会话查询普通商品；另一真实会话在 A 表查两条投诉并按 record_id 写回，仅修改 2 行，Outbox 同步成功。
30. **Recipe 自然语言自主路由未通过稳定性验收。** 真实新会话会编造 run_id/文件名、漏 instruction，甚至在只有索引计数时编造表内容；带工具提示的会话也未稳定完成。后端拒绝非法编号/来源，未按虚构参数改表。B 表后端正确执行不能冒充这些 DSH 会话成功。
31. **Qwen 4B 复杂 Procedure 全链路未通过。** 真实 Word 提取已测试，规则执行器和断点测试通过，自动编译及自主路由仍是未完成部分。编译端点独立可配置，但没有偷偷下载/切换其他模型或改变用户默认配置。

## 安全（32–36）

32. 原 Outbox、身份、Workspace 测试仍全部通过。真实测试使用小型合成表/独立测试工作区；没有把旧 5 万行库重新向量化作为开发前提。原始 5 万行 Excel SHA256 复核与此前记录一致。
33. 原备份、临时文件替换、持久 intent、Outbox 继续复用。Procedure 不提供跨步骤全局回滚；已成功步骤保留，冲突不会自动覆盖外部更改。
34. 两个 API Key 输入为 password；更重要的是 DSH live schema 标记 role=secret，真实 settings.describe 不回传模拟密钥，修改其他配置不会丢失已有 secret。私有连接文件、SQLite、模型响应中的源数据和日志不进入发布包。无日志输出真实 API Key。
35. SOP/IR 没有 eval、shell 或任意 import 执行分支；Node 仍以固定模块名启动 Python。输入文件来自调用者显式路径，不是严格 OS 文件系统沙箱；持有宿主权限的人/其他工具仍能操作文件。不能将插件称为安全隔离环境。
36. 所有 Procedure 先预览，首次 dry_run=false 也不写。confirm=true 批准的是已冻结全计划；user_confirm 表示纳入该预览确认，不代表中途再弹窗。当前确认依赖 Agent 遵守用户批准，不是不可绕过的浏览器人工签名。因此功能默认关闭，不能把小模型口头承诺当作授权保障。

## 测试与边界（37–41）

37. 最终完整回归：Node 6/6、Python 89/89，总计 95 项通过。Python 218.361 秒；模拟服务 5 万行索引 114.894 秒、425 行 Outbox patch 1.502 秒。模拟服务耗时不是实际向量化吞吐。早期失败日志保留，不覆盖失败历史。
38. Recipe 回归覆盖参数化、改名列、缺列、歧义、确认、故障次数仅记一次、草稿去重、无旧定位符。真实 B 后端复用通过；DSH 自主路由失败另列，未混算成功。
39. Word 回归覆盖真实 python-docx 段落/表格顺序、分块上限、覆盖校验、双调用编译检查点。小批量语义判断覆盖每条候选，缺失即拒绝。复杂 SOP 真实编译及 Word 视觉验收未通过。
40. 真实 DSH 证据保存在操作者私有 `.real_validation/rc-20260908/`，含普通会话、A 表 query/patch、失败的 B 自主/引导会话、SOP 会话、UI 检查、clean profile 安装与回归日志。公开包不带这些工作簿/会话原文。结果以 SQLite/Excel/Outbox 和 tool/result 为准，不采信模型自报的完成文字。
41. 剩余工作：修复/替换复杂 SOP 的编译适配与 4B 自主参数构造；在真实 8K 窗口重新验收三类任务；必要时接入不可绕过的人工审批；完成受支持的 Word 视觉验收。其余边界包括 top-50 非全表召回、有限角色别名/词法 Recipe 搜索、单文件/最多 64 步、Python 内存保留有限行集、Excel 高级对象保真和手动备份保留策略。本版是可安装的实验性 RC，不是已完全验收的发布版。

## 本轮方法论

先分清事实、派生索引与模型判断：Excel/SQLite 决定实际值，WeKnora 负责召回，有限模型批次判断语义。模板与运行实例分离，旧定位符不能变成复用规则。写入必须建立冻结预览、前后值和 intent 证据；恢复时证明已写过，而非重复执行试运气。

验收分层：静态校验 → 模拟故障 → 真实小表/真实服务 → 干净包安装 → 真实浏览器/模型会话。每层单独保留失败；包哈希、实际单元格和 Outbox 状态优先于安装命令提示或模型文字。模型不可靠时保留需要审阅的状态，不能通过削弱校验、写死测试条件或扩大 Context 隐藏问题。

## 高影响操作与实际处置

- Python 依赖安装：仅项目独立虚拟环境，未改系统 Python。会使用网络和磁盘，用户已授权验证环境准备。
- DSH 重启：仅本轮新建 3081 测试进程，先核验命令行；主 3080、Controller、ToolDoc 和默认模型配置保持。
- Excel 写入：仅合成 A/B 测试表，各 2 行并保留备份；复杂 SOP 表未执行失败计划。没有原始 5 万行写入。
- 公开发布、删除旧 KB、清空 SQLite、强制覆盖业务文件：均未执行。任何自动审批提示不等于绕过宿主权限机制。
