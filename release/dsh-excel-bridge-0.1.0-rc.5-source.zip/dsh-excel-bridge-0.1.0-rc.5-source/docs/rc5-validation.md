# RC5 实施、验收与方法论报告

日期：2026-09-24。版本：0.1.0-rc.5。结论：后端和恢复回归通过；Recipe 自主路由及 SOP 自动编译仍未达到无人值守标准，不发布为 1.0。

最终 tarball SHA-256：`ea29ab1fac7bf57a488f012c8bd3d3a6f99baec18d8733cd11d05dc67ffad8a7`。9 月 10 日的私有 RC5 原型与它不同：后者修正了当前 DSH 模型的凭证服务访问。两份本地证据均保留，从未对外发布同版本包。最终安装验证按文件哈希确认，不以 pnpm 的缓存提示作为成功依据。

## Recipe（1–7）

1. **recipe_id：不需要。** 模型入口只接受 `instruction` 和 `files`，不增加 Recipe 专用工具。
2. **run_id：不需要。** 后端用宿主可信会话身份、规范化文件路径和请求摘要绑定运行。模型不能传会话 ID、运行 ID、映射、Plan 或确认标志。
3. **Resolver：** 本地 SQLite 最近最多 2000 个模板，Top K 上限 3。意图词项、有限可审计同义词和字段覆盖评分；首名至少 0.7，领先次名至少 0.1 才进入预览。真实测试发现历史名称与“物流投诉”不同词，已补意图归一化，未降低阈值。该词表只做模板检索，不替代逐行语义判断。
4. **Field Mapping：** 使用同 schema 已确认映射或唯一精确角色别名；缺列/多列歧义返回 `needs_mapping`。不复用旧工作簿行号或 record_id。
5. **20 个全新真实 DSH 会话：严格通过 15/20（75%）。** 正常命中 3/4、字段改名 2/4、缺字段 2/3、相似 Recipe 2/2、无 Recipe 2/2、低置信度 1/2、错误文件 1/1、字段歧义 2/2。通过是指正确进入待审批或正确拒绝，不是 15 个自动改表成功。模型参数形状及准确文件约定通过 17/20（85%）。历史模板来自此前实际 query/patch 学习记录，复制到隔离测试库；不宣称本次新生成了 20 个历史模板。
6. **虚构参数仍有残留：** 本批未出现模型填写 recipe_id/run_id，但有编造文件路径、把退款/赔偿等未提供规则添入 instruction、误选普通查询/patch 的行为。一次对 1 行做了同值重写：单元格值没变，但文件哈希改变、有备份，按失败计算。不能据此宣称“模型不会再编造”。
7. **低置信度停止：** `needs_review` / `no_recipe_match`；字段问题为 `needs_mapping`；这些 Procedure 路径不写 Excel。不降低校验来抬高通过率。20 会话中 19 份文件保持原夹具哈希；例外是上述普通 patch 误路由。

## Procedure（8–17）

8. 配置提供 `current_dsh_model`、`openai_compatible`、`local_openai_compatible_endpoint`、`disabled`、`manual_review`，以及独立 URL、model、secret API key。后两种关闭网络编译，不自动下载模型。
9. **当前 DSH 模型可以用作 Compiler。** 真实测试发现直接访问未注入的 `credentials` 会被 Cordis 拒绝；最终版按 DSH 自身适配器用法通过 `Context.get('credentials')` 获取可选服务。凭证缺失安全停止。修正包真实调用已进入 `extract_check`，不再是宿主服务访问错误。
10. 独立 OpenAI-compatible 配置通道已实现，本地独立 55557 端点已实测。没有获得可用的更强模型端点或授权凭证，因此没有“强模型对比成功”的结论。此处的独立服务仍运行现有 Qwen 4B。
11. 复用 DOCX 正文段落/表格顺序及 MD/TXT parser；默认 1800 字符/块，最多 128 块、20 万字符。输入 8 MB、DOCX 解压 32 MB 上限；过长段落拒绝而不是截断后猜规则。原复杂 Word 文档未改写；中文解析已核对，未宣称完成 Word 视觉渲染验收。
12. Rule Extraction 提取 condition、action、exceptions、roles、semantic、order、depends_on、paragraphs，并显式列出描述段落及需复核项。校验类型、完整段落来源、描述/规则重叠、依赖前向引用。
13. 精确重复规则合并并保留来源；逐条已抽取规则组装 Plan fragment，不把整份 SOP 重送给组装阶段。后端命名步骤、连接依赖；不加入 eval、任意 Python 或 shell 执行。
14. 原段落→规则的独立检查、每条规则→步骤的覆盖检查都需通过。编译阶段结果、输入摘要、usage 和耗时存 SQLite；重入复用 checkpoint，不手工修复失败计划冒充成功。
15. 保留严格 Plan IR validator：未知键、未知类型、非法角色/条件、循环和向前引用、分支目标、危险载荷等均阻止执行。Schema 合法不代表业务语义正确，仍需覆盖检查和预览审批。
16. **复杂 Word 自动编译未通过。** 本轮 4 步、8 步、原复杂 Word 三个直接端点试验均为 `needs_review`。修正后的真实 DSH/current-model Word 试验也未通过，未产生获准写回的复杂 SOP。
17. 具体失败见下表。4 步提取虽有 4 条，包含把确定条件标成 semantic、把动作类型当角色等问题；不能把数量对齐算规则完整率 100%。8 步和 Word 的描述/规则来源重叠被拒绝。当前模型复测在覆盖检查输出预算耗尽；这是输出上限，不是 8K Context overflow。

| 直接端点试验（9 月 10 日） | 抽取条数 | 已返回结构化输出字符 | 总编译耗时 | 停止位置 | 最终 Plan/覆盖验收 |
| --- | ---: | ---: | ---: | --- | --- |
| 4 步 SOP | 4 | 745 | 15.03 秒 | extract_check 未返回唯一结构化调用 | 未通过 |
| 8 步 SOP | 8 | 1684 | 20.95 秒 | extract 来源校验失败 | 未通过 |
| 原复杂 Word | 5 | 964 | 15.47 秒 | extract 来源校验失败 | 未通过 |

字符数只统计已成功返回的结构化阶段，不包含失败阶段未保存的原始输出。忠实规则完整率没有通过独立验证，不能由条数推断。9 月 24 日修正后 current-model Word 的 extract 返回 894 字符，prompt 768 / completion 614 tokens，约 12.04 秒；随后 extract_check 耗尽 400-token 输出预算，整次工具约 21.67 秒。

## 执行（18–22）

18. filter、select、aggregate、确定条件 branch/verify、patch、数值运算全部由 Python 执行，不请求 LLM。复杂流程的状态和数据不靠模型记忆。
19. semantic_query 使用 WeKnora 召回及有限候选复核，默认候选上限 50，最多 8 条/模型批。显式提示 top-K 并非全表穷尽，禁止把召回数量当全量统计结论。
20. procedure_runs、procedure_step_runs、procedure_items 保存冻结计划、映射、行前后值、定位、步骤摘要、状态和源文件哈希。外部完整状态只返回有限投影，保持原文件锁、备份、临时保存、os.replace 和 Outbox 链路。
21. 原 6 步第 4 次写回后真实进程退出测试继续通过。新增 8 步分支/数值流程的单测及**真实 WeKnora 集成测试**均通过：第 3 步后 `os._exit(86)`，审批保留 EXECUTING，重启完成 8 步，最终审批 COMPLETED、同一 plan_hash，Outbox completed=14，其余 pending/processing/retry/failed/blocked 均为 0。真实测试 Plan 明确标记为人工编写的运行时夹具，不冒充 Word 编译成果。
22. 数值最终为 `[17,22,9,11,20,27,6]`，恰好 2 个备份，再次 resume 文件哈希不变；无重复 patch/数字累加。另一个真实 DSH Recipe 会话在管理员批准后只更新预期 ID 1、3，ID 2、4 保持未处理，Outbox completed=6，无积压。

## 真正 8K（23–28）

23. 隔离 llama-server 实际 `-c 8192 --parallel 1`，`/props` 确认 n_ctx=8192；不替换原默认服务、不下载模型。精简 Agent 仅 4 个 Bridge 工具。
24. RC5 普通 Query 最大采样 Context/投影 2031 tokens，实际命中预期 5 个圣诞商品。模型最终展示仍擅加货币符号并给出未执行的错误嵌套 filters 示例，因此只将检索结果判定正确，不将整段自然语言答复无条件判为正确。
25. Recipe 20 会话最大采样 Context/投影 2289，最大已实际请求输入（含缓存读取）2116 tokens；每会话 1–4 模型步骤、1–3 工具调用。
26. 最终修正包复杂 Word/current-model 最大采样 Context/投影 1560 tokens，实际请求输入 1291；1 模型步骤、1 工具调用，停止于编译 review。**这不是已成功执行复杂 Word 全流程的 Context 证明。**
27. 三类会话 systemTokens=113、toolsTokens=797；工具紧凑 schema 3172 字符。普通 Query dialog=598、Recipe 最大 dialog=789、最终 Word dialog=314 tokens。这里的 Context 来自 DSH pressure/projected 采样，不冒充服务端每一瞬间精确峰值；内部 Compiler 请求另计 usage，不算进 Agent 对话历史。
28. 所测会话无 Context overflow。Compiler 使用字符和输出上限而非通用 tokenizer 的严格预检；不能推广为任意长 SOP、任意模型或任意 64 步对话必定低于 8K。

## 审批（29–31）

29. SQLite 持久状态为 PLAN_CREATED → PREVIEW_READY → WAITING_CONFIRMATION → APPROVED → EXECUTING → COMPLETED；完整冻结计划/映射/行前后值/操作摘要计算 SHA-256 plan_hash。管理员独立 CLI 批准精确 hash；模型工具不暴露授权入口。测试的自动审批只针对验证脚本严格限定的合成夹具，不作为用户业务数据的预批准。
30. Plan、映射、冻结行或操作变化使旧批准失效；运行/恢复前再次校验，发生外部编辑则阻止继续。修改原 instruction/SOP 也使旧绑定停止，需要新会话重新预览，而不是用聊天中的“同意”批准新请求。
31. `procedure_run` 不接受 confirm；兼容内部 resume 的 confirm 参数不授予权限；`excel_patch` 也不能以 confirm=true 跳过批量审批。边界必须明确：管理员 OS 账户/任意 shell/直接改 DB 是可信管理面，不是被此插件隔离的对手。普通小批量 patch 仍保留原行为（默认阈值 20 行；跨表也触发审批），所以选错普通工具可绕开“本应走 Procedure”的意图路径，本批已实际观察到一次同值重写。尚未做到所有低影响调用累计风险或所有业务高影响单元格的统一授权。

## 发布（32–37）

32. 最终版本为 **0.1.0-rc.5**（Python 0.1.0rc5），不是 1.0。Stable/Tested 和 Experimental 在 README 分开标注。
33. 最终 39 文件 tarball 通过真实 DSH CLI `plugin --profile web add <tarball> --ignore-scripts` 在全新 home 安装；逐文件哈希一致，真实凭证扫描/宿主路径扫描通过。默认配置和 Python 依赖元数据保留；没有全局 pip、模型下载或默认模型切换。
34. 最终安装的浏览器“设置→插件”配置卡通过可见性、编辑保存、刷新保留、password 类型及密钥传输脱敏验证。验证脚本先前的 revision 竞态与异步 checkbox 瞬时断言已修正，不当作产品成功结果遮掩。
35. 最终 UI enable/disable 验证通过；Node 同时验证注销/恢复工具，默认仍为 3 个，Procedure opt-in 才为 4 个。临时测试密钥已清除。
36. GitHub 尚缺用户选择/授权的真实公开仓库、remote URL、repository 字段、提交和公开提交哈希。没有伪造 repository，也没有自动创建远端、推送或 npm publish。源码目录使用明确白名单，排除私有测试数据、工作簿、数据库、凭证、模型、node_modules、虚拟环境。
37. 2026-09-24 复核了 [DSH 官方发布文档](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md) 和 [dsh.pub 提交规范](https://dsh.pub/en/submit/)。当前 bundle.patch、client.inject、入口、license、version、keywords、files 与真实本机安装契约一致；dsh.pub 还需要公开可安装仓库及固定提交，再由用户批准提交。未执行任何公开提交动作。

## 回归和限制（38–42）

38. 最终 Node **8/8** 通过，包含新增宿主凭证服务访问与缺失凭证安全停止测试。
39. 最终 Python **114/114** 通过，耗时 195.695 秒。50,000 行夹具索引约 88.928 秒，425 行 Outbox patch 约 2.078 秒；性能会受缓存/并发/机器负载影响，不是 SLA。
40. 原 Node 6 + Python 89 的测试覆盖继续通过；必要的审批调用/迁移版本断言按新契约更新，没有删除原安全用例。RC3 冻结基线及其独立 95 项原版运行日志保留。
41. 新增自动化测试 **27 项**（Node 2、Python 25），最终共 **122 项**。20 个真实会话、UI、真实 Compiler 和真实 WeKnora 崩溃试验另列，不混入单元测试计数。
42. 当前主要限制：自然语言路由只有本批 75% 严格通过；错误路径/扩写指令/错选普通工具仍存在；低影响 patch 并非全局强审批；三个 SOP 编译试验未通过；无强 Compiler 对比；自然语言展示仍可能补充不存在的单位/错误示例；严格 instruction 绑定要求续跑原参数，改写后会安全停止；大批量直接 patch 中断可要求重新预览，不具备任意增量算术的无条件自动重放；字符预算不等于任意 tokenizer 的严格 8K 证明。当前不建议无人值守批量修改业务文件。

## 方法论及证据索引

- 先冻结 RC3 可回退基线，再将模型承担的 ID、映射、状态和恢复下沉后端；用类型白名单、持久状态和精确快照缩小错误的影响范围。
- 分层计数：单测通过、宿主集成通过、真实服务通过、模型意图正确、业务结果正确是不同结论。`turn/end=completed` 绝不等同 `Procedure completed`。
- 失败不覆盖：RC4 20 会话仅 7/20 严格路由通过；9 月 10 日 RC5 中断批仅 7 个完整结果，未计作完整验收；9 月 24 日另起 20 会话取得 15/20。不能跨批挑选成功样本拼成 100%。
- 发现宿主 contract 缺陷后，以最小 Node 修复 + 针对回归 + 新安装 + 文件哈希确认收敛；不靠重复同版本安装时的缓存提示判断生效。
- SOP 失败停在原因明确的阶段。真实运行时崩溃测试可以用手工测试 Plan，但必须注明来源，与自动编译成功完全分开。
- 本机原始证据（均不进入公开源码包）：`.real_validation/rc4-20260909/` 保存基线、初次编译和中断记录；`.real_validation/rc5-20260924/` 保存本批矩阵、普通 Query、审批续跑、最终 current-model Word、UI、回归和实际崩溃恢复。对应关键文件为 `sessions/matrix-analysis.json`、`sessions/02-normal/approval-live.json`、`complex-final/dsh-word-current.json`、`live-crash/crash-report.json`、`ui-final/settings.json`、`final-regression.*.log`、`final-artifact-audit.json`。

## 风险与下一阶段建议

优先解决可信任务入口/文件绑定和低影响普通 patch 的路由边界，再评估可选更强 Compiler。不要用降低审批阈值以外的提示承诺来宣称已强制授权，也不要靠放大 Context 或关掉 Validator 追求通过率。接入远程 Compiler 会发送 SOP 内容，应由用户选择端点并确认数据处理边界；公开发布会暴露源码，应先审阅白名单和脱敏结果。本轮未执行这些对外动作。
