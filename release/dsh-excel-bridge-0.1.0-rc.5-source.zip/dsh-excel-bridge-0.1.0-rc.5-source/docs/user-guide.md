# 使用指南

## 连接和权限

在 DSH 设置 → 插件 → Excel Bridge 配置 Python executable、工作区和连接文件。工作区下的 `.excel_bridge/index.db` 保存定位及运行状态；不要在不同租户间共用同一工作区。

连接文件使用一份租户凭证，不需要为每张表配置知识库 ID。WeKnora Key 需允许本租户内的 retrieve、ingest、manage_kbs，且 KB allow-list 不能只限定旧库。Embedding 模型由管理员配置一次。

API Key 可通过 password 输入或私有连接文件配置；本地文件不是加密保险库，需自行设置用户专用权限。不要在聊天或 Git 中保存凭证。SOP 编译模型的 API Key 与 WeKnora Key 相互独立。

## Recipe 和 Procedure

新功能为 RC 阶段，默认关闭。在设置里开启 Recipe Memory 和 Procedure 后，工具从三个变为四个，仅新增 procedure_run。

成功的语义查询后，对全部返回记录执行相同状态 set，可生成历史 Recipe draft。复用时重新解析新表字段和目标记录，不保存旧行号作为模板。仅远端同步完成的成功复用计入自动激活；管理员也可通过 workflow_cli 明确激活。不是每条聊天或每种自由操作都会生成方案。

用户示例：

- “这个新表按照上次物流投诉的处理方法处理。”
- “按照这个 Word 的流程处理这个 Excel，先给我预览。”
- 收到预览后：“确认按这个预览执行。”

任何新运行均先预览。参数中的 dry_run=false 不能跳过第一次预览。确认后以同一 run_id 继续，不要重复提交原始任务创建另一运行。多步骤写入、超过配置阈值、数值/金额修改和跨工作表会标记风险。复合字段映射或源文件发生变化时停止。

SOP 支持 .docx、.md、.txt，也可由管理员提供严格 Plan JSON。自然语言编译需配置 OpenAI-compatible API 地址（包含 /v1）和模型名称。插件不会启动、下载或替换生成模型；继续使用自己配置的服务。每次模型请求只包含当前文档块及规则，不带全部历史或 Excel 数据。可能发送 SOP 内容到配置的模型服务；选择远端服务前确认隐私要求。

维护命令从插件根目录运行，也可以先 `pip install .`：

```powershell
Get-Content ./plan.json -Raw | python -m excel_bridge.workflow_cli validate --workspace ./workspace
Get-Content ./plan.json -Raw | python -m excel_bridge.workflow_cli recipe-create --workspace ./workspace
'{"recipe_id":"recipe_..."}' | python -m excel_bridge.workflow_cli recipe-activate --workspace ./workspace
'{}' | python -m excel_bridge.workflow_cli approvals --workspace ./workspace
'{"approval_id":"<审批列表中的编号>","plan_hash":"<该预览的哈希>"}' | python -m excel_bridge.workflow_cli approve --workspace ./workspace
# 管理员已批准后，恢复指定的本地运行（不是 DSH Tool）：
'{"run_id":"<真实运行编号>"}' | python -m excel_bridge.workflow_cli resume --connection-file ./private/bridge-connection.json
python -m excel_bridge.maintenance recover --connection-file ./private/bridge-connection.json --max-tasks 1000 --max-seconds 10
```

## 恢复和限制

可选后台恢复每隔指定秒数处理最多 1000 个 Outbox 任务，单次网络预算 10 秒。退出 DSH 或禁用插件会停止其后台进程。未到退避时间、failed、blocked 不会无限重试。它不自动确认或继续尚未批准的 Procedure。

Procedure 用 SQLite 保存当前步骤、冻结目标和写入前后值。恢复时先处理已有 patch intent，再核对原表。变更无法解释时 blocked，不重放算术。多步骤流程不是跨文件/跨系统事务，已完成写入保留；备份可供明确人工恢复。

本版每个运行只有一个 XLSX，最多 64 步，默认最多 100000 条输入记录；预览数据在 Python/SQLite 中，不进模型 Context。复杂 Excel 对象、宏、公式计算、不一致多 Sheet schema、删除行/列和新增列不属于 Procedure 白名单。基础 excel_patch 的旧能力保持。

语义步骤使用真实 WeKnora FAQ top-50 候选，不能保证全表召回，预览明确标注范围。精确规则在 Python/SQLite 上执行，不用关键词代替模糊语义。Recipe 搜索对最近 2000 个模板做本地词项/中文二元组和字段覆盖评分，最多返回 3 条；模糊候选需要选择。

Procedure 的语义步骤需要配置编译模型，用于按最多 8 条候选/批作相关性判断，每条只发送映射角色的文本（上限 1200 字符）。判断缺失或不合法会停止，不把召回列表全部当成业务命中。Recipe 和 SOP 的 DSH 调用均只给 files 和 instruction；files 为一个 XLSX 加可选的 DOCX/MD/TXT。禁止把内部编号交给模型。编译、运行和同步中的后续调用重复原始参数，后端使用可信会话标识查找检查点。

审批在后端强制执行。所有 Procedure 以及达到 previewThreshold 或跨 Sheet 的直接 patch 都需管理员审批；布尔 confirm 不是授权。审批绑定冻结计划哈希，计划/映射/行/操作变化后须重新预览。管理员 CLI 与 OS/SQLite 写权限属于可信边界，不是对同账户任意 shell 的隔离机制。

SOP 每段最多 1800 字符，最多 128 块、总 200000 字符；过长单段和无法确定的跨段指代需人工拆分或审阅。schema 校验不等于语义正确性：编译器另外做独立有限交叉检查，但用户仍需检查预览。不要把模型的文字承诺当作 Excel 已保存的证据。
