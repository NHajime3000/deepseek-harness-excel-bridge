<!-- Public export: operator-local paths redacted; original evidence stays outside this release. -->
# Excel Workspace / WeKnora 生命周期实施与验收报告

日期：2026-09-08。项目：`<operator-local-path>`。本次保留原有 SQLite Locator、FAQ、Outbox 和三个 DSH Tool，不接入第四个工具、Summary、Ask 或大型 Excel DocReader 上传。

结论：实现和本机部署已完成；全部 65 项回归通过，真实新文件自然语言 query → patch → query 闭环通过。此前失败轮次保留，不能将一次成功解读为 4B 模型对任意表达都稳定正确。

## 1. 交付清单

新增源码：

- `excel_bridge/workspace.py`：文件级 Workspace、建库意图恢复、删除、对账、重新绑定，以及按文件路由的维护 Worker。
- `src/client.js`：DSH Web 设置→插件中的 Excel Bridge 配置卡。
- `tests/workspace_mock.py`、`tests/test_workspace.py`：多 KB 测试服务和 Workspace 回归。
- `scripts/workspace-live-setup.py`：一次性创建独立验收租户、连接和 Embedding 默认配置；**不创建任何文件 KB**。
- `scripts/workspace-live-verify.py`：真实生命周期、离线恢复和源文件/SQLite/FAQ 三方验收。
- `scripts/dsh-workspace-validation.mjs`、`scripts/verify-dsh-settings.mjs`：自然语言会话与真实浏览器设置验收。

修改源码：`config.py`、`storage.py`、`indexer.py`、`outbox.py`、`weknora_client.py`、`service.py`、`maintenance.py`、`patcher.py`、`query.py`、`src/index.js`、`package.json`、`tests/test_outbox.py`、`tests/node_plugin.test.mjs`、`scripts/verify-outbox-migration.py`、`README.md`。

本机部署修改仅限：Web profile 的 Excel Bridge 连接、当前轻量 Agent 的一条 XLSX 规则，以及 `.real_validation/local-stack.json` 的恢复连接路径。未改默认 Qwen、Local LLM Controller、ToolDoc 或原 50,000 行业务表。原 profile/Agent 配置已保存在验收目录的 `profile.before.yml`、`agent.cordis.before.yml`。

## 2. SQLite schema 与 migration

`PRAGMA user_version` 从 0/1 加法迁移到 2。新增 `file_workspaces`，不重建、不清空、不改写原 files、records、Outbox 或 patch_intents。

| 字段组 | 字段与用途 |
| --- | --- |
| 文件身份 | `file_id` 主键；规范化 `file_path` 唯一且不区分大小写；`file_name` |
| 固定目的地 | `base_url`、`tenant_id`、`knowledge_base_id`、`knowledge_base_name` |
| 生命周期 | `kb_status`、`kb_created_by_bridge`、`mode` |
| 建库恢复 | `intent_token`、`phase`（prepared/posting/bound/deleted） |
| 故障 | `error_category`、通用且不含凭据的 `last_error` |
| 移动校验 | `file_hash`，保存已知源文件 SHA-256 |
| 时间 | `created_at`、`updated_at`、`last_indexed_at`、`last_synced_at`、`deleted_at` |

状态约束：creating / ready / syncing / error / orphaned / deleting / deleted。Bridge 所有的非空 KB ID 另有 `(base_url, tenant_id, knowledge_base_id)` 唯一索引。

旧 `bridge_meta.remote_scope` 可以确定旧文件目的地时，迁移为 `mode=legacy`、`kb_created_by_bridge=0`；旧库不因此变成 Bridge 可删除的独占库。没有旧目的地证据的文件不猜测绑定。

真实迁移证据：

- `migration-50000.json`：files=1、records=50000，迁移前后每张旧表的数量与 SHA-256 相同；records 摘要为 `fc3277fd40afd166c6b5e9f35e1e214ac68cc21f634e43087a56ea169969fddc`。
- `migration-outbox.json`：另一个真实库的 records=3、outbox_tasks=4、patch_intents=1，以及 bridge_meta，迁移前后均一致。
- 两个 SQLite 备份分别为 `legacy-50000.pre-workspace.db` 和 `outbox-live.pre-workspace.db`。使用 SQLite backup API，而不是复制正在运行的 WAL 文件。

## 3. ensure_workspace / ensure_index

按规范化路径或已知 file_id 查映射，使用 OS 文件锁串行化建库/写入/Worker。无映射时先提交本地创建意图，再发送远端 POST；远端返回后立即落盘 KB ID。后续全部操作按 ID，而非名称路由。

名称为 `excel_<清洗后的文件名>_<file_id前12位>`，保留中文、截断文件名，不含完整磁盘路径。不同目录中的同名文件有不同 file_id。

`excel_query` 内部自动 ensure：

1. 新文件自动建立 Workspace 和 FAQ KB。
2. 小表流式读入 SQLite，生成 Outbox，批量提交 FAQ。
3. 已注册且 size/mtime 未变时不重扫、不重新向量化，仅恢复未完成同步。
4. 外部变化复用现有 added/updated/deleted/unchanged 机制。
5. 同步未完成返回 `indexing`；不能把未完成索引的空召回当作不存在。

查询的真实 DSH 超时是 60 秒，后端网络预算为 40 秒，锁等待最多 5 秒。新建/变化文件的自动扫描门槛为 1,000 行、2 MB 压缩大小、8 MB 解压总量；超过门槛返回 `indexing_required`，由原有 `excel_index`（一小时超时）完成。没有新增长任务 Tool。

此处 SQLite 的 1,000 行分批是有界内存缓冲，不是“先读完整表再保存”。流式读取、分批 SQL 与事务原子性同时保留。

## 4. 真实 WeKnora API 与权限

核对本机 `<operator-local-path>`、`internal/handler/knowledgebase.go` 和 `internal/types/tenant_api_key.go`，并实际调用：

| 操作 | 接口 |
| --- | --- |
| 创建 FAQ KB | `POST /api/v1/knowledge-bases` |
| 获取 / 查询候选库 | `GET /api/v1/knowledge-bases/{id}` / `GET /api/v1/knowledge-bases` |
| 删除 KB | `DELETE /api/v1/knowledge-bases/{id}` |
| FAQ 批量导入 / 删除 | `POST` / `DELETE /api/v1/knowledge-bases/{id}/faq/entries` |
| 导入进度 | `GET /api/v1/faq/import/progress/{task_id}` |
| 语义查询 | `POST /api/v1/knowledge-bases/{id}/faq/search` |

建库 body 使用 `type=faq`、已配置的 `embedding_model_id`、`faq_config.index_mode=question_only` 和 `question_index_mode=combined`。不需要更新 KB API。

普通运行只使用一个配置好的 tenant/key/model。自动建库要求 `manage_kbs`，检索和内容写入要求 `retrieve` / `ingest`；KB allow-list 不能限定为某个尚未创建的新库。验收仅一次建立 tenant 10007，所有本轮文件复用同一份连接；不是每文件建 tenant。旧 50k 专用 Key 不被扩权或替换。

## 5. 幂等、崩溃与失败恢复

创建前持久化随机 ownership reference（description）和确定性可读名称。POST 后、保存 ID 前崩溃：重启后枚举该租户 KB，只有名称和 ownership reference 均精确、唯一匹配才认领。多个匹配阻止继续；POST 结果未知且列表暂时为空，也不盲目重复 POST。

明确拒绝或连接拒绝可回到 prepared；401/403、缺少 Embedding 等配置问题等待管理员修复。`workspace-reconcile --retry` 保留原意图、重新核对，并不清除 POST 不确定性证据。

真实服务器验收：子进程在 `FAIL_AFTER_KB_CREATE` 以退出码 86 终止，本地 KB ID 仍为空；新进程按 ownership reference 恢复，匹配库始终只有 1 个。

真实停服验收：只停止 `WeKnora-app`，新表 query 返回 workspace_error，创建意图保留为 prepared；恢复同一容器后，query 自动创建 1 个 KB、索引 3 行。没有删除容器或数据卷。

## 6. 文件级隔离与 Outbox

Workspace 模式每个文件创建绑定该 KB 的 client/indexer/query/patcher/worker。不同文件的任务不混入同一远端批次。任务 payload 固定保存 base_url、tenant_id、KB ID；Workspace operation_key 也包含目的地，旧 legacy operation_key 保持不变。

改变当前全局 KB 不会使旧任务改投新库；base URL / tenant 与持久绑定不符时阻止处理。旧异步 task_id、remote_index、旧 entry ID、版本指纹和 posting 检查点全部复用原 Outbox 恢复机制。

真实双文件验证：A、B 对应不同 KB；修改 A 后 B 的 FAQ 完整响应摘要不变；外部只改 A 的一行后，仅这一条 entry ID 被替换，另外两条不变。

## 7. 删除、缺失与移动

`workspace-delete` 先持久化 deleting，阻止该文件后续任务，再确认已提交导入结束并删除远端 KB；确认 404 后标记 deleted。失败仍保留 KB ID。未知异步提交不能确认时阻止删除，不以“先忘掉本地绑定”掩盖失败。

本地 records 保留审计，files 标记 workspace_deleted；未完成 Outbox 标记 superseded。普通 query/patch 不会重新激活 deleted/deleting Workspace。非 Bridge 所有的 legacy KB 拒绝此删除操作。

真实维护 CLI 删除的仅是 `生命周期B.xlsx` 的测试 KB；A 及其他文件不受影响。删除的远端索引可以从保留的原 Excel 重建，但原 KB ID 不可恢复。

源文件消失只标记 orphaned / local_file_missing，绝不自动删 KB。明确 `workspace-rebind` 要求旧路径不存在、新文件 SHA-256 与已保存源摘要完全相同、无路径冲突或未确认写入意图；保留 file_id、record_id 和 KB。副本、内容变化或不明确身份不猜测。

## 8. DSH 配置与自动路由

真实无头 Edge 已确认“设置→插件→Excel Bridge”显示配置卡、Python 路径等字段，API Key 字段类型为 password。通过 UI 关闭，再创建测试会话检查真实 request/header：Excel 工具数量为 0；重新启用后为 3。最终开关已恢复启用。证据为 `settings-verification.json`、`settings.png`。

工具仍只有 `excel_index`、`excel_query`、`excel_patch`。最新 name+description+parameters JSON 合计 **2631 字符**，相比原约 2488 增加 143 字符（约 5.7%）；主要增加写入 value 和 eq/ne 的标量类型约束。最终说明区分“按含义搜索：只填 query、不带 filters”与“匹配已知列值：query 留空、filters 使用标量值”，不再放入具体业务状态示例。

当前轻量 Agent 只新增一条规则：

> 现有 .xlsx 查询用 excel_query：按含义找商品时只填 query、不加 filters；匹配已知列值时用 filters、query 留空。修改用 excel_patch。不要整表读取，未要求导出不另建文件；仅依据工具成功结果报告完成。

没有删除 ToolDoc，其普通文档/明确文档生成能力仍在。默认模型仍为原 `qwen3-4b-thinking-2507.Q4_K_M`；Embedding 仍为独立本机 qwen3-embedding。本次只通过现有 Controller 启动模型，没有修改 Controller 或默认模型配置。

环境核对发现：最终验收时 DSH 声明窗口和文本服务实际 `-c` 参数均为 **16384**（Embedding 服务为 8192），不能把它写成“实测在 8192 服务窗口运行”。本轮实际 Context 压力 4570、预计 4613，均低于用户要求的 8192；没有为验收扩大窗口，也未额外切换模型。

## 9. 真实小模型验收与不掩盖失败

验收根目录：`<operator-local-path>`。完整脱敏事件证据不保存模型隐藏推理或 API Key。

开发期间真实发现并保留了以下失败证据：

- 第一次模型传入对象作为状态值，旧代码把对象 stringify 后写入测试表。已在 Python 和 Tool Schema 双层拒绝复合类型，新增“文件字节完全不变”的回归。
- 修复后模型有时在失败结果之后仍口头声称成功。因此验收必须打开源 XLSX、核对 SQLite 与 FAQ，而非相信助手结尾。
- 模型曾擅自使用 ToolDoc 导出副本，后续操作对象偏移；已补充“未要求导出不另建文件”。
- 模型曾把 `ReviewStatus eq '待评估'` 放进语义 query，产生错误召回。已增加明确过滤表达式拒绝，绝不把 DSL 静默当精确过滤。
- `销售闭环验收.xlsx` 的前两步成功，但第三步反复把对象传给 eq，最终触发输出 max-tokens；这是输出预算耗尽，不是 Context 溢出。随后补充 eq/ne 标量 schema。
- 具体的“待评估”示例又被模型套入首次语义查询，误筛掉新表所有未审核记录。最终移除业务值示例，并平衡语义与精确查询规则；这一修改之后获得下面的完整通过记录。该因果解释是基于调用轨迹的判断，并非随机对照实验结论。

中间一轮 `销售自动路由验收.xlsx` 已实现自动建库、真实 patch 两条及 Outbox 同步：KB=1、FAQ=6、重复=0、completed=8、所有待同步/失败状态=0；但第三轮自然语言精确查询曾误用语义检索，**该中间轮不能单独代表完整自然语言验收通过**。

最终通过：`商品语义闭环.xlsx`，会话 `session-62ae5572-9f83-4190-b497-e56cf0bdca7d`。脱敏原始事件为 `natural-language-balanced.json`，独立事实校验为 `real-workspace-evidence.json` 的 `final` / `agent_acceptance`。

只给模型三条自然语言指令（未出现工具名、KB ID、Tenant 或 API Key）：

1. “请查看 <operator-local-path>
2. “把其中两条标记为待评估。”
3. “再找出这个表里已经标记为待评估的商品。”

| 核验项 | 真实结果 |
| --- | --- |
| 新文件、自动建库 | 测试前匹配 KB=0；首个工具就是 excel_query；之后 KB=1 |
| 工具调用轨迹 | excel_query → excel_patch → excel_query；共 3 次，无 excel_index、ToolDoc 或失败重试 |
| 首次语义结果 | 圣诞木星挂饰、玻璃装饰球共 2 条，Workspace ready |
| 原 XLSX | 前两条 ReviewStatus 为待评估，另四条仍未审核；非模型口头确认 |
| 最后精确查询 | query 为空，filters 为 ReviewStatus eq 待评估；恰好返回这两条 |
| Outbox | completed=8；pending/processing/retry/failed/blocked/superseded 均为 0 |
| 远端 FAQ | 6 条、6 个唯一 record_id，重复 FAQ=0 |
| 三方对账 | remote_checked=6，remote_missing=0，remote_conflicts=0，无错误 |
| Context | pressureTokens=4570，projectedTokens=4613，均小于 8192 |
| Token 构成 | DSH 全部已加载工具估算 2581 tokens，system=111，messages=892；不是仅 Excel 三工具的 token 数 |
| 步骤与耗时 | 3 轮、6 个模型步骤、3 次工具调用；模型累计 20.001 秒，工具累计 6.478 秒（不含用户两轮间等待） |

前面的失败样本与最终通过样本使用不同新文件和独立 KB，均保留供审计。最终表的状态由真实 DSH 模型调用修改，验收脚本没有预先写入“待评估”来制造通过。

### 全量回归与大表保护

Python **61/61**（176.003 秒）和 Node **4/4**，合计 **65/65**。最新工具说明部署后又重跑 Node 四项，均通过。完整 Python 日志为 `regression-final.log`。

50,000 行 mock 接口基准为 89.149 秒，425 条批量 patch 为 0.886 秒，样例查询结果 1265 字符。这些是受控 mock 回归指标，不代表真实 Embedding 吞吐。原 50,000 行数据库完成保留摘要的迁移，未重新执行真实全量向量化。

收尾只读核验：`<operator-local-path>` 的 SHA-256 仍为 `DBA380ECC779288DE64F23B32A563399490D46C63A566B3333B37900BD29622C`，与此前一致。DSH Web（3080）、WeKnora（8080）、文本模型（55555）及 Embedding（55556）健康请求均为 HTTP 200；Excel Bridge 开关为启用。当前 Web 使用本轮隔离验收连接，旧 50k 连接文件保留，并未将其密钥扩权。

## 10. 方法论与边界

方法：先核对实际协议和 timeout，再做加法迁移；先落盘意图再发请求；对不确定状态保守停止；按文件固定目的地；以真实进程退出和真实服务停机验证恢复；以 Excel→SQLite→FAQ 三方事实加模型调用轨迹验收，而不以自然语言“成功”判定。

边界：

- 4B 模型仍可能误选工具/条件或错误口头总结，短规则不能保证所有输入零失误；后端校验和原表/结果复核是必要防线。
- 大文件首次/增量 query 会明确要求 excel_index，不承诺在 60 秒内完成 50k 向量化。
- query 自动更新依赖 size/mtime；人为保持两者不变的外部修改需 force_reindex/对账。
- 移动后同时编辑的文件不能用旧 SHA-256 自动确认身份，需管理员处理。
- 删除是终态，不支持同一映射自动再生；新注册需明确选择新的 SQLite Workspace，避免普通查询复活已删除 KB。
- 服务端无原生幂等键，唯一名称+ownership reference 恢复是补偿策略；未知 POST 且无法唯一确认时仍需维护介入。
- 锁针对本机普通文件系统，不支持多主机共享 SQLite/网络盘并发；需要保持 Excel 在安全回写时可替换。
- 语义召回后过滤不是全表穷举；精确状态用空 query + filters。LLM 的大 limit 被硬上限 20 截断，返回字符数仍受限。
- 未重新向量化原真实 50,000 行；大规模性能来自原完整回归中的 50k mock 接口测试，不能冒称本轮真实 50k 向量化。
- 本轮没有再次重启 Windows；仅验证进程/服务恢复及持久数据库重用。
