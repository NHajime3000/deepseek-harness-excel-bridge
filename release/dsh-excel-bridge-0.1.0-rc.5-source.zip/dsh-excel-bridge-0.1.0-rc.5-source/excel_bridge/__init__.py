"""Lightweight, bounded-context Excel write-back bridge."""

from .config import BridgeConfig, WeknoraConfig
from .service import ExcelBridge

__all__ = ["BridgeConfig", "ExcelBridge", "WeknoraConfig"]
__version__ = "0.1.0"

