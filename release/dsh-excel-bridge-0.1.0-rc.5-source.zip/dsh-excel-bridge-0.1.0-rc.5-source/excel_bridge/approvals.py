"""Durable administrator approvals. This module has no model-facing approval route.

The OS account and admin CLI are trusted, not a sandbox against arbitrary code.
Tool arguments, including confirm=true, cannot grant an approval.
"""
from __future__ import annotations
import hashlib
import json
import time
import uuid

from .locking import bridge_lock
from .plan_ir import PlanError
from .utils import canonical_json


def digest(snapshot):
    return hashlib.sha256(canonical_json(snapshot).encode('utf-8')).hexdigest()


class ApprovalStore:
    def __init__(self, store):
        self.store = store

    @staticmethod
    def _transition(db, approval_id, state, actor):
        db.execute('UPDATE workflow_approvals SET state=? WHERE approval_id=?', (state, approval_id))
        db.execute('INSERT INTO approval_events(approval_id,state,created_at,actor) VALUES (?,?,?,?)',
                   (approval_id, state, time.time(), actor))

    def freeze(self, kind, subject, snapshot, preview):
        plan_hash = digest(snapshot)
        with self.store.connection() as db:
            existing = db.execute('SELECT * FROM workflow_approvals WHERE kind=? AND subject=? AND plan_hash=?',
                                  (kind, subject, plan_hash)).fetchone()
            if existing:
                return dict(existing)
            # A changed plan invalidates every prior approval for this subject.
            for old in db.execute("SELECT approval_id FROM workflow_approvals WHERE kind=? AND subject=? AND state<> 'INVALIDATED'", (kind, subject)).fetchall():
                self._transition(db, old[0], 'INVALIDATED', 'backend')
            aid = 'approval_' + uuid.uuid4().hex
            db.execute('INSERT INTO workflow_approvals VALUES (?,?,?,?,?,?,?,?,?,?)',
                       (aid, kind, subject, plan_hash, canonical_json(snapshot), canonical_json(preview),
                        'PLAN_CREATED', time.time(), None, None))
            for state in ('PLAN_CREATED', 'PREVIEW_READY', 'WAITING_CONFIRMATION'):
                self._transition(db, aid, state, 'backend')
            return dict(db.execute('SELECT * FROM workflow_approvals WHERE approval_id=?', (aid,)).fetchone())

    def list_pending(self):
        with self.store.connection() as db:
            return [{**dict(row), 'preview': json.loads(row['preview_json'])} for row in db.execute(
                "SELECT approval_id,kind,subject,plan_hash,state,preview_json,created_at FROM workflow_approvals WHERE state='WAITING_CONFIRMATION' ORDER BY created_at LIMIT 100")]

    def approve(self, approval_id, plan_hash, *, actor):
        """Administrator-only entry: caller must show and approve the exact hash."""
        if not isinstance(actor, str) or not actor.strip():
            raise PlanError('Approval requires an administrator identity')
        with bridge_lock(self.store), self.store.connection() as db:
            row = db.execute('SELECT * FROM workflow_approvals WHERE approval_id=?', (approval_id,)).fetchone()
            if not row or row['plan_hash'] != plan_hash or digest(json.loads(row['snapshot_json'])) != plan_hash:
                raise PlanError('Approval does not match the frozen plan_hash')
            if row['state'] != 'WAITING_CONFIRMATION':
                raise PlanError('Only the current waiting preview can be approved')
            if row['kind'] == 'procedure' and digest(self.procedure_snapshot(row['subject'])) != plan_hash:
                raise PlanError('Procedure changed after preview; approval rejected')
            self._transition(db, approval_id, 'APPROVED', actor)
            db.execute('UPDATE workflow_approvals SET approved_at=?,approved_by=? WHERE approval_id=?',
                       (time.time(), actor, approval_id))
        return {'status': 'approved', 'approval_id': approval_id, 'plan_hash': plan_hash}

    def procedure_snapshot(self, run_id):
        with self.store.connection() as db:
            run = db.execute('SELECT * FROM procedure_runs WHERE run_id=?', (run_id,)).fetchone()
            if not run:
                raise PlanError('Run not found')
            items = [dict(row) for row in db.execute(
                'SELECT step_id,record_id,before_json,after_json,operation_json FROM procedure_items WHERE run_id=? ORDER BY step_id,record_id', (run_id,))]
            steps = [dict(row) for row in db.execute(
                'SELECT step_id,ordinal,input_summary,output_locator,summary_json FROM procedure_step_runs WHERE run_id=? ORDER BY ordinal', (run_id,))]
        return {'run_id': run_id, 'file_id': run['file_id'], 'source_hash': run['source_hash'],
                'plan': json.loads(run['plan_json']), 'mapping': json.loads(run['mapping_json']),
                'items': items, 'steps': steps}

    def check_procedure(self, run_id, preview):
        snapshot = self.procedure_snapshot(run_id)
        with self.store.connection() as db:
            row = db.execute("SELECT * FROM workflow_approvals WHERE kind='procedure' AND subject=? ORDER BY created_at DESC LIMIT 1", (run_id,)).fetchone()
            if row:
                if row['plan_hash'] != digest(snapshot) and row['state'] != 'INVALIDATED':
                    self._transition(db, row['approval_id'], 'INVALIDATED', 'backend')
                    return {**dict(row), 'state': 'INVALIDATED'}
                return dict(row)
        return self.freeze('procedure', run_id, snapshot, preview)

    def transition(self, approval_id, state):
        with self.store.connection() as db:
            row = db.execute('SELECT state FROM workflow_approvals WHERE approval_id=?', (approval_id,)).fetchone()
            allowed = {'EXECUTING': {'APPROVED', 'EXECUTING'}, 'COMPLETED': {'EXECUTING', 'COMPLETED'},
                       'INVALIDATED': {'PLAN_CREATED', 'PREVIEW_READY', 'WAITING_CONFIRMATION', 'APPROVED', 'EXECUTING'}}
            if not row or row[0] not in allowed.get(state, set()):
                raise PlanError('Invalid approval transition')
            self._transition(db, approval_id, state, 'backend')

    @staticmethod
    def waiting(row):
        if row['state'] == 'INVALIDATED':
            return {'status': 'needs_review', 'approval_state': 'INVALIDATED',
                    'message': '冻结计划或任务已改变，旧审批已失效。请新建预览，不得批准旧预览的修改版本。'}
        return {'status': 'waiting_confirmation', 'approval_state': row['state'],
                'plan_hash': row['plan_hash'],
                'message': '预览已冻结，尚未写入。请通过管理员审批入口批准当前 plan_hash，然后以原 instruction 和 files 继续。'}
