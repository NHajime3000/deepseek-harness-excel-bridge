from __future__ import annotations

import json
import sys
from typing import Any, Callable

from .config import BridgeConfig, MAX_RETURN_CHARS
from .service import ExcelBridge
from .utils import bound_result


def _read_arguments() -> dict[str, Any]:
    raw = sys.stdin.buffer.read(MAX_RETURN_CHARS * 20)
    if not raw:
        return {}
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("tool arguments must be a JSON object")
    return value


def main() -> int:
    # The JSON wire protocol is UTF-8, independent of Windows console code page.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="strict")
    if len(sys.argv) != 2 or sys.argv[1] not in {
        "excel_index",
        "excel_query",
        "excel_patch",
        "procedure_run",
    }:
        print(json.dumps({"status": "error", "error": "unknown tool"}))
        return 2
    try:
        bridge = ExcelBridge(BridgeConfig.from_env())
        handlers: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
            "excel_index": bridge.excel_index,
            "excel_query": bridge.excel_query,
            "excel_patch": bridge.excel_patch,
            "procedure_run": lambda arguments: bridge.procedure_run(arguments, session_key=__import__('os').getenv('EXCEL_BRIDGE_SESSION_KEY')),
        }
        result = bound_result(handlers[sys.argv[1]](_read_arguments()))
        output = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
        if len(output) > MAX_RETURN_CHARS:
            raise RuntimeError("bounded result exceeded MAX_RETURN_CHARS")
        sys.stdout.write(output)
        return 0
    except Exception as error:
        result = bound_result(
            {"status": "error", "error": f"{type(error).__name__}: {error}"}
        )
        sys.stdout.write(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
