from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


DEFAULT_QUERY_LIMIT = 5
MAX_QUERY_LIMIT = 20
MAX_RETURN_CHARS = 12_000
DEFAULT_BATCH_SIZE = 200
MIN_BATCH_SIZE = 100
MAX_BATCH_SIZE = 500


def _optional_env(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    value = value.strip()
    return value or None


def normalize_api_root(raw: str) -> str:
    root = raw.strip().rstrip("/")
    if not root.endswith("/api/v1"):
        root += "/api/v1"
    return root


@dataclass(frozen=True, slots=True)
class WeknoraConfig:
    base_url: str = "http://localhost:8080/api/v1"
    api_key: str | None = None
    tenant_id: str | None = None
    knowledge_base_id: str | None = None
    batch_size: int = DEFAULT_BATCH_SIZE
    request_timeout: float = 30.0
    task_timeout: float = 600.0
    poll_interval: float = 0.5
    vector_threshold: float = 0.3
    enabled: bool = True
    auto_create_kb: bool = True
    embedding_model_id: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "base_url", normalize_api_root(self.base_url))
        if not 0 < self.vector_threshold <= 1:
            raise ValueError("vector_threshold must be > 0 and <= 1 (WeKnora treats 0 as its default)")
        if not MIN_BATCH_SIZE <= self.batch_size <= MAX_BATCH_SIZE:
            raise ValueError(
                f"batch_size must be between {MIN_BATCH_SIZE} and {MAX_BATCH_SIZE}"
            )

    @classmethod
    def from_env(cls) -> "WeknoraConfig":
        enabled = os.environ.get("EXCEL_BRIDGE_WEKNORA_ENABLED", "true").lower() not in {
            "0",
            "false",
            "no",
        }
        return cls(
            base_url=os.environ.get(
                "EXCEL_BRIDGE_WEKNORA_BASE_URL",
                os.environ.get("WEKNORA_BASE_URL", "http://localhost:8080/api/v1"),
            ),
            api_key=_optional_env("EXCEL_BRIDGE_WEKNORA_API_KEY")
            or _optional_env("WEKNORA_API_KEY"),
            tenant_id=_optional_env("EXCEL_BRIDGE_WEKNORA_TENANT_ID")
            or _optional_env("WEKNORA_TENANT_ID"),
            knowledge_base_id=_optional_env("EXCEL_BRIDGE_WEKNORA_KNOWLEDGE_BASE_ID")
            or _optional_env("WEKNORA_KNOWLEDGE_BASE_ID"),
            batch_size=int(
                os.environ.get("EXCEL_BRIDGE_BATCH_SIZE", str(DEFAULT_BATCH_SIZE))
            ),
            request_timeout=float(
                os.environ.get("EXCEL_BRIDGE_REQUEST_TIMEOUT", "30")
            ),
            task_timeout=float(os.environ.get("EXCEL_BRIDGE_TASK_TIMEOUT", "600")),
            poll_interval=float(os.environ.get("EXCEL_BRIDGE_POLL_INTERVAL", "0.5")),
            vector_threshold=float(os.environ.get("EXCEL_BRIDGE_VECTOR_THRESHOLD", "0.3")),
            enabled=enabled,
            auto_create_kb=os.getenv("EXCEL_BRIDGE_AUTO_CREATE_KB", "true").lower() not in {"false", "0"},
            embedding_model_id=_optional_env("EXCEL_BRIDGE_EMBEDDING_MODEL_ID"),
        )


@dataclass(frozen=True, slots=True)
class OutboxConfig:
    max_attempts: int = 8
    retry_delays: tuple[float, ...] = (5, 15, 60, 300, 900)
    lock_timeout: float = 600
    immediate_seconds: float = 600

    def __post_init__(self):
        if (self.max_attempts < 1 or not self.retry_delays or min(self.retry_delays) < 0
                or self.lock_timeout < 0 or self.immediate_seconds <= 0):
            raise ValueError("invalid outbox retry/timeout configuration")

    @classmethod
    def from_env(cls):
        return cls(
            max_attempts=int(os.getenv("EXCEL_BRIDGE_OUTBOX_MAX_ATTEMPTS", "8")),
            retry_delays=tuple(float(v) for v in os.getenv("EXCEL_BRIDGE_OUTBOX_RETRY_DELAYS", "5,15,60,300,900").split(",")),
            lock_timeout=float(os.getenv("EXCEL_BRIDGE_OUTBOX_LOCK_TIMEOUT", "600")),
            immediate_seconds=float(os.getenv("EXCEL_BRIDGE_OUTBOX_IMMEDIATE_SECONDS", "600")),
        )


@dataclass(frozen=True, slots=True)
class WorkflowConfig:
    procedure_enabled: bool = False
    recipe_enabled: bool = False
    preview_threshold: int = 20
    max_records: int = 100000
    steps_per_call: int = 8
    compiler_base_url: str = ''
    compiler_model: str = ''
    compiler_api_key: str | None = None
    compiler_provider: str = 'local_openai_compatible_endpoint'
    compiler_timeout: float = 300
    chunk_chars: int = 1800

    def __post_init__(self):
        if self.compiler_provider not in {'current_dsh_model', 'openai_compatible', 'local_openai_compatible_endpoint', 'disabled', 'manual_review'}:
            raise ValueError('invalid compiler provider')
        if not 1 <= self.preview_threshold <= 10000 or not 1 <= self.max_records <= 1000000:
            raise ValueError('invalid workflow row budget')
        if not 1 <= self.steps_per_call <= 64 or not 200 <= self.chunk_chars <= 2400 or not 1 <= self.compiler_timeout <= 300:
            raise ValueError('invalid workflow execution budget')

    @classmethod
    def from_env(cls):
        return cls(
            procedure_enabled=os.getenv('EXCEL_BRIDGE_PROCEDURE_ENABLED', 'false').lower() == 'true',
            recipe_enabled=os.getenv('EXCEL_BRIDGE_RECIPE_ENABLED', 'false').lower() == 'true',
            preview_threshold=int(os.getenv('EXCEL_BRIDGE_PREVIEW_THRESHOLD', '20')),
            max_records=int(os.getenv('EXCEL_BRIDGE_PROCEDURE_MAX_RECORDS', '100000')),
            steps_per_call=int(os.getenv('EXCEL_BRIDGE_PROCEDURE_STEPS_PER_CALL', '8')),
            compiler_base_url=os.getenv('EXCEL_BRIDGE_COMPILER_BASE_URL', ''),
            compiler_model=os.getenv('EXCEL_BRIDGE_COMPILER_MODEL', ''),
            compiler_api_key=_optional_env('EXCEL_BRIDGE_COMPILER_API_KEY'),
            compiler_provider=os.getenv('EXCEL_BRIDGE_COMPILER_PROVIDER', 'local_openai_compatible_endpoint'),
        )


@dataclass(frozen=True, slots=True)
class BridgeConfig:
    workspace: Path
    weknora: WeknoraConfig
    outbox: OutboxConfig = field(default_factory=OutboxConfig.from_env)
    auto_index_on_query: bool = True
    default_query_limit: int = DEFAULT_QUERY_LIMIT
    query_index_max_rows: int = 1000
    query_budget_seconds: float = 40
    workflow: WorkflowConfig = field(default_factory=WorkflowConfig.from_env)

    def __post_init__(self):
        if not 1 <= self.default_query_limit <= MAX_QUERY_LIMIT or not 0 < self.query_budget_seconds <= 50 or self.query_index_max_rows < 1:
            raise ValueError('invalid query limit/budget configuration')

    @property
    def state_dir(self) -> Path:
        return self.workspace / ".excel_bridge"

    @property
    def database_path(self) -> Path:
        return self.state_dir / "index.db"

    @property
    def backup_dir(self) -> Path:
        return self.state_dir / "backups"

    @classmethod
    def from_env(cls) -> "BridgeConfig":
        workspace = Path(
            os.environ.get("EXCEL_BRIDGE_WORKSPACE", os.getcwd())
        ).expanduser().resolve()
        return cls(workspace=workspace, weknora=WeknoraConfig.from_env(),
                   auto_index_on_query=os.getenv("EXCEL_BRIDGE_AUTO_INDEX_ON_QUERY", "true").lower() not in {"false", "0"},
                   default_query_limit=int(os.getenv("EXCEL_BRIDGE_DEFAULT_QUERY_LIMIT", "5")),
                   query_index_max_rows=int(os.getenv("EXCEL_BRIDGE_QUERY_INDEX_MAX_ROWS", "1000")),
                   query_budget_seconds=float(os.getenv("EXCEL_BRIDGE_QUERY_BUDGET_SECONDS", "40")))
