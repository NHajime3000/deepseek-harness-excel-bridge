"""Tests patch checkpoint(), or opt in to abrupt subprocess termination.

Never part of the DSH tool schema. Both environment flags are required.
"""
import os


def checkpoint(name: str) -> None:
    if (os.environ.get("EXCEL_BRIDGE_TEST_FAULTS") == "1"
            and os.environ.get("EXCEL_BRIDGE_FAIL_AT") == name):
        os._exit(86)
