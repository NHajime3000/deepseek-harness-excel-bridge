from __future__ import annotations

import itertools
import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Iterable, Iterator

from openpyxl import load_workbook

from .models import Record
from .storage import LocatorStore
from .utils import (
    build_content,
    canonical_json,
    canonical_path,
    fingerprint_data,
    is_blank_record,
    make_file_id,
    make_record_id,
    record_key_hash,
    row_data,
    unique_headers,
)
from .weknora_client import WeknoraClient
from .locking import bridge_lock
from .outbox import Outbox
from .faults import checkpoint


KEY_PRIORITY = [
    "id",
    "编号",
    "订单号",
    "invoiceno",
    "invoice",
    "sku",
    "stockcode",
    "customerid",
]


def _normalized_header(value: str) -> str:
    return "".join(character for character in value.casefold() if character.isalnum())


def _candidate_headers(headers: list[str]) -> list[str]:
    normalized = {_normalized_header(header): header for header in headers}
    candidates: list[str] = []
    for name in KEY_PRIORITY:
        header = normalized.get(_normalized_header(name))
        if header and header not in candidates:
            candidates.append(header)
    if candidates:
        for header in headers:
            compact = _normalized_header(header)
            if ("date" in compact or "日期" in compact or "时间" in compact) and header not in candidates:
                candidates.append(header)
    return candidates[:8]


def _candidate_token(value: Any) -> str | None:
    return None if value is None or value == "" else canonical_json(value)


def _discover_key(
    connection: sqlite3.Connection, sheet: str, candidate_count: int
) -> list[int]:
    for width in range(1, min(4, candidate_count) + 1):
        for columns in itertools.combinations(range(candidate_count), width):
            names = [f"c{index}" for index in columns]
            missing = " OR ".join(f"{name} IS NULL" for name in names)
            if connection.execute(
                f"SELECT 1 FROM stage_rows WHERE sheet = ? AND ({missing}) LIMIT 1",
                (sheet,),
            ).fetchone():
                continue
            group = ", ".join(names)
            duplicate = connection.execute(
                f"SELECT 1 FROM stage_rows WHERE sheet = ? GROUP BY {group} HAVING COUNT(*) > 1 LIMIT 1",
                (sheet,),
            ).fetchone()
            if duplicate is None:
                return list(columns)
    return []


def _record_from_stage(row: sqlite3.Row, file_id: str, file_path: str) -> Record:
    return Record(
        record_id=row["record_id"],
        file_id=file_id,
        sheet=row["sheet"],
        row_hint=row["row_hint"],
        record_key=json.loads(row["record_key_json"]),
        record_key_hash=row["record_key_hash"],
        fingerprint=row["fingerprint"],
        data=json.loads(row["data_json"]),
        content=row["content"],
        weknora_document_id=row["weknora_document_id"],
        weknora_chunk_id=row["weknora_chunk_id"],
        weknora_entry_id=row["weknora_entry_id"],
        rag_status=row["rag_status"],
        rag_error=row["rag_error"],
    )


class ExcelIndexer:
    def __init__(self, store: LocatorStore, weknora: WeknoraClient | None, outbox=None):
        self.store = store
        self.weknora = weknora
        self.outbox = outbox or Outbox(store, weknora)

    def index(self, file: str, force_reindex: bool = False, *, defer_sync=False) -> dict[str, Any]:
        with bridge_lock(self.store):
            from .reconcile import recover_patch_intents
            recover_patch_intents(self.store, self.outbox, file_id=self.store.file_id_for_path(Path(file)))
            return self._index(file, force_reindex, defer_sync=defer_sync)

    def _index(self, file: str, force_reindex: bool, *, defer_sync=False) -> dict[str, Any]:
        started = time.perf_counter()
        path = Path(file).expanduser().resolve()
        if path.suffix.casefold() != ".xlsx":
            raise ValueError("excel_index supports .xlsx files only")
        if not path.is_file():
            raise FileNotFoundError(f"Excel file not found: {path}")
        stat = path.stat()
        file_id = self.store.file_id_for_path(path)
        previous = self.store.get_file_by_id(file_id)
        with self.store.connection() as connection:
            needs_sync = self.weknora is not None and connection.execute(
                "SELECT 1 FROM records WHERE file_id=? AND rag_status<>'synced' LIMIT 1",
                (file_id,),
            ).fetchone() is not None
        if (
            previous is not None
            and not force_reindex
            and previous["file_size"] == stat.st_size
            and previous["modified_time_ns"] == stat.st_mtime_ns
        ):
            with self.store.connection() as connection:
                count = connection.execute(
                    "SELECT COUNT(*) FROM records WHERE file_id = ?", (file_id,)
                ).fetchone()[0]
                if needs_sync:
                    for row in connection.execute("SELECT * FROM records WHERE file_id=? AND rag_status<>'synced'", (file_id,)):
                        self.outbox.enqueue(connection, self.store.row_to_record(row), rearm=True)
                tasks = connection.execute("SELECT id,task_type FROM outbox_tasks WHERE file_id=? AND status NOT IN ('completed','superseded')", (file_id,)).fetchall()
            if not defer_sync:
                self.outbox.run_until_idle(file_id=file_id)
            sync = self.outbox.summary([t[0] for t in tasks])
            updated = self.outbox.summary([t[0] for t in tasks if t[1] != 'rag_delete'])["rag_sync"]["completed"]
            return {
                "status": "ok" if not self.weknora or sync["sync_status"] == "synced" else "partial",
                "file": path.name,
                "sheets": len(json.loads(previous["primary_key_json"])),
                "records": count,
                "indexed": updated,
                "added": 0,
                "updated": 0,
                "deleted": 0,
                "unchanged": count,
                **sync,
                "elapsed_seconds": round(time.perf_counter() - started, 3),
            }

        file_path = canonical_path(path)
        with self.store.connection() as connection:
            self._create_stage_tables(connection)
            candidates, sheet_count, total = self._stream_to_stage(connection, path)
            primary_keys = self._finalize_stage(
                connection, file_id, file_path, candidates
            )
            stats = self._change_stats(connection, file_id)
            task_ids = self._enqueue_rag(connection, file_id)
            self.store.upsert_file(
                connection,
                file_id=file_id,
                file_path=file_path,
                file_name=path.name,
                file_size=stat.st_size,
                modified_time_ns=stat.st_mtime_ns,
                status="ready",
                primary_keys=primary_keys,
            )
            connection.execute(
                """
                DELETE FROM records
                WHERE file_id = ?
                  AND record_id NOT IN (SELECT record_id FROM stage_records)
                """,
                (file_id,),
            )
            stage_cursor = connection.execute(
                "SELECT * FROM stage_records ORDER BY sheet, row_hint"
            )
            while rows := stage_cursor.fetchmany(1_000):
                self.store.upsert_records(
                    connection,
                    (_record_from_stage(row, file_id, file_path) for row in rows),
                )
            current = path.stat()
            if (current.st_size, current.st_mtime_ns) != (stat.st_size, stat.st_mtime_ns):
                raise RuntimeError("Excel changed during indexing; local transaction rolled back")

        checkpoint("FAIL_AFTER_SQLITE_UPDATE")
        if not defer_sync:
            self.outbox.run_until_idle(file_id=file_id)
        sync = self.outbox.summary(task_ids)
        synced = sync["rag_sync"]["completed"]

        return {
            "status": "ok" if not self.weknora or sync["sync_status"] == "synced" else "partial",
            "file": path.name,
            "sheets": sheet_count,
            "records": total,
            "indexed": synced if self.weknora is not None else stats["added"] + stats["updated"],
            **stats,
            **sync,
            "elapsed_seconds": round(time.perf_counter() - started, 3),
        }

    @staticmethod
    def _create_stage_tables(connection: sqlite3.Connection) -> None:
        connection.executescript(
            """
            DROP TABLE IF EXISTS temp.stage_rows;
            DROP TABLE IF EXISTS temp.stage_records;
            DROP TABLE IF EXISTS temp.stage_identity;
            CREATE TEMP TABLE stage_rows (
                sheet TEXT NOT NULL,
                row_hint INTEGER NOT NULL,
                data_json TEXT NOT NULL,
                fingerprint TEXT NOT NULL,
                c0 TEXT, c1 TEXT, c2 TEXT, c3 TEXT,
                c4 TEXT, c5 TEXT, c6 TEXT, c7 TEXT,
                PRIMARY KEY(sheet, row_hint)
            );
            CREATE TEMP TABLE stage_records (
                record_id TEXT PRIMARY KEY,
                sheet TEXT NOT NULL,
                row_hint INTEGER NOT NULL,
                record_key_json TEXT NOT NULL,
                record_key_hash TEXT NOT NULL,
                fingerprint TEXT NOT NULL,
                data_json TEXT NOT NULL,
                content TEXT NOT NULL,
                weknora_document_id TEXT,
                weknora_chunk_id TEXT,
                weknora_entry_id INTEGER,
                rag_status TEXT NOT NULL DEFAULT 'pending',
                rag_error TEXT
            );
            CREATE INDEX temp.idx_stage_sheet_fp ON stage_rows(sheet, fingerprint);
            CREATE INDEX temp.idx_stage_records_sheet_fp ON stage_records(sheet, fingerprint);
            CREATE TEMP TABLE stage_identity (
                sheet TEXT NOT NULL,
                row_hint INTEGER NOT NULL,
                occurrence INTEGER NOT NULL,
                record_id TEXT,
                PRIMARY KEY(sheet, row_hint)
            );
            """
        )

    @staticmethod
    def _stream_to_stage(
        connection: sqlite3.Connection, path: Path
    ) -> tuple[dict[str, tuple[list[str], list[str]]], int, int]:
        workbook = load_workbook(path, read_only=True, data_only=False)
        candidates: dict[str, tuple[list[str], list[str]]] = {}
        total = 0
        try:
            for worksheet in workbook.worksheets:
                rows = worksheet.iter_rows(values_only=True)
                try:
                    headers = unique_headers(next(rows))
                except StopIteration:
                    candidates[worksheet.title] = ([], [])
                    continue
                candidate_names = _candidate_headers(headers)
                candidates[worksheet.title] = (headers, candidate_names)
                pending: list[tuple[Any, ...]] = []
                for row_number, values in enumerate(rows, 2):
                    data = row_data(headers, values)
                    if is_blank_record(data):
                        continue
                    tokens = [_candidate_token(data.get(name)) for name in candidate_names]
                    tokens.extend([None] * (8 - len(tokens)))
                    pending.append(
                        (
                            worksheet.title,
                            row_number,
                            canonical_json(data),
                            fingerprint_data(data),
                            *tokens,
                        )
                    )
                    total += 1
                    if len(pending) >= 1_000:
                        connection.executemany(
                            "INSERT INTO stage_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            pending,
                        )
                        pending.clear()
                if pending:
                    connection.executemany(
                        "INSERT INTO stage_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        pending,
                    )
            return candidates, len(workbook.worksheets), total
        finally:
            workbook.close()

    @staticmethod
    def _finalize_stage(
        connection: sqlite3.Connection,
        file_id: str,
        file_path: str,
        candidates: dict[str, tuple[list[str], list[str]]],
    ) -> dict[str, list[str]]:
        primary_keys: dict[str, list[str]] = {}
        previous = connection.execute("SELECT primary_key_json FROM files WHERE file_id=?", (file_id,)).fetchone()
        established = json.loads(previous[0]) if previous else {}
        for sheet, (_headers, candidate_names) in candidates.items():
            if sheet in established:
                key_fields = established[sheet]
                if any(name not in candidate_names for name in key_fields):
                    raise ValueError(f"established business key columns disappeared from sheet {sheet!r}")
                if key_fields:
                    columns = [f"c{candidate_names.index(name)}" for name in key_fields]
                    missing = " OR ".join(f"{name} IS NULL" for name in columns)
                    duplicate = connection.execute(
                        f"SELECT 1 FROM stage_rows WHERE sheet=? GROUP BY {', '.join(columns)} HAVING COUNT(*)>1 LIMIT 1", (sheet,)
                    ).fetchone()
                    blank = connection.execute(f"SELECT 1 FROM stage_rows WHERE sheet=? AND ({missing}) LIMIT 1", (sheet,)).fetchone()
                    if duplicate or blank:
                        raise ValueError(f"established business key is no longer unique/non-empty in sheet {sheet!r}; refusing identity remapping")
            else:
                positions = _discover_key(connection, sheet, len(candidate_names))
                key_fields = [candidate_names[index] for index in positions]
            primary_keys[sheet] = key_fields
            if key_fields:
                cursor = connection.execute(
                    "SELECT * FROM stage_rows WHERE sheet = ? ORDER BY row_hint", (sheet,)
                )
            else:
                # Rank/join on disk, not Python dictionaries of the entire file.
                # Reuse only exact fingerprints. A changed row at the same
                # position is NOT evidence of identity when no business key exists.
                connection.execute(
                    """
                    INSERT INTO stage_identity(sheet, row_hint, occurrence, record_id)
                    WITH incoming AS (
                        SELECT sheet, row_hint, fingerprint,
                            ROW_NUMBER() OVER (PARTITION BY fingerprint ORDER BY row_hint) AS n
                        FROM stage_rows WHERE sheet=?
                    ), existing AS (
                        SELECT record_id, fingerprint,
                            ROW_NUMBER() OVER (PARTITION BY fingerprint ORDER BY row_hint, record_id) AS n
                        FROM records WHERE file_id=? AND sheet=? AND record_key_hash=''
                    )
                    SELECT i.sheet, i.row_hint, i.n, e.record_id FROM incoming i
                    LEFT JOIN existing e ON i.fingerprint=e.fingerprint AND i.n=e.n
                    """, (sheet, file_id, sheet),
                )
                cursor = connection.execute(
                    """
                    SELECT s.*, i.occurrence, i.record_id AS existing_id
                    FROM stage_rows s JOIN stage_identity i
                        ON i.sheet=s.sheet AND i.row_hint=s.row_hint
                    WHERE s.sheet=? ORDER BY s.row_hint
                    """,
                    (sheet,),
                )
            pending: list[tuple[Any, ...]] = []
            for row in cursor:
                data = json.loads(row["data_json"])
                key = {name: data.get(name) for name in key_fields}
                occurrence = 1 if key_fields else int(row["occurrence"])
                record_id: str | None = row["existing_id"] if not key_fields else None
                if record_id is None:
                    record_id = make_record_id(
                        file_id, sheet, key, row["fingerprint"], occurrence
                    )
                    # A previously patched row retains its old ID. If its original
                    # contents reappear, that is a NEW row, not the patched one.
                    collision = 0
                    while not key_fields and connection.execute(
                        "SELECT 1 FROM records WHERE record_id=?", (record_id,)
                    ).fetchone():
                        collision += 1
                        record_id = make_record_id(
                            file_id, sheet, {}, f"{row['fingerprint']}:new:{collision}", occurrence
                        )
                pending.append(
                    (
                        record_id,
                        sheet,
                        row["row_hint"],
                        canonical_json(key),
                        record_key_hash(key),
                        row["fingerprint"],
                        row["data_json"],
                        build_content(record_id, file_path, sheet, key, data),
                    )
                )
                if len(pending) >= 1_000:
                    connection.executemany(
                        """
                        INSERT INTO stage_records(
                            record_id, sheet, row_hint, record_key_json, record_key_hash,
                            fingerprint, data_json, content
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        pending,
                    )
                    pending.clear()
            if pending:
                connection.executemany(
                    """
                    INSERT INTO stage_records(
                        record_id, sheet, row_hint, record_key_json, record_key_hash,
                        fingerprint, data_json, content
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    pending,
                )
        connection.execute(
            """
            UPDATE stage_records
            SET weknora_document_id = (SELECT r.weknora_document_id FROM records r WHERE r.record_id = stage_records.record_id),
                weknora_chunk_id = (SELECT r.weknora_chunk_id FROM records r WHERE r.record_id = stage_records.record_id),
                weknora_entry_id = (SELECT r.weknora_entry_id FROM records r WHERE r.record_id = stage_records.record_id),
                rag_status = COALESCE((SELECT r.rag_status FROM records r WHERE r.record_id = stage_records.record_id), 'pending'),
                rag_error = (SELECT r.rag_error FROM records r WHERE r.record_id = stage_records.record_id)
            WHERE EXISTS (SELECT 1 FROM records r WHERE r.record_id = stage_records.record_id)
            """
        )
        connection.execute("""UPDATE stage_records SET rag_status='pending',rag_error=NULL
            WHERE EXISTS (SELECT 1 FROM records r WHERE r.record_id=stage_records.record_id
                          AND r.fingerprint<>stage_records.fingerprint)""")
        return primary_keys

    @staticmethod
    def _change_stats(connection: sqlite3.Connection, file_id: str) -> dict[str, int]:
        added = connection.execute(
            """SELECT COUNT(*) FROM stage_records s
               LEFT JOIN records r ON r.record_id=s.record_id AND r.file_id=?
               WHERE r.record_id IS NULL""",
            (file_id,),
        ).fetchone()[0]
        updated = connection.execute(
            """SELECT COUNT(*) FROM stage_records s JOIN records r ON r.record_id=s.record_id
               WHERE r.file_id=? AND r.fingerprint<>s.fingerprint""",
            (file_id,),
        ).fetchone()[0]
        unchanged = connection.execute(
            """SELECT COUNT(*) FROM stage_records s JOIN records r ON r.record_id=s.record_id
               WHERE r.file_id=? AND r.fingerprint=s.fingerprint""",
            (file_id,),
        ).fetchone()[0]
        deleted = connection.execute(
            """SELECT COUNT(*) FROM records r LEFT JOIN stage_records s ON s.record_id=r.record_id
               WHERE r.file_id=? AND s.record_id IS NULL""",
            (file_id,),
        ).fetchone()[0]
        return {
            "added": int(added),
            "updated": int(updated),
            "deleted": int(deleted),
            "unchanged": int(unchanged),
        }

    def _enqueue_rag(self, connection: sqlite3.Connection, file_id: str) -> list[str]:
        task_ids = []
        deleted = connection.execute("""SELECT r.* FROM records r LEFT JOIN stage_records s ON s.record_id=r.record_id
            WHERE r.file_id=? AND s.record_id IS NULL""", (file_id,))
        for row in deleted:
            task_ids.append(self.outbox.enqueue(connection, self.store.row_to_record(row), delete=True, rearm=True))
        changed = connection.execute("""SELECT s.* FROM stage_records s LEFT JOIN records r ON s.record_id=r.record_id
            WHERE r.record_id IS NULL OR r.fingerprint<>s.fingerprint OR s.rag_status<>'synced'
            ORDER BY s.sheet,s.row_hint""")
        for row in changed:
            task_ids.append(self.outbox.enqueue(connection, _record_from_stage(row, file_id, ""), rearm=True))
        if self.weknora is None:
            connection.execute(
                "UPDATE stage_records SET rag_status='local_only', rag_error=NULL"
            )
        return task_ids
