"""Local process lock, released by the OS on exit (also serializes XLSX writers).

SQLite leases are durable diagnostics; this lock prevents a still-alive slow
worker from being stolen after its lease expires. No network filesystem support.
"""
from __future__ import annotations

import os
import threading
import time
from contextlib import contextmanager

_held = threading.local()


@contextmanager
def bridge_lock(store, timeout: float = 60):
    path = str(store.path.resolve()) + ".worker.lock"
    held = getattr(_held, "paths", {})
    if path in held:
        yield
        return
    handle = open(path, "a+b")
    if os.stat(path).st_size == 0:
        handle.write(b"0")
        handle.flush()
    deadline = time.monotonic() + timeout
    acquired = False
    try:
        while not acquired:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Excel Bridge writer/worker is busy") from None
                time.sleep(0.05)
        held[path] = True
        _held.paths = held
        yield
    finally:
        if acquired:
            held.pop(path, None)
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()
