"""Internal CLI, deliberately not registered as a DSH tool."""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

from .config import BridgeConfig, WeknoraConfig, OutboxConfig, WorkflowConfig
from .locking import bridge_lock
from .reconcile import reconcile
from .service import ExcelBridge
from .workspace import WorkspaceError


def load_config(connection_file=None, workspace=None):
    if not connection_file:
        from dataclasses import replace
        config = BridgeConfig.from_env()
        return replace(config, workspace=Path(workspace).resolve()) if workspace else config
    source = json.loads(Path(connection_file).read_text(encoding="utf-8-sig"))
    return BridgeConfig(
        workspace=Path(workspace or source.get("workspaceRoot") or Path(connection_file).parent).resolve(),
        weknora=WeknoraConfig(base_url=source.get("baseUrl", "http://127.0.0.1:8080/api/v1"),
                              api_key=source.get("apiKey"), tenant_id=source.get("tenantId"),
                              knowledge_base_id=source.get("knowledgeBaseId"),
                              batch_size=source.get("batchSize", 200),
                              auto_create_kb=source.get('autoCreateKb', True),
                              embedding_model_id=source.get('embeddingModelId'),
                              enabled=source.get('weknoraEnabled', True)),
        auto_index_on_query=source.get('autoIndexOnQuery', True),
        default_query_limit=source.get('defaultQueryLimit', 5),
        outbox=OutboxConfig(max_attempts=source.get('outboxMaxAttempts', 8), immediate_seconds=source.get('outboxImmediateSeconds', 600)),
        workflow=WorkflowConfig(procedure_enabled=source.get('procedureEnabled', False), recipe_enabled=source.get('recipeEnabled', False),
            preview_threshold=source.get('previewThreshold', 20), compiler_base_url=source.get('compilerBaseUrl', ''),
            compiler_model=source.get('compilerModel', ''), compiler_api_key=source.get('compilerApiKey'),
            compiler_provider=source.get('compilerProvider', 'local_openai_compatible_endpoint')))


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8', errors='strict')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("recover", "reconcile", "stats", "retry-blocked", 'workspace-list',
                        'workspace-status', 'workspace-reconcile', 'workspace-delete', 'workspace-rebind'))
    parser.add_argument("--connection-file", default=os.getenv("EXCEL_BRIDGE_CONNECTION_FILE"))
    parser.add_argument("--workspace")
    parser.add_argument("--file")
    parser.add_argument('--new-path')
    parser.add_argument('--retry', action='store_true')
    parser.add_argument("--max-tasks", type=int, default=1000)
    parser.add_argument("--max-seconds", type=float, default=45)
    parser.add_argument("--remote-limit", type=int, default=20)
    args = parser.parse_args()
    logging.basicConfig(level=logging.WARNING, format="%(message)s")
    bridge = ExcelBridge(load_config(args.connection_file, args.workspace))
    if args.command in ('workspace-delete','workspace-rebind','workspace-status') and not args.file:
        parser.error('--file is required for this workspace command')
    if args.command == 'workspace-rebind' and not args.new_path:
        parser.error('--new-path is required')
    if args.command.startswith('workspace-'):
        try:
            if args.command == 'workspace-list':
                result = {'workspaces':bridge.workspaces.list_workspaces()}
            elif args.command == 'workspace-status':
                mapping = bridge.workspaces.get(args.file)
                result = {'workspace': dict(mapping) if mapping else None}
            elif args.command == 'workspace-delete':
                result = bridge.workspaces.delete_workspace(args.file)
            elif args.command == 'workspace-rebind':
                result = bridge.workspaces.rebind(args.file, args.new_path)
            else:
                result = bridge.workspaces.reconcile(args.file, retry=args.retry, max_seconds=args.max_seconds, remote_limit=args.remote_limit)
        except WorkspaceError as error:
            result = error.result(args.file or '')
        print(json.dumps(result, ensure_ascii=False))
        return 0
    mapping = bridge.workspaces.get(args.file) if args.file else None
    file_id = mapping['file_id'] if mapping else bridge.store.resolve_file(args.file)["file_id"] if args.file else None
    if args.command == "stats":
        result = bridge.outbox.get_outbox_stats(file_id)
    elif args.command == "reconcile":
        result = (bridge.workspaces.reconcile(args.file, retry=args.retry, max_seconds=args.max_seconds, remote_limit=args.remote_limit)
                  if bridge.workspace_mode else reconcile(bridge.store, bridge.outbox, file_id=file_id, remote_limit=args.remote_limit, max_seconds=args.max_seconds))
    else:
        if args.command == "retry-blocked":
            # Explicit operator action after correcting credentials/source. Preserve
            # remote task/POST uncertainty checkpoints; never blindly reset phase.
            with bridge_lock(bridge.store), bridge.store.connection() as connection:
                connection.execute("UPDATE outbox_tasks SET status='retry',attempt_count=0,next_retry_at=0 WHERE status IN ('blocked','failed')" +
                                   (" AND file_id=?" if file_id else ""), (file_id,) if file_id else ())
        result = bridge.outbox.run_until_idle(file_id=file_id, max_tasks=args.max_tasks, max_seconds=args.max_seconds)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
