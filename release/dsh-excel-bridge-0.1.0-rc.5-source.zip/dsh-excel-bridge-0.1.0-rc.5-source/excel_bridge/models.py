from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class Record:
    record_id: str
    file_id: str
    sheet: str
    row_hint: int
    record_key: dict[str, Any]
    record_key_hash: str
    fingerprint: str
    data: dict[str, Any]
    content: str
    weknora_document_id: str | None = None
    weknora_chunk_id: str | None = None
    weknora_entry_id: int | None = None
    rag_status: str = "pending"
    rag_error: str | None = None


@dataclass(frozen=True, slots=True)
class LocatedRecord:
    record: Record
    row: int

