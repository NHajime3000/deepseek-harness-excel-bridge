"""Durable, per-record delivery with batched HTTP. No remote I/O in DB transactions."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from contextlib import closing

from .config import OutboxConfig
from .faults import checkpoint
from .locking import bridge_lock
from .storage import utc_now
from .utils import canonical_json
from .weknora_client import WeknoraError

LOG = logging.getLogger(__name__)
TERMINAL = ("completed", "superseded")
STATUSES = ("pending", "processing", "retry", "completed", "failed", "blocked", "superseded")


class Outbox:
    def __init__(self, store, client, config: OutboxConfig | None = None, *, file_id=None):
        self.store, self.client = store, client
        self.config = config or OutboxConfig.from_env()
        self.worker_id = f"{os.getpid()}:{uuid.uuid4().hex}"
        self.file_id = file_id
        self.scoped_identity = False
        self.scope = ({"base_url": client.config.base_url, "tenant_id": client.config.tenant_id,
                       "kb_id": client.config.knowledge_base_id} if client else None)
        with store.connection() as connection:
            if file_id:
                mapping = connection.execute("SELECT * FROM file_workspaces WHERE file_id=?", (file_id,)).fetchone()
                if not mapping:
                    raise ValueError("missing file workspace binding")
                self.saved_scope = {"base_url": mapping['base_url'], "tenant_id": mapping['tenant_id'], "kb_id": mapping['knowledge_base_id']}
                self.scoped_identity = mapping['mode'] == 'workspace'
                return
            if self.scope and self.scope.get('kb_id'):
                connection.execute("INSERT OR IGNORE INTO bridge_meta VALUES ('remote_scope',?)", (canonical_json(self.scope),))
            saved = connection.execute("SELECT value FROM bridge_meta WHERE key='remote_scope'").fetchone()
            self.saved_scope = json.loads(saved[0]) if saved else self.scope

    def enqueue(self, connection, record, *, delete=False, rearm=False):
        kind = "rag_delete" if delete else "rag_replace" if record.weknora_entry_id else "rag_upsert"
        # Treat upsert/replace as the same desired-state operation for deduplication.
        identity = [record.record_id, record.fingerprint, "delete" if delete else "sync"]
        if self.scoped_identity:
            identity.append(self.saved_scope)
        key = hashlib.sha256(canonical_json(identity).encode()).hexdigest()
        payload = {"expected_fingerprint": record.fingerprint, "old_entry_id": record.weknora_entry_id,
                   "target_content": record.content, "phase": "ready", "scope": self.saved_scope}
        existing = connection.execute("SELECT * FROM outbox_tasks WHERE operation_key=?", (key,)).fetchone()
        now = time.time()
        if existing:
            # A -> B -> A and remotely missing completed entries must be repairable.
            # Active/failed/blocked deliveries never silently lose their checkpoints.
            if rearm and existing["status"] in TERMINAL:
                connection.execute("""UPDATE outbox_tasks SET status='pending',payload_json=?,task_type=?,
                    attempt_count=0,next_retry_at=0,last_error=NULL,error_category=NULL,
                    remote_task_id=NULL,remote_entry_id=NULL,completed_at=NULL,locked_at=NULL,worker_id=NULL,
                    created_at=?,updated_at=? WHERE id=?""",
                                   (canonical_json(payload), kind, now, now, existing["id"]))
            return existing["id"]
        task_id = str(uuid.uuid4())
        connection.execute("""INSERT INTO outbox_tasks(id,task_type,record_id,file_id,sheet,operation_key,
            payload_json,status,max_attempts,created_at,updated_at) VALUES (?,?,?,?,?,?,?,'pending',?,?,?)""",
                           (task_id, kind, record.record_id, record.file_id, record.sheet, key,
                            canonical_json(payload), self.config.max_attempts, now, now))
        return task_id

    def get_outbox_stats(self, file_id=None):
        file_id = file_id or self.file_id
        with self.store.connection() as connection:
            rows = connection.execute("SELECT status,COUNT(*) FROM outbox_tasks" +
                                      (" WHERE file_id=?" if file_id else "") + " GROUP BY status",
                                      (file_id,) if file_id else ()).fetchall()
        return {**dict.fromkeys(STATUSES, 0), **dict(rows)}

    def summary(self, task_ids):
        counts = dict.fromkeys(STATUSES, 0)
        with self.store.connection() as connection:
            for offset in range(0, len(task_ids), 400):
                batch = task_ids[offset:offset + 400]
                for row in connection.execute(f"SELECT status,COUNT(*) FROM outbox_tasks WHERE id IN ({','.join('?' for _ in batch)}) GROUP BY status", batch):
                    counts[row[0]] += row[1]
        pending = counts["pending"] + counts["retry"] + counts["processing"]
        failed = counts["failed"] + counts["blocked"]
        completed = counts["completed"]
        return {"sync_status": "synced" if not pending and not failed else "partial" if completed else "failed" if failed and not pending else "pending",
                "rag_sync": {"completed": completed, "pending": pending, "failed": failed}}

    def _update(self, tasks, **fields):
        if not tasks:
            return
        fields["updated_at"] = time.time()
        with self.store.connection() as connection:
            for task in tasks:
                connection.execute(f"UPDATE outbox_tasks SET {','.join(f'{k}=?' for k in fields)} WHERE id=?",
                                   (*fields.values(), task["id"]))
                task.update(fields)

    def _payloads(self, tasks):
        with self.store.connection() as connection:
            for task in tasks:
                raw = canonical_json(task["payload"])
                connection.execute("UPDATE outbox_tasks SET payload_json=?,updated_at=? WHERE id=?",
                                   (raw, time.time(), task["id"]))
                task["payload_json"] = raw

    def recover_processing(self):
        with self.store.connection() as connection:
            return connection.execute("""UPDATE outbox_tasks SET status='retry',next_retry_at=0,
                locked_at=NULL,worker_id=NULL,updated_at=?,last_error='expired worker lease',
                error_category='worker_crash' WHERE status='processing' AND COALESCE(locked_at,0)<?""",
                                      (time.time(), time.time() - self.config.lock_timeout)).rowcount

    def _claim(self, limit, file_id=None, exclude=()):
        with self.store.connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            where = " AND t.file_id=?" if file_id else ""
            parameters = [time.time()] + ([file_id] if file_id else [])
            # Only the oldest unfinished delivery of a record can run. A blocked
            # unknown POST also fences newer versions until explicitly reconciled.
            # Avoid sorting every remaining payload on every batch (quadratic
            # work on a 50k queue). This partial index already has claim order.
            rows = connection.execute("""SELECT t.* FROM outbox_tasks AS t INDEXED BY idx_outbox_ready_order
                WHERE t.status IN ('pending','retry') AND t.next_retry_at<=?""" + where + """
                AND NOT EXISTS (SELECT 1 FROM outbox_tasks o WHERE o.record_id=t.record_id
                    AND o.status NOT IN ('completed','superseded')
                    AND (o.created_at<t.created_at OR (o.created_at=t.created_at AND o.rowid<t.rowid)))
                ORDER BY t.created_at,t.rowid""", parameters)
            tasks = []
            for row in rows:
                if row["id"] in exclude:
                    continue
                tasks.append(dict(row))
                if len(tasks) >= limit:
                    break
            for task in tasks:
                connection.execute("UPDATE outbox_tasks SET status='processing',locked_at=?,worker_id=?,updated_at=? WHERE id=?",
                                   (time.time(), self.worker_id, time.time(), task["id"]))
                task["payload"] = json.loads(task["payload_json"])
            return tasks

    def _error(self, tasks, error):
        category = getattr(error, "category", "internal")
        blocked = category in {"authorization", "not_found", "configuration", "conflict", "ambiguous", "uncertain"}
        # No server body, API key, payload or arbitrary exception text in logs.
        detail = str(error) if isinstance(error, WeknoraError) else f"{type(error).__name__}: local sync failure; inspect source/reconcile"
        if self.client and self.client.config.api_key:
            detail = detail.replace(self.client.config.api_key, "[redacted]")
        with self.store.connection() as connection:
            for task in tasks:
                attempt = task["attempt_count"] + 1
                status = "blocked" if blocked else "failed" if attempt >= task["max_attempts"] else "retry"
                delay = self.config.retry_delays[min(attempt - 1, len(self.config.retry_delays) - 1)]
                connection.execute("""UPDATE outbox_tasks SET status=?,attempt_count=?,next_retry_at=?,last_error=?,
                    error_category=?,locked_at=NULL,worker_id=NULL,updated_at=? WHERE id=?""",
                                   (status, attempt, time.time() + delay, detail[:600], category, time.time(), task["id"]))
                connection.execute("UPDATE records SET rag_status='error',rag_error=? WHERE record_id=? AND fingerprint=?",
                                   (detail[:600], task["record_id"], task["payload"]["expected_fingerprint"]))
                LOG.warning("task_id=%s record_id=%s attempt=%d category=%s status=%s", task["id"], task["record_id"], attempt, category, status)

    def _obsolete(self, task):
        current = self._records.get(task["record_id"])
        return current is not None if task["task_type"] == "rag_delete" else current is None or current.fingerprint != task["payload"]["expected_fingerprint"]

    def _finish(self, task, binding=None):
        self._finish_many([(task, binding)])

    def _finish_many(self, results):
        for task, binding in results:
            if self._obsolete(task) and binding:
                task["payload"]["cleanup_entry_id"] = binding["id"]
                self._payloads([task])
                self.client.delete_entries([binding["id"]])
        with self.store.connection() as connection:
            for task, binding in results:
                self._finish_sql(connection, task, binding)

    def _finish_sql(self, connection, task, binding):
        obsolete = self._obsolete(task)
        if binding and not obsolete:
            connection.execute("""UPDATE records SET weknora_entry_id=?,weknora_document_id=?,weknora_chunk_id=?,
                    rag_status='synced',rag_error=NULL,updated_at=? WHERE record_id=? AND fingerprint=?""",
                                   (binding["id"], binding.get("knowledge_id"), binding.get("chunk_id"), utc_now(),
                                    task["record_id"], task["payload"]["expected_fingerprint"]))
        connection.execute("""UPDATE outbox_tasks SET status=?,completed_at=?,updated_at=?,locked_at=NULL,
                worker_id=NULL,last_error=NULL,error_category=NULL,remote_entry_id=COALESCE(?,remote_entry_id) WHERE id=?""",
                               ("superseded" if obsolete else "completed", time.time(), time.time(),
                                binding["id"] if binding else None, task["id"]))

    def _lookup_uncertain(self, task):
        entries = self.client.find_record_entries(task["record_id"])
        expected = task["payload"]["expected_fingerprint"]
        matches = [e for e in entries if f"fingerprint={expected}" in (e.get("answers") or [])
                   and e.get("standard_question") == task["payload"]["target_content"]]
        if len(entries) == 1 and len(matches) == 1:
            self._finish(task, matches[0])
        else:
            # Absence in a listing does not prove an unknown asynchronous POST
            # cannot still commit. Without a server idempotency key, stop safely.
            raise WeknoraError("unconfirmed POST/progress expired: cannot prove remote outcome; reconcile/operator required",
                               category="uncertain")

    def _poll(self, tasks, deadline):
        task_id = tasks[0]["remote_task_id"]
        while True:
            try:
                progress = self.client.get_import_progress(task_id)
            except WeknoraError as error:
                if error.status == 404:
                    for task in tasks:
                        try:
                            self._lookup_uncertain(task)
                        except Exception as lookup_error:
                            self._error([task], lookup_error)
                    return
                raise
            if progress.get("status") in ("completed", "failed"):
                break
            if time.monotonic() + self.client.config.poll_interval >= deadline:
                self._error(tasks, WeknoraError("remote import still processing", category="remote_pending"))
                return
            time.sleep(self.client.config.poll_interval)
        successes = {item.get("index"): item for item in progress.get("success_entries", []) if isinstance(item, dict)}
        completed = []
        failed = []
        for task in tasks:
            item = successes.get(task["payload"].get("remote_index"))
            if item and isinstance(item.get("seq_id"), int):
                completed.append((task, {"id": item["seq_id"], "knowledge_id": progress.get("knowledge_id")}))
            else:
                failed.append(task)
        self._finish_many(completed)
        for task in failed:
            # Terminal partial failure may have created an entry but failed
            # embedding. Delete only entries owned by THIS record before retry.
            entries = self.client.find_record_entries(task["record_id"])
            self.client.delete_entries([e["id"] for e in entries])
            task["payload"]["phase"] = "deleted"
            task["payload"].setdefault("previous_task_ids", []).append(task_id)
            self._payloads([task])
            self._update([task], remote_task_id=None)
            self._error([task], WeknoraError("terminal import failed for this record", category="remote_failed"))

    def _execute(self, tasks, deadline):
        self._records = self.store.get_records(t["record_id"] for t in tasks)
        ready = []
        groups = {}
        for task in tasks:
            try:
                if (self.scope != self.saved_scope or task["payload"].get("scope") not in (None, self.scope)):
                    raise WeknoraError("configured remote destination differs from persisted destination", category="configuration")
                if task["payload"].get("cleanup_entry_id"):
                    self.client.delete_entries([task["payload"]["cleanup_entry_id"]])
                    self._finish(task)
                elif task["remote_task_id"]:
                    groups.setdefault(task["remote_task_id"], []).append(task)
                elif task["payload"]["phase"] == "posting":
                    self._lookup_uncertain(task)
                elif self._obsolete(task):
                    if task["task_type"] == "rag_delete" and task["payload"].get("old_entry_id") is not None:
                        self.client.delete_entries([task["payload"]["old_entry_id"]])
                    self._finish(task)
                else:
                    ready.append(task)
            except Exception as error:
                self._error([task], error)
        for group in groups.values():
            try:
                self._poll(group, deadline)
            except Exception as error:
                # Completed siblings are not returned to retry after a partial success.
                with self.store.connection() as connection:
                    active = [t for t in group if connection.execute("SELECT status FROM outbox_tasks WHERE id=?", (t["id"],)).fetchone()[0] == "processing"]
                self._error(active, error)
                self._halt = True
        if not ready:
            return
        try:
            self.client.verify_knowledge_base()
            self.client.delete_entries(t["payload"]["old_entry_id"] for t in ready
                                       if t["payload"]["phase"] == "ready" and t["payload"].get("old_entry_id") is not None)
            checkpoint("FAIL_AFTER_REMOTE_DELETE")
            for task in ready:
                task["payload"]["phase"] = "deleted"
            self._payloads(ready)
            creates = []
            for task in ready:
                if task["task_type"] == "rag_delete":
                    self._finish(task)
                else:
                    creates.append(task)
            ready = creates
            if not ready:
                return
            checkpoint("FAIL_BEFORE_REMOTE_CREATE")
            for index, task in enumerate(ready):
                task["payload"].update(phase="posting", remote_index=index)
            self._payloads(ready)
            try:
                remote_id = self.client.start_import([self._records[t["record_id"]] for t in ready])
            except WeknoraError as error:
                if not error.uncertain:
                    for task in ready:
                        task["payload"]["phase"] = "deleted"
                    self._payloads(ready)
                raise
            checkpoint("FAIL_AFTER_REMOTE_ACCEPT_BEFORE_CHECKPOINT")
            self._update(ready, remote_task_id=remote_id)
            checkpoint("FAIL_AFTER_REMOTE_POST")
            self._poll(ready, deadline)
        except Exception as error:
            with self.store.connection() as connection:
                active = [t for t in ready if connection.execute("SELECT status FROM outbox_tasks WHERE id=?", (t["id"],)).fetchone()[0] == "processing"]
            self._error(active, error)
            self._halt = True

    def run_once(self, *, max_tasks=None, max_seconds=None, file_id=None):
        return self.run_until_idle(max_tasks=max_tasks or (self.client.config.batch_size if self.client else 200),
                                   max_seconds=max_seconds, file_id=file_id)

    def run_until_idle(self, *, max_tasks=100000, max_seconds=None, file_id=None):
        file_id = file_id or self.file_id
        if not self.client:
            return {"processed": 0, "disabled": True, **self.get_outbox_stats(file_id)}
        deadline = time.monotonic() + (max_seconds if max_seconds is not None else self.config.immediate_seconds)
        prior_deadline = self.client.deadline
        if prior_deadline:
            deadline = min(deadline, prior_deadline)
        seen = set()
        self._halt = False
        local_report = {}
        try:
            with bridge_lock(self.store, timeout=0), closing(self.store.connect()):
                self.recover_processing()
                # Ensure Excel remains the authority, including interrupted saves.
                from .reconcile import reconcile_local
                local_report = reconcile_local(self.store, self, file_id=file_id, deadline=deadline)
                self.client.deadline = deadline
                while len(seen) < max_tasks and time.monotonic() < deadline:
                    tasks = self._claim(min(self.client.config.batch_size, max_tasks - len(seen)), file_id, seen)
                    if not tasks:
                        break
                    seen.update(t["id"] for t in tasks)
                    self._execute(tasks, min(deadline, time.monotonic() + self.client.config.task_timeout))
                    if self._halt:
                        break
        except TimeoutError:
            return {"processed": 0, "busy": True, **self.get_outbox_stats(file_id)}
        finally:
            self.client.deadline = prior_deadline
        return {"processed": len(seen), **self.get_outbox_stats(file_id), "local_reconcile": local_report}
