from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from .models import Record
from .storage import LocatorStore
from .utils import (
    bound_result,
    build_content,
    canonical_path,
    fingerprint_data,
    json_value,
    make_record_id,
    matches_filters,
    record_key_hash,
    resolve_column,
    row_data,
    unique_headers,
    validate_filters,
    validate_filter_columns,
)
from .weknora_client import WeknoraClient
from .outbox import Outbox
from .locking import bridge_lock
from .faults import checkpoint


SUPPORTED_OPERATIONS = {"set", "numeric_add", "numeric_multiply", "append_column"}


@dataclass(slots=True)
class PlannedOperation:
    column: str
    kind: str
    value: Any


@dataclass(slots=True)
class Target:
    record: Record
    row: int
    operations: list[PlannedOperation] = field(default_factory=list)


def _operation(raw: Any) -> PlannedOperation:
    if not isinstance(raw, dict):
        raise ValueError("operation must be an object")
    column = raw.get("column")
    kind = raw.get("operation", raw.get("type"))
    if not isinstance(column, str) or not column.strip():
        raise ValueError("operation.column is required")
    if kind not in SUPPORTED_OPERATIONS:
        raise ValueError(f"unsupported operation: {kind}")
    if raw.get('value') is not None and not isinstance(raw['value'], (str, int, float, bool)):
        raise ValueError('operation.value must be a string, number, boolean or null; for a text status use the string itself, not an object')
    return PlannedOperation(column=column.strip(), kind=kind, value=raw.get("value"))


def _same(left: Any, right: Any) -> bool:
    return left == right or (str(left).strip() == str(right).strip())


def _locator_matches(data: dict[str, Any], record: Record) -> bool:
    if record.record_key:
        return all(
            (column := resolve_column(data, key)) is not None
            and _same(data[column], expected)
            for key, expected in record.record_key.items()
        )
    return fingerprint_data(data) == record.fingerprint


def _new_value(current: Any, operation: PlannedOperation) -> Any:
    if operation.kind in {"set", "append_column"}:
        return json_value(operation.value)
    if isinstance(current, bool) or not isinstance(current, (int, float)):
        raise ValueError(f"{operation.column} is not numeric")
    if isinstance(operation.value, bool) or not isinstance(operation.value, (int, float)):
        raise ValueError(f"value for {operation.kind} must be numeric")
    if operation.kind == "numeric_add":
        return json_value(current + operation.value)
    return json_value(current * operation.value)


class ExcelPatcher:
    def __init__(
        self,
        store: LocatorStore,
        weknora: WeknoraClient | None,
        backup_dir: Path,
        outbox=None,
    ):
        self.store = store
        self.weknora = weknora
        self.backup_dir = backup_dir
        self.outbox = outbox or Outbox(store, weknora)

    def patch(self, file: str, **kwargs) -> dict[str, Any]:
        with bridge_lock(self.store):
            from .reconcile import recover_patch_intents
            recover_patch_intents(self.store, self.outbox, file_id=self.store.resolve_file(file)["file_id"])
            return self._patch(file, **kwargs)

    def _patch(
        self,
        file: str,
        operations: list[dict[str, Any]] | None = None,
        selector: dict[str, Any] | None = None,
        operation: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        file_row = self.store.resolve_file(file)
        path = Path(file_row["file_path"])
        if path.suffix.casefold() != ".xlsx" or not path.is_file():
            raise FileNotFoundError(f"indexed XLSX source is unavailable: {path}")
        if operations is None:
            operations = []
        if not isinstance(operations, list):
            raise ValueError("operations must be an array")
        if selector is not None and not isinstance(selector, dict):
            raise ValueError("selector must be an object")
        validate_filters(selector)
        if not operations and (not selector or operation is None):
            raise ValueError("provide operations, or selector plus operation")

        source_stat = path.stat()
        workbook = load_workbook(path, read_only=False, data_only=False)
        failures: list[dict[str, Any]] = []
        try:
            sheet_headers = {
                sheet.title: unique_headers(
                    cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))
                )
                for sheet in workbook.worksheets
            }
            targets: dict[tuple[str, int], Target] = {}
            validate_filter_columns(selector, (header for headers in sheet_headers.values() for header in headers))
            self._add_explicit_targets(
                workbook,
                file_row["file_id"],
                sheet_headers,
                operations,
                targets,
                failures,
            )
            if selector:
                if operation is None:
                    raise ValueError("selector requires operation")
                self._add_selector_targets(
                    workbook,
                    file_row,
                    sheet_headers,
                    selector,
                    _operation(operation),
                    targets,
                    failures,
                )

            primary_keys: dict[str, list[str]] = json.loads(file_row["primary_key_json"])
            changes, valid_targets = self._plan_changes(
                workbook, sheet_headers, primary_keys, targets, failures
            )
            summary = {
                "matched": len(targets),
                "sheets": sorted({target.record.sheet for target in valid_targets}),
                "columns": sorted({change["column"] for change in changes}),
                "examples": changes[:5],
                "failed": len(failures),
                "failures": failures[:5],
            }
            if dry_run:
                return bound_result({"status": "preview", **summary})
            if not valid_targets:
                return bound_result(
                    {
                        "status": "error" if failures else "ok",
                        "modified": 0,
                        "reindexed": 0,
                        "backup": None,
                        **summary,
                    }
                )

            self._apply_changes(workbook, sheet_headers, valid_targets)
            updated_records = self._updated_records(
                workbook, sheet_headers, file_row, valid_targets
            )
            from .reconcile import prepare_patch_intent, confirm_patch_intent
            intent_id = prepare_patch_intent(self.store, file_row, updated_records)
            backup = self._safe_save(workbook, path, source_stat)
            checkpoint("FAIL_AFTER_EXCEL_SAVE")
        finally:
            workbook.close()

        # Safe Excel save must never be reported as an unexecuted patch.
        try:
            task_ids = confirm_patch_intent(self.store, self.outbox, intent_id)
            checkpoint("FAIL_AFTER_SQLITE_UPDATE")
            self.outbox.run_until_idle(file_id=file_row["file_id"])
            sync = self.outbox.summary(task_ids)
            rag_error = None
        except Exception as error:
            sync = {"sync_status": "pending", "rag_sync": {"completed": 0, "pending": len(updated_records), "failed": 0}}
            rag_error = f"Excel saved; recovery intent {intent_id} retained ({type(error).__name__})"

        result = {
            "status": "ok" if not rag_error and (not self.weknora or sync["sync_status"] == "synced") else "partial",
            "modified": len(updated_records),
            "failed": len(failures),
            "backup": str(backup),
            "reindexed": sync["rag_sync"]["completed"],
            **sync,
            "sheets": summary["sheets"],
            "columns": summary["columns"],
            "examples": summary["examples"],
            "failures": summary["failures"],
        }
        if rag_error:
            result["rag_error"] = rag_error
        if result["status"] == "partial":
            result["message"] = "Excel 已安全保存；待同步动作已持久保留，运行恢复 Worker，无需重复修改 Excel。"
        return bound_result(result)

    def _add_explicit_targets(
        self,
        workbook: Any,
        file_id: str,
        sheet_headers: dict[str, list[str]],
        operations: list[dict[str, Any]],
        targets: dict[tuple[str, int], Target],
        failures: list[dict[str, Any]],
    ) -> None:
        grouped: dict[str, list[PlannedOperation]] = defaultdict(list)
        for raw in operations:
            if not isinstance(raw, dict) or not isinstance(raw.get("record_id"), str):
                failures.append({"status": "not_found", "error": "record_id is required"})
                continue
            try:
                grouped[raw["record_id"]].append(_operation(raw))
            except ValueError as error:
                failures.append(
                    {"record_id": raw.get("record_id"), "status": "invalid", "error": str(error)}
                )
        records = self.store.get_records(grouped)
        by_sheet: dict[str, list[Record]] = defaultdict(list)
        for record_id, planned in grouped.items():
            record = records.get(record_id)
            if record is None or record.file_id != file_id or record.sheet not in workbook.sheetnames:
                failures.append({"record_id": record_id, "status": "not_found"})
                continue
            by_sheet[record.sheet].append(record)

        # Scan each affected sheet once. row_hint is checked naturally during the
        # scan, but never bypasses the uniqueness check: a newly duplicated key
        # must be reported as ambiguous rather than patched by position.
        for sheet_name, wanted in by_sheet.items():
            sheet = workbook[sheet_name]
            headers = sheet_headers[sheet_name]
            found: dict[str, list[int]] = {record.record_id: [] for record in wanted}
            hint_matched: set[str] = set()
            for record in wanted:
                if 2 <= record.row_hint <= sheet.max_row:
                    hinted_data = row_data(
                        headers, (cell.value for cell in sheet[record.row_hint])
                    )
                    if _locator_matches(hinted_data, record):
                        found[record.record_id].append(record.row_hint)
                        hint_matched.add(record.record_id)
            keyed: dict[tuple[str, ...], dict[str, list[Record]]] = defaultdict(
                lambda: defaultdict(list)
            )
            fingerprinted: dict[str, list[Record]] = defaultdict(list)
            for record in wanted:
                if record.record_key:
                    signature = tuple(record.record_key)
                    keyed[signature][record.record_key_hash].append(record)
                else:
                    fingerprinted[record.fingerprint].append(record)
            for row_number, cells in enumerate(sheet.iter_rows(min_row=2), 2):
                data = row_data(headers, (cell.value for cell in cells))
                for signature, by_hash in keyed.items():
                    current_key = {
                        name: data.get(resolve_column(data, name) or name)
                        for name in signature
                    }
                    for record in by_hash.get(record_key_hash(current_key), []):
                        if (
                            _locator_matches(data, record)
                            and not (
                                record.record_id in hint_matched
                                and row_number == record.row_hint
                            )
                        ):
                            found[record.record_id].append(row_number)
                fingerprint = fingerprint_data(data)
                for record in fingerprinted.get(fingerprint, []):
                    if not (
                        record.record_id in hint_matched and row_number == record.row_hint
                    ):
                        found[record.record_id].append(row_number)
            for record in wanted:
                rows = found[record.record_id]
                if len(rows) != 1:
                    failures.append(
                        {
                            "record_id": record.record_id,
                            "status": "not_found" if not rows else "ambiguous",
                        }
                    )
                    continue
                target = targets.setdefault(
                    (record.sheet, rows[0]), Target(record=record, row=rows[0])
                )
                target.operations.extend(grouped[record.record_id])

    def _add_selector_targets(
        self,
        workbook: Any,
        file_row: Any,
        sheet_headers: dict[str, list[str]],
        selector: dict[str, Any],
        operation: PlannedOperation,
        targets: dict[tuple[str, int], Target],
        failures: list[dict[str, Any]],
    ) -> None:
        primary_keys: dict[str, list[str]] = json.loads(file_row["primary_key_json"])
        with self.store.connection() as connection:
            connection.execute("CREATE TEMP TABLE patch_locators (sheet TEXT, locator TEXT, row_hint INTEGER, selected INTEGER)")
            connection.execute("CREATE INDEX temp.idx_patch_locators ON patch_locators(sheet, locator)")
            for sheet in workbook.worksheets:
                headers = sheet_headers[sheet.title]
                key_fields = primary_keys.get(sheet.title, [])
                pending: list[tuple[Any, ...]] = []
                for row_number, cells in enumerate(sheet.iter_rows(min_row=2), 2):
                    data = row_data(headers, (cell.value for cell in cells))
                    if key_fields:
                        key = {name: data.get(resolve_column(data, name) or name) for name in key_fields}
                        locator = record_key_hash(key)
                    else:
                        locator = fingerprint_data(data)
                    pending.append((sheet.title, locator, row_number, int(matches_filters(data, selector))))
                    if len(pending) >= 1000:
                        connection.executemany("INSERT INTO patch_locators VALUES (?, ?, ?, ?)", pending)
                        pending.clear()
                connection.executemany("INSERT INTO patch_locators VALUES (?, ?, ?, ?)", pending)
                # Count ALL rows sharing the locator, including rows outside
                # the filter. A filter must never hide a duplicated business key.
                selected = connection.execute(
                    """SELECT locator, MIN(CASE WHEN selected=1 THEN row_hint END) AS row_hint, COUNT(*) AS copies
                       FROM patch_locators WHERE sheet=? GROUP BY locator HAVING SUM(selected)>0""",
                    (sheet.title,),
                )
                field = "record_key_hash" if key_fields else "fingerprint"
                for item in selected:
                    stored = connection.execute(
                        f"SELECT * FROM records WHERE file_id=? AND sheet=? AND {field}=? LIMIT 2",
                        (file_row["file_id"], sheet.title, item["locator"]),
                    ).fetchall()
                    row_number = int(item["row_hint"])
                    if len(stored) != 1 or item["copies"] != 1:
                        failures.append(
                            {
                                "sheet": sheet.title,
                                "row": row_number,
                                "status": "not_found" if not stored else "ambiguous",
                            }
                        )
                        continue
                    target = targets.setdefault(
                        (sheet.title, row_number), Target(record=self.store.row_to_record(stored[0]), row=row_number)
                    )
                    target.operations.append(operation)

    @staticmethod
    def _plan_changes(
        workbook: Any,
        sheet_headers: dict[str, list[str]],
        primary_keys: dict[str, list[str]],
        targets: dict[tuple[str, int], Target],
        failures: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[Target]]:
        changes: list[dict[str, Any]] = []
        valid_targets: list[Target] = []
        for target in targets.values():
            sheet = workbook[target.record.sheet]
            headers = sheet_headers[target.record.sheet]
            virtual = row_data(headers, (cell.value for cell in sheet[target.row]))
            valid_operations: list[PlannedOperation] = []
            for planned in target.operations:
                existing = resolve_column(virtual, planned.column)
                if any(
                    planned.column.casefold() == key.casefold()
                    for key in primary_keys.get(target.record.sheet, [])
                ):
                    failures.append(
                        {
                            "record_id": target.record.record_id,
                            "status": "invalid",
                            "error": "business key columns cannot be patched in the MVP",
                        }
                    )
                    continue
                if planned.kind == "append_column" and existing is not None:
                    failures.append(
                        {
                            "record_id": target.record.record_id,
                            "status": "invalid",
                            "error": f"column already exists: {planned.column}",
                        }
                    )
                    continue
                column = existing or planned.column
                current = virtual.get(column)
                try:
                    updated = _new_value(current, planned)
                except ValueError as error:
                    failures.append(
                        {
                            "record_id": target.record.record_id,
                            "status": "invalid",
                            "error": str(error),
                        }
                    )
                    continue
                if existing is None:
                    virtual[column] = current
                virtual[column] = updated
                valid_operations.append(planned)
                changes.append(
                    {
                        "record_id": target.record.record_id,
                        "sheet": target.record.sheet,
                        "row": target.row,
                        "column": column,
                        "old": current,
                        "new": updated,
                    }
                )
            target.operations = valid_operations
            if valid_operations:
                valid_targets.append(target)
        return changes, valid_targets

    @staticmethod
    def _apply_changes(
        workbook: Any,
        sheet_headers: dict[str, list[str]],
        targets: list[Target],
    ) -> None:
        column_maps: dict[str, dict[str, int]] = {
            sheet: {name: index for index, name in enumerate(headers, 1)}
            for sheet, headers in sheet_headers.items()
        }
        for target in targets:
            sheet = workbook[target.record.sheet]
            mapping = column_maps[target.record.sheet]
            for planned in target.operations:
                existing = next(
                    (name for name in mapping if name.casefold() == planned.column.casefold()),
                    None,
                )
                if existing is None:
                    existing = planned.column
                    mapping[existing] = len(mapping) + 1
                    sheet_headers[target.record.sheet].append(existing)
                    sheet.cell(row=1, column=mapping[existing], value=existing)
                cell = sheet.cell(row=target.row, column=mapping[existing])
                cell.value = _new_value(cell.value, planned)

    def _safe_save(self, workbook: Any, path: Path, source_stat: os.stat_result) -> Path:
        def unchanged() -> None:
            current = path.stat()
            if (current.st_size, current.st_mtime_ns) != (source_stat.st_size, source_stat.st_mtime_ns):
                raise RuntimeError("Excel changed during patch; refusing to overwrite concurrent edits")
        unchanged()
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        backup = self.backup_dir / f"{path.stem}.{stamp}{path.suffix}"
        shutil.copy2(path, backup)
        handle, temporary_name = tempfile.mkstemp(
            prefix=f".{path.stem}.excel-bridge-", suffix=path.suffix, dir=path.parent
        )
        os.close(handle)
        temporary = Path(temporary_name)
        try:
            workbook.save(temporary)
            unchanged()
            # Windows readers may briefly hold a handle without delete sharing.
            # Persistent Excel locks still fail; concurrent edits never get overwritten.
            for attempt in range(4):
                try:
                    unchanged()
                    os.replace(temporary, path)
                    break
                except PermissionError:
                    if attempt == 3:
                        raise
                    time.sleep(0.15 * (attempt + 1))
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return backup

    @staticmethod
    def _updated_records(
        workbook: Any,
        sheet_headers: dict[str, list[str]],
        file_row: Any,
        targets: list[Target],
    ) -> list[Record]:
        updated: list[Record] = []
        seen: set[str] = set()
        for target in targets:
            if target.record.record_id in seen:
                continue
            seen.add(target.record.record_id)
            sheet = workbook[target.record.sheet]
            data = row_data(
                sheet_headers[target.record.sheet],
                (cell.value for cell in sheet[target.row]),
            )
            fingerprint = fingerprint_data(data)
            record = target.record
            record.row_hint = target.row
            record.data = data
            record.fingerprint = fingerprint
            record.content = build_content(
                record.record_id,
                file_row["file_path"],
                record.sheet,
                record.record_key,
                data,
            )
            updated.append(record)
        return updated
