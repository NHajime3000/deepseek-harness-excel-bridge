"""Versioned, data-only workflow IR. No eval, code, paths or old row locators."""
from __future__ import annotations

import json
import math
import re
from .utils import matches_filters, validate_filters

STEP_TYPES = {'filter', 'semantic_query', 'select', 'aggregate', 'branch', 'patch',
              'verify', 'export_summary', 'user_confirm'}
IDENTIFIER = re.compile(r'^[A-Za-z][A-Za-z0-9_]{0,63}$')
SCALAR = (str, int, float, bool, type(None))


class PlanError(ValueError):
    pass


def scalar(value):
    if not isinstance(value, SCALAR) or (isinstance(value, float) and not math.isfinite(value)):
        raise PlanError('Expected a finite scalar value')
    if isinstance(value, str) and len(value) > 1000:
        raise PlanError('Scalar text exceeds 1000 characters')


def validate_condition(condition, roles, depth=0):
    if depth > 8 or not isinstance(condition, dict) or not condition:
        raise PlanError('Invalid or overly nested condition')
    if any(k in condition for k in ('all', 'any', 'not')):
        if len(condition) != 1:
            raise PlanError('Logical condition must have one operator')
        key, value = next(iter(condition.items()))
        if key == 'not':
            validate_condition(value, roles, depth + 1)
        else:
            if not isinstance(value, list) or not 1 <= len(value) <= 20:
                raise PlanError('all/any require a bounded nonempty list')
            for item in value:
                validate_condition(item, roles, depth + 1)
        return
    if set(condition) - set(roles):
        raise PlanError('Condition references an undeclared field role')
    validate_filters(condition)
    for constraint in condition.values():
        for operator, value in (constraint.items() if isinstance(constraint, dict) else [('eq', constraint)]):
            if operator not in {'eq', 'ne', 'lt', 'lte', 'gt', 'gte', 'in', 'between', 'contains'}:
                raise PlanError('Unknown condition operator')
            for member in value if isinstance(value, list) else [value]:
                scalar(member)


def condition_matches(data, condition, mapping):
    if 'all' in condition:
        return all(condition_matches(data, c, mapping) for c in condition['all'])
    if 'any' in condition:
        return any(condition_matches(data, c, mapping) for c in condition['any'])
    if 'not' in condition:
        return not condition_matches(data, condition['not'], mapping)
    translated = {mapping[role]: value for role, value in condition.items()}
    # Numeric comparisons never fall back to lexicographic ordering.
    for column, constraints in translated.items():
        if isinstance(constraints, dict):
            for op, expected in constraints.items():
                if op in {'lt', 'lte', 'gt', 'gte', 'between'}:
                    if isinstance(data.get(column), bool) or not isinstance(data.get(column), (int, float)):
                        raise PlanError('Numeric condition encountered nonnumeric data')
                    for number in expected if isinstance(expected, list) else [expected]:
                        if isinstance(number, bool) or not isinstance(number, (int, float)):
                            raise PlanError('Numeric condition requires numeric constants')
    return matches_filters(data, translated)


def validate_plan(plan):
    if not isinstance(plan, dict) or set(plan) - {'ir_version', 'name', 'intent', 'required_roles', 'parameters', 'steps'}:
        raise PlanError('Unknown plan fields; file/row/record/KB locators are not templates')
    if plan.get('ir_version') != 1 or not isinstance(plan.get('name'), str) or not 1 <= len(plan['name']) <= 120:
        raise PlanError('Plan requires ir_version=1 and a bounded name')
    if len(json.dumps(plan, ensure_ascii=False)) > 64000:
        raise PlanError('Plan exceeds 64000 characters')
    roles = plan.get('required_roles')
    if not isinstance(roles, list) or not 1 <= len(roles) <= 40 or len(set(roles)) != len(roles):
        raise PlanError('required_roles must be unique and nonempty')
    if any(not isinstance(r, str) or not IDENTIFIER.fullmatch(r) for r in roles):
        raise PlanError('Invalid field role identifier')
    params = plan.get('parameters', {})
    if not isinstance(params, dict) or len(params) > 40:
        raise PlanError('Invalid parameters')
    for key, value in params.items():
        if not IDENTIFIER.fullmatch(key):
            raise PlanError('Invalid parameter name')
        scalar(value)
    steps = plan.get('steps')
    if not isinstance(steps, list) or not 1 <= len(steps) <= 64:
        raise PlanError('Plan must contain 1 to 64 steps')
    known = {'input'}
    ids = set()
    wrote = False
    fields = {
        'filter': {'condition'}, 'semantic_query': {'query', 'role'},
        'select': {'roles', 'limit'}, 'aggregate': {'metric', 'role'},
        'branch': {'condition', 'then', 'else'}, 'patch': {'role', 'operation', 'value'},
        'verify': {'condition', 'min_count', 'max_count'},
        'export_summary': set(), 'user_confirm': {'message'},
    }
    for step in steps:
        if not isinstance(step, dict) or step.get('type') not in STEP_TYPES:
            raise PlanError('Unknown step type')
        kind, sid = step['type'], step.get('id')
        if kind == 'semantic_query' and wrote:
            raise PlanError('Semantic steps must precede writes; preview cannot search a not-yet-updated index')
        wrote = wrote or kind == 'patch'
        if not isinstance(sid, str) or not IDENTIFIER.fullmatch(sid) or sid in known or sid in ids:
            raise PlanError('Duplicate or invalid step ID')
        if set(step) - ({'id', 'type', 'source'} | fields[kind]):
            raise PlanError('Unknown step fields')
        sources = step.get('source', 'input')
        sources = sources if isinstance(sources, list) else [sources]
        if not sources or any(not isinstance(s, str) or s not in known for s in sources):
            raise PlanError('Source must reference an earlier output; cycles/forward references forbidden')
        if kind in {'filter', 'branch'} or (kind == 'verify' and 'condition' in step):
            validate_condition(step.get('condition'), roles)
        if kind in {'patch', 'semantic_query'} and step.get('role') not in roles:
            raise PlanError('Step references an undeclared role')
        if kind == 'semantic_query' and (not isinstance(step.get('query'), str) or not 1 <= len(step['query']) <= 1000):
            raise PlanError('Semantic search requires bounded query text')
        if kind == 'patch':
            if step.get('operation') not in {'set', 'numeric_add', 'numeric_multiply'} or 'value' not in step:
                raise PlanError('Procedure patch allows set/add/multiply on existing columns only')
            scalar(step['value'])
            if isinstance(step['value'], str) and step['value'].lstrip().startswith('='):
                raise PlanError('Formula injection is not permitted in Procedure writes')
        if kind == 'select':
            if set(step.get('roles', [])) - set(roles):
                raise PlanError('Unknown select role')
            if 'limit' in step and (type(step['limit']) is not int or not 1 <= step['limit'] <= 100000):
                raise PlanError('Invalid select limit')
        if kind == 'aggregate':
            if step.get('metric') not in {'count', 'sum', 'min', 'max', 'mean'}:
                raise PlanError('Unknown aggregate metric')
            if step['metric'] != 'count' and step.get('role') not in roles:
                raise PlanError('Numeric aggregate needs a role')
        if kind == 'verify':
            for key in ('min_count', 'max_count'):
                if key in step and (type(step[key]) is not int or step[key] < 0):
                    raise PlanError('Invalid verification count')
        if kind == 'branch':
            if 'then' not in step or 'else' not in step or step['then'] == step['else']:
                raise PlanError('Branch requires distinct then/else targets')
            known.update({sid + '.then', sid + '.else'})
        known.add(sid)
        ids.add(sid)
    for step in steps:
        if step['type'] == 'branch':
            for port in ('then', 'else'):
                target = next((s for s in steps if s['id'] == step[port]), None)
                if target is None or target.get('source') != step['id'] + '.' + port:
                    raise PlanError('Branch target must consume its corresponding partition')
    return plan


def bind_parameters(plan, overrides=None):
    plan = json.loads(json.dumps(validate_plan(plan)))
    params = {**plan.get('parameters', {}), **(overrides or {})}
    if set(params) - set(plan.get('parameters', {})):
        raise PlanError('Unknown parameter override')
    def replace(value):
        if isinstance(value, str) and re.fullmatch(r'\$\{[A-Za-z][A-Za-z0-9_]*\}', value):
            key = value[2:-1]
            if key not in params:
                raise PlanError('Missing parameter')
            scalar(params[key])
            return params[key]
        if isinstance(value, list):
            return [replace(v) for v in value]
        if isinstance(value, dict):
            return {k: replace(v) for k, v in value.items()}
        return value
    plan['steps'] = replace(plan['steps'])
    return validate_plan(plan)
