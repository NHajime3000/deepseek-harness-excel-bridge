"""Persistent preview-first executor for validated data-only workflow plans."""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from pathlib import Path

from .faults import checkpoint
from .locking import bridge_lock
from .patcher import PlannedOperation, _new_value
from .plan_ir import PlanError, bind_parameters, condition_matches
from .recipes import RecipeMemory
from .reconcile import file_hash, recover_patch_intents
from .utils import canonical_json, extract_record_id, fingerprint_data
from .approvals import ApprovalStore


class ProcedureEngine:
    def __init__(self, bridge, *, semantic_reviewer=None):
        self.bridge, self.store, self.config = bridge, bridge.store, bridge.config.workflow
        self.memory = RecipeMemory(self.store)
        from .sop import SopCompiler
        self.semantic_reviewer = semantic_reviewer or SopCompiler(self.store, self.config).review_candidates

    def _components(self, file):
        if self.bridge._managed(file):
            mapping = self.bridge.workspaces.ensure_workspace(file)
            indexer, querier, patcher, outbox = self.bridge.workspaces.components(mapping)
            return indexer, querier, patcher, outbox
        return self.bridge.indexer, self.bridge.querier, self.bridge.patcher, self.bridge.outbox

    def _records(self, file_id):
        with self.store.connection() as db:
            count = db.execute('SELECT COUNT(*) FROM records WHERE file_id=?', (file_id,)).fetchone()[0]
            if count > self.config.max_records:
                raise PlanError('Procedure input exceeds configured max_records; no writes performed')
            return {r['record_id']: {'data': json.loads(r['data_json']), 'sheet': r['sheet']}
                    for r in db.execute('SELECT record_id,data_json,sheet FROM records WHERE file_id=? ORDER BY sheet,row_hint', (file_id,))}

    def _columns(self, records):
        return sorted({c for r in records.values() for c in r['data']})

    def prepare(self, file, plan, *, mapping=None, parameters=None, recipe_id=None, procedure_id=None, source_type='manual'):
        plan = bind_parameters(plan, parameters)
        file = str(Path(file).expanduser().resolve())
        with bridge_lock(self.store):
            if self.bridge._managed(file):
                _, indexed, components = self.bridge.workspaces.ensure_index(file)
                indexer, querier, patcher, outbox = components
            else:
                indexer, querier, patcher, outbox = self._components(file)
                indexed = indexer.index(file)
            if indexed.get('status') not in {'ok', 'partial'}:
                return indexed
            file_row = self.store.resolve_file(file)
            records = self._records(file_row['file_id'])
            columns = self._columns(records)
            resolved = self.memory.resolve(plan['required_roles'], columns, mapping)
            if resolved['status'] != 'mapped':
                return {**resolved, 'available_columns': columns[:40], 'message': '请确认角色对应的真实列；未修改 Excel。'}
            mapping = resolved['mapping']
            # A union of headers across sheets is not sufficient for safe mapping.
            if any(set(mapping.values()) - set(r['data']) for r in records.values()):
                return {'status': 'needs_mapping', 'message': '所选工作表结构不一致；请提供结构一致的输入表。'}
            source_hash = file_hash(file)
            run_id = 'run_' + uuid.uuid4().hex
            selections = {'input': list(records)}
            summaries, items, all_modified = [], [], set()
            risks, examples, affected_columns, affected_sheets = [], [], set(), set()
            write_steps = 0
            for position, step in enumerate(plan['steps']):
                sid, kind = step['id'], step['type']
                sources = step.get('source', 'input')
                sources = sources if isinstance(sources, list) else [sources]
                chosen = list(dict.fromkeys(rid for src in sources for rid in selections[src]))
                input_count = len(chosen)
                summary = {'step': sid, 'type': kind, 'input_count': input_count}
                if kind in {'filter', 'verify'}:
                    matching = [rid for rid in chosen if condition_matches(records[rid]['data'], step.get('condition', {'any': [{plan['required_roles'][0]: {'ne': None}}, {plan['required_roles'][0]: None}]}), mapping)]
                    if kind == 'verify':
                        if len(matching) != len(chosen) or not step.get('min_count', 0) <= len(chosen) <= step.get('max_count', self.config.max_records):
                            raise PlanError('Verification failed during preview: ' + sid)
                        summary['verified'] = True
                    else:
                        chosen = matching
                elif kind == 'semantic_query':
                    if querier.weknora is None:
                        raise PlanError('Semantic procedure steps require WeKnora')
                    stats = outbox.get_outbox_stats(file_row['file_id'])
                    if any(stats[s] for s in ('pending', 'processing', 'retry', 'failed', 'blocked')):
                        return {'status': 'indexing', 'message': '语义索引同步尚未完成；恢复后重新预览。'}
                    hits = querier.weknora.search(step['query'], 50)
                    candidates = []
                    for hit in hits:
                        rid = extract_record_id(hit.get('standard_question'), hit.get('answers'), hit.get('matched_question'))
                        if not rid and isinstance(hit.get('id'), int):
                            record = self.store.find_by_entry_id(file_row['file_id'], hit['id'])
                            rid = record.record_id if record else None
                        if rid in chosen and rid not in candidates:
                            candidates.append(rid)
                    texts = [records[rid]['data'][mapping[step['role']]] for rid in candidates]
                    chosen = [candidates[i] for i in self.semantic_reviewer(step['query'], texts)]
                    summary['recalled_count'] = len(candidates)
                    summary['semantically_reviewed'] = True
                    summary.update(candidate_limit=50, scope='semantic_candidates_not_exhaustive')
                    risks.append('semantic_top_50_not_exhaustive')
                elif kind == 'branch':
                    yes = [rid for rid in chosen if condition_matches(records[rid]['data'], step['condition'], mapping)]
                    yes_set = set(yes)
                    selections[sid + '.then'] = yes
                    selections[sid + '.else'] = [rid for rid in chosen if rid not in yes_set]
                    summary.update(then_count=len(yes), else_count=len(chosen)-len(yes))
                elif kind == 'select':
                    chosen = chosen[:step.get('limit', self.config.max_records)]
                elif kind == 'patch':
                    write_steps += 1
                    column = mapping[step['role']]
                    operation = PlannedOperation(column, step['operation'], step['value'])
                    for rid in chosen:
                        before = dict(records[rid]['data'])
                        after = {**before, column: _new_value(before[column], operation)}
                        changed = fingerprint_data(before) != fingerprint_data(after)
                        if changed:
                            all_modified.add(rid)
                            affected_columns.add(column)
                            affected_sheets.add(records[rid]['sheet'])
                            if len(examples) < 3:
                                examples.append({'sheet': records[rid]['sheet'], 'column': column, 'old': before[column], 'new': after[column]})
                        # Frozen per-record before/after images allow recovery without re-applying arithmetic.
                        items.append((run_id, sid, rid, canonical_json(before), canonical_json(after),
                                      canonical_json({'record_id': rid, 'column': column, 'operation': step['operation'], 'value': step['value']})))
                        records[rid]['data'] = after
                    summary['planned_count'] = len(chosen)
                    if step['operation'] != 'set' or step['role'] in {'amount', 'price'}:
                        risks.append('numeric_or_monetary_write')
                elif kind == 'aggregate':
                    metric = step['metric']
                    if metric == 'count':
                        value = len(chosen)
                    else:
                        values = [records[rid]['data'][mapping[step['role']]] for rid in chosen]
                        if any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in values):
                            raise PlanError('Aggregate encountered nonnumeric values')
                        value = (sum(values) if metric == 'sum' else min(values) if metric == 'min' else max(values) if metric == 'max' else sum(values)/len(values)) if values else None
                    summary.update(metric=metric, value=value)
                elif kind == 'user_confirm':
                    risks.append('explicit_confirmation_step')
                elif kind == 'export_summary':
                    summary['format'] = 'json'
                selections[sid] = chosen
                summary['output_count'] = len(chosen)
                summaries.append(summary)
            if len(all_modified) > self.config.preview_threshold:
                risks.append('bulk_write')
            if write_steps > 1:
                risks.append('multi_step_write')
            if len(affected_sheets) > 1:
                risks.append('multi_sheet_write')
            if file_hash(file) != source_hash:
                raise PlanError('Source changed during preview')
            preview = {'status': 'preview', 'run_id': run_id, 'name': plan['name'], 'file': Path(file).name,
                       'matched': len(all_modified), 'sheets': sorted(affected_sheets), 'columns': sorted(affected_columns),
                       'mapping': mapping, 'risks': sorted(set(risks)), 'examples': examples,
                       'steps': summaries[:8], 'step_count': len(summaries),
                       'message': '尚未修改 Excel。需要管理员批准冻结预览，再使用原任务说明和文件继续。'}
            pid = procedure_id or 'procedure_' + uuid.uuid4().hex
            now = time.time()
            with self.store.connection() as db:
                if not procedure_id:
                    db.execute('INSERT INTO procedures VALUES (?,?,?,?,?,?,?,?,?)',
                               (pid, plan['name'], 1, canonical_json(plan), source_type, None, 'validated', now, now))
                db.execute('INSERT INTO procedure_runs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                           (run_id, pid, file_row['file_id'], 'preview', 0, canonical_json(plan), canonical_json(resolved),
                            canonical_json(preview), canonical_json({'file_hash': source_hash}), source_hash, None, now, now, None))
                db.executemany('INSERT INTO procedure_step_runs VALUES (?,?,?,?,?,?,?,?,?,?)',
                               [(run_id, s['step'], i, 'pending', canonical_json({'count': s['input_count']}),
                                 run_id + '/' + s['step'], canonical_json(s), None, None, None)
                                for i, s in enumerate(summaries)])
                db.executemany('INSERT INTO procedure_items VALUES (?,?,?,?,?,?)', items)
                db.execute("INSERT INTO procedure_items SELECT ?,'input',record_id,data_json,data_json,NULL FROM records WHERE file_id=?",
                           (run_id, file_row['file_id']))
                if recipe_id:
                    recipe = self.memory.get(recipe_id)
                    db.execute('INSERT INTO recipe_runs VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                               (run_id, recipe_id, recipe['version'], file_row['file_id'], 'preview', canonical_json(mapping),
                                canonical_json(preview), None, now, None, None))
            approval = ApprovalStore(self.store).check_procedure(run_id, preview)
            return {**preview, **ApprovalStore.waiting(approval)}

    def status(self, run_id):
        with self.store.connection() as db:
            run = db.execute('SELECT * FROM procedure_runs WHERE run_id=?', (run_id,)).fetchone()
            if run is None:
                raise PlanError('Run not found')
            steps = db.execute('SELECT step_id,status,summary_json FROM procedure_step_runs WHERE run_id=? ORDER BY ordinal', (run_id,)).fetchall()
        preview = json.loads(run['preview_json'])
        return {'status': run['status'], 'run_id': run_id, 'current_step': run['current_step'], 'step_count': len(steps),
                'modified': preview['matched'] if run['status'] in {'completed', 'syncing'} else None,
                'steps_completed': sum(s['status'] == 'completed' for s in steps),
                'recent_steps': [{'id': s['step_id'], 'status': s['status'], **json.loads(s['summary_json'])} for s in steps[-3:]],
                'error': run['error']}

    def resume(self, run_id, *, confirm=False):
        with bridge_lock(self.store):
            with self.store.connection() as db:
                row = db.execute('SELECT * FROM procedure_runs WHERE run_id=?', (run_id,)).fetchone()
            if row is None:
                raise PlanError('Run not found')
            run = dict(row)
            if run['status'] == 'completed':
                return self.status(run_id)
            if run['status'] in {'blocked', 'failed'}:
                return self.status(run_id)
            approvals = ApprovalStore(self.store)
            preview = json.loads(run['preview_json'])
            approval = approvals.check_procedure(run_id, preview)
            # confirm is retained only for source compatibility. It grants nothing.
            if approval['state'] not in {'APPROVED', 'EXECUTING'}:
                return {**preview, **approvals.waiting(approval)}
            file_row = self.store.get_file_by_id(run['file_id'])
            if not file_row:
                raise PlanError('Run source mapping is missing')
            file = file_row['file_path']
            indexer, querier, patcher, outbox = self._components(file)
            recover_patch_intents(self.store, outbox, run['file_id'])
            with self.store.connection() as db:
                steps = db.execute('SELECT * FROM procedure_step_runs WHERE run_id=? ORDER BY ordinal', (run_id,)).fetchall()
            pending = [s for s in steps if s['status'] != 'completed']
            expected_hash = json.loads(run['checkpoint_json'])['file_hash']
            actual_hash = file_hash(file)
            # Only a running write with all expected postimages can justify a hash change.
            recovering = bool(pending and pending[0]['status'] == 'running')
            if actual_hash != expected_hash and not recovering:
                return self._block(run_id, 'Source changed since preview/checkpoint; create a new preview')
            if actual_hash != expected_hash and recovering:
                # Verify the whole row set, not just patch targets: an unrelated
                # external edit must not be hidden by a matching target postimage.
                indexer.index(file, force_reindex=True, defer_sync=True)
                current_all = self._records(run['file_id'])
                with self.store.connection() as db:
                    expected_all = {r['record_id']: r['after_json'] for r in db.execute(
                        "SELECT record_id,after_json FROM procedure_items WHERE run_id=? AND step_id='input'", (run_id,))}
                    for done in steps[:pending[0]['ordinal'] + 1]:
                        for target in db.execute('SELECT record_id,after_json FROM procedure_items WHERE run_id=? AND step_id=?', (run_id, done['step_id'])):
                            expected_all[target['record_id']] = target['after_json']
                if set(current_all) != set(expected_all) or any(fingerprint_data(current_all[rid]['data']) != fingerprint_data(json.loads(expected_all[rid])) for rid in expected_all):
                    return self._block(run_id, 'Interrupted write source differs from frozen row set')
            if run['status'] == 'preview':
                approvals.transition(approval['approval_id'], 'EXECUTING')
                self.memory.confirm_mapping(json.loads(run['mapping_json']))
                with self.store.connection() as db:
                    db.execute("UPDATE procedure_runs SET status='running',confirmation_hash=?,updated_at=? WHERE run_id=?",
                               (approval['plan_hash'], time.time(), run_id))
            plan = json.loads(run['plan_json'])
            for step_row in pending[:self.config.steps_per_call]:
                sid = step_row['step_id']
                step = plan['steps'][step_row['ordinal']]
                with self.store.connection() as db:
                    targets = db.execute('SELECT * FROM procedure_items WHERE run_id=? AND step_id=?', (run_id, sid)).fetchall()
                    db.execute("UPDATE procedure_step_runs SET status='running',started_at=COALESCE(started_at,?) WHERE run_id=? AND step_id=?", (time.time(), run_id, sid))
                if step['type'] == 'patch' and targets:
                    current = self.store.get_records(t['record_id'] for t in targets)
                    before_ok = all(t['record_id'] in current and current[t['record_id']].fingerprint == fingerprint_data(json.loads(t['before_json'])) for t in targets)
                    after_ok = all(t['record_id'] in current and current[t['record_id']].fingerprint == fingerprint_data(json.loads(t['after_json'])) for t in targets)
                    if file_hash(file) != expected_hash:
                        if step_row['status'] != 'running' or not after_ok:
                            return self._block(run_id, 'Cannot prove interrupted write; inspect source and patch intent')
                        # Require an actual completed existing patch intent, not merely similar cell values.
                        with self.store.connection() as db:
                            proof = db.execute("SELECT 1 FROM patch_intents WHERE file_id=? AND status='completed' AND created_at>=? LIMIT 1",
                                               (run['file_id'], step_row['started_at'] or run['created_at'])).fetchone()
                        if not proof:
                            return self._block(run_id, 'No durable patch evidence for changed workbook')
                    elif before_ok:
                        result = patcher.patch(file, operations=[json.loads(t['operation_json']) for t in targets])
                        checkpoint('PROCEDURE_AFTER_PATCH_' + str(step_row['ordinal'] + 1))
                        if result.get('failed', 0) or result.get('status') not in {'ok', 'partial'}:
                            return self._block(run_id, 'Patch failed; previously completed steps are retained')
                        current = self.store.get_records(t['record_id'] for t in targets)
                        if not all(t['record_id'] in current and current[t['record_id']].fingerprint == fingerprint_data(json.loads(t['after_json'])) for t in targets):
                            return self._block(run_id, 'Saved patch differs from the frozen preview')
                    elif not after_ok:
                        return self._block(run_id, 'Record version no longer matches preview')
                expected_hash = file_hash(file)
                with self.store.connection() as db:
                    db.execute("UPDATE procedure_step_runs SET status='completed',completed_at=? WHERE run_id=? AND step_id=?", (time.time(), run_id, sid))
                    db.execute('UPDATE procedure_runs SET current_step=?,checkpoint_json=?,updated_at=? WHERE run_id=?',
                               (step_row['ordinal'] + 1, canonical_json({'file_hash': expected_hash}), time.time(), run_id))
                checkpoint('PROCEDURE_AFTER_STEP_' + str(step_row['ordinal'] + 1))
            status = self.status(run_id)
            if status['steps_completed'] < status['step_count']:
                return {**status, 'approval_state': 'EXECUTING', 'message': '检查点已保存；使用原任务说明和文件继续。'}
            outbox.run_until_idle(file_id=run['file_id'], max_seconds=10)
            stats = outbox.get_outbox_stats(run['file_id'])
            synced = not any(stats[s] for s in ('pending', 'processing', 'retry', 'failed', 'blocked'))
            final_status = 'completed' if synced or outbox.client is None else 'syncing'
            if self.bridge._managed(file):
                self.bridge.workspaces._update(run['file_id'], kb_status='ready' if synced else 'syncing',
                                               file_hash=expected_hash, last_synced_at=time.time() if synced else None)
            with self.store.connection() as db:
                db.execute('UPDATE procedure_runs SET status=?,updated_at=? WHERE run_id=?', (final_status, time.time(), run_id))
                recipe_run = db.execute('SELECT * FROM recipe_runs WHERE run_id=?', (run_id,)).fetchone()
                origin = db.execute('SELECT source_type FROM procedures WHERE procedure_id=?', (run['procedure_id'],)).fetchone()
                if (not recipe_run and synced and self.config.recipe_enabled and origin['source_type'] == 'sop'
                        and json.loads(run['preview_json'])['matched'] > 0):
                    template = json.loads(run['plan_json'])
                    template['parameters'] = {}
                    for i, step in enumerate(template['steps']):
                        if step['type'] == 'patch':
                            key = 'write_value_' + str(i)
                            template['parameters'][key] = step['value']
                            step['value'] = '${' + key + '}'
                    rid = self.memory.create(template, 'sop', connection=db)
                    db.execute('INSERT INTO recipe_runs VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                               (run_id, rid, 1, run['file_id'], 'running', run['mapping_json'], run['preview_json'],
                                None, run['created_at'], None, None))
                    recipe_run = db.execute('SELECT * FROM recipe_runs WHERE run_id=?', (run_id,)).fetchone()
                if recipe_run and recipe_run['status'] != 'completed' and synced:
                    db.execute("UPDATE recipe_runs SET status='completed',completed_at=?,result_json=? WHERE run_id=?", (time.time(), canonical_json(status), run_id))
                    db.execute('UPDATE recipes SET success_count=success_count+1,last_used_at=?,updated_at=? WHERE recipe_id=?', (time.time(), time.time(), recipe_run['recipe_id']))
                    count = db.execute("SELECT COUNT(DISTINCT file_id) FROM recipe_runs WHERE recipe_id=? AND status='completed'", (recipe_run['recipe_id'],)).fetchone()[0]
                    if count >= 2:
                        db.execute("UPDATE recipes SET status='active' WHERE recipe_id=?", (recipe_run['recipe_id'],))
            # Export only summaries to a derived, fixed internal path. No user-controlled output path.
            output_dir = self.bridge.config.state_dir / 'procedures'
            output_dir.mkdir(exist_ok=True)
            result = {**self.status(run_id), 'outbox': stats,
                      'sync_status': 'local_only' if outbox.client is None else 'synced' if synced else 'pending'}
            if final_status == 'completed':
                approvals.transition(approval['approval_id'], 'COMPLETED')
            result['approval_state'] = 'COMPLETED' if final_status == 'completed' else 'EXECUTING'
            (output_dir / (run_id + '.json')).write_text(canonical_json(result), encoding='utf-8')
            return result

    def _block(self, run_id, error):
        with self.store.connection() as db:
            for approval in db.execute("SELECT approval_id FROM workflow_approvals WHERE kind='procedure' AND subject=? AND state NOT IN ('COMPLETED','INVALIDATED')", (run_id,)).fetchall():
                ApprovalStore._transition(db, approval['approval_id'], 'INVALIDATED', 'blocked_run')
            recipe = db.execute('SELECT recipe_id,status FROM recipe_runs WHERE run_id=?', (run_id,)).fetchone()
            if recipe and recipe['status'] not in {'blocked', 'failed', 'completed'}:
                db.execute('UPDATE recipes SET failure_count=failure_count+1,updated_at=? WHERE recipe_id=?', (time.time(), recipe['recipe_id']))
            db.execute("UPDATE procedure_runs SET status='blocked',error=?,updated_at=? WHERE run_id=?", (error, time.time(), run_id))
            db.execute("UPDATE recipe_runs SET status='blocked',error=? WHERE run_id=?", (error, run_id))
        return self.status(run_id)
