from __future__ import annotations

import json
import re
from typing import Any, Iterable

from .config import DEFAULT_QUERY_LIMIT, MAX_QUERY_LIMIT
from .models import Record
from .storage import LocatorStore
from .utils import bound_result, extract_record_id, matches_filters, resolve_column, validate_filters, validate_filter_columns
from .weknora_client import WeknoraClient


DISPLAY_PRIORITY = [
    "Description",
    "名称",
    "商品名称",
    "ReviewStatus",
    "状态",
    "Quantity",
    "数量",
    "Price",
    "价格",
    "Country",
    "国家",
]


def _bounded_limit(value: Any) -> int:
    if value is None:
        return DEFAULT_QUERY_LIMIT
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValueError("limit must be a positive integer")
    return min(value, MAX_QUERY_LIMIT)


def _project_data(
    record: Record, query: str, filters: dict[str, Any] | None
) -> dict[str, Any]:
    selected: list[str] = []
    key_names = set(record.record_key)

    def add(requested: str) -> None:
        column = resolve_column(record.data, requested)
        if column and column not in key_names and column not in selected:
            selected.append(column)

    for requested in (filters or {}):
        add(requested)
    folded_query = query.casefold()
    for column in record.data:
        if column.casefold() in folded_query:
            add(column)
    for column in DISPLAY_PRIORITY:
        add(column)
    for column, value in record.data.items():
        if value is not None and value != "":
            add(column)
        if len(selected) >= 8:
            break
    projected: dict[str, Any] = {}
    for column in selected[:8]:
        value = record.data[column]
        if isinstance(value, str) and len(value) > 800:
            value = value[:797] + "..."
        projected[column] = value
    return projected


class ExcelQuery:
    def __init__(self, store: LocatorStore, weknora: WeknoraClient | None):
        self.store = store
        self.weknora = weknora

    def query(
        self,
        file: str,
        query: str,
        filters: dict[str, Any] | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        actual_limit = _bounded_limit(limit)
        validate_filters(filters)
        if re.fullmatch(r'\s*\w+\s*(?:==|=|\b(?:eq|ne|lt|lte|gt|gte)\b)\s*(?:[\'"][^\'"\r\n]*[\'"]|[-+]?\d+(?:\.\d+)?)\s*', query, flags=re.IGNORECASE):
            raise ValueError('query accepts semantic text, not a filter expression. For exact conditions use query="" and filters with the actual column name and value.')
        file_row = self.store.resolve_file(file)
        if filters:
            # Include fields added by a partial patch, not just the first row's
            # old schema. SQLite enumerates keys without loading row data in Python.
            with self.store.connection() as connection:
                columns = connection.execute(
                    "SELECT DISTINCT j.key FROM records r, json_each(r.data_json) j WHERE r.file_id=?", (file_row["file_id"],)
                )
                validate_filter_columns(filters, (row[0] for row in columns))
        if filters is not None and not isinstance(filters, dict):
            raise ValueError("filters must be an object")
        matches: list[dict[str, Any]] = []
        if query.strip():
            if self.weknora is None:
                raise ValueError("semantic query requires WeKnora configuration")
            candidate_count = min(200, max(actual_limit * 20, 50 if filters else actual_limit))
            hits = self.weknora.search(query.strip(), candidate_count)
            seen: set[str] = set()
            for hit in hits:
                record_id = extract_record_id(
                    hit.get("standard_question"),
                    hit.get("matched_question"),
                    hit.get("answers"),
                )
                record: Record | None = None
                if record_id:
                    record = self.store.get_record(record_id)
                if record is None and isinstance(hit.get("id"), int):
                    record = self.store.find_by_entry_id(file_row["file_id"], hit["id"])
                if (
                    record is None
                    or record.file_id != file_row["file_id"]
                    or record.record_id in seen
                    or not matches_filters(record.data, filters)
                ):
                    continue
                seen.add(record.record_id)
                matches.append(self._project_match(record, query, filters, hit.get("score", 0)))
                if len(matches) >= actual_limit:
                    break
        else:
            if not filters:
                raise ValueError("query cannot be empty unless filters are provided")
            with self.store.connection() as connection:
                cursor = connection.execute(
                    "SELECT * FROM records WHERE file_id = ? ORDER BY sheet, row_hint",
                    (file_row["file_id"],),
                )
                for row in cursor:
                    record = self.store.row_to_record(row)
                    if matches_filters(record.data, filters):
                        matches.append(self._project_match(record, query, filters, 1.0))
                        if len(matches) >= actual_limit:
                            break
        result = {
            "status": "ok",
            "file": file_row["file_name"],
            "count": len(matches),
            "limit": actual_limit,
            "matches": matches,
        }
        if query.strip() and filters and not matches:
            result["note"] = 'No matches in WeKnora top-50 candidates. This does not prove absence; use query="" for exact filter-only lookup.'
        return bound_result(result)

    @staticmethod
    def _project_match(
        record: Record,
        query: str,
        filters: dict[str, Any] | None,
        score: Any,
    ) -> dict[str, Any]:
        numeric_score = score if isinstance(score, (int, float)) else 0
        return {
            "record_id": record.record_id,
            "sheet": record.sheet,
            "row_hint": record.row_hint,
            "key": record.record_key,
            "data": _project_data(record, query, filters),
            "score": round(float(numeric_score), 6),
        }
