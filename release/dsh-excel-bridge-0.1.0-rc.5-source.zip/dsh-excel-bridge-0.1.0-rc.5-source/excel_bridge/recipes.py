"""Local recipe templates, conservative role mapping and success-gated history."""
from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from contextlib import nullcontext
from difflib import SequenceMatcher

from .plan_ir import validate_plan, PlanError
from .utils import canonical_json

ROLE_ALIASES = {
    'complaint_text': ['ComplaintText', '客户投诉描述', '客诉内容', '客诉描述', '投诉内容', '客户反馈'],
    'review_status': ['ReviewStatus', '处理状态', '审核标记', '处理标记', '复核状态'],
    'product_description': ['Description', 'ProductDescription', '商品描述', '产品描述', '商品名称'],
    'order_status': ['OrderStatus', '订单状态'], 'order_id': ['OrderID', '订单编号'],
    'price': ['Price', 'UnitPrice', '价格', '单价'], 'amount': ['Amount', '金额', '退款金额'],
    'quantity': ['Quantity', '数量'], 'country': ['Country', '国家'],
    'customer_id': ['CustomerID', '客户编号'],
}


def normalized(value):
    return re.sub(r'[\s_\-]+', '', value).casefold()


def schema_hash(columns):
    return hashlib.sha256(canonical_json(sorted(columns)).encode()).hexdigest()


def intent_tokens(text):
    """Small auditable search lexicon, not an executable business-rule substitute.

    Remove transport paths and reuse boilerplate. Synonyms only rank templates;
    actual semantic row selection still uses WeKnora plus candidate review.
    """
    text = re.sub(r'[A-Za-z]:[/\\][^\s，。；]+', ' ', text.casefold())
    topics = {
        'logistics': ['物流延迟','配送异常','快递丢件','配送途中丢失','物流','配送','快递','丢件','延迟','logistics','shipping','delivery'],
        'complaint': ['投诉','客诉','complaint'],
        'quality': ['商品质量','产品质量','质量','quality'],
        'refund': ['退款','退货','refund','return'],
        'inventory': ['库存','存货','inventory','stock'],
        'invoice': ['发票','开票','invoice'],
        'tax': ['税务','税金','tax'],
        'budget': ['预算','budget'],
        'fraud': ['欺诈','诈骗','fraud'],
    }
    words = set()
    for topic, aliases in topics.items():
        for alias in sorted(aliases, key=len, reverse=True):
            if alias in text:
                words.add(topic)
                text = text.replace(alias, ' ')
    for phrase in ['按上次','上一次','上次','以前','历史','之前','沿用','复用','的方式','的办法','的方法','处理方式','处理方法','这个表格','这个表','这张表','新表','处理','复核','请','按照','按','same as','last time','previous','reuse','review']:
        text = text.replace(phrase, ' ')
    words.update(re.findall(r'[a-z0-9_]+', text))
    for phrase in re.findall(r'[\u3400-\u9fff]+', text):
        words.update(phrase[i:i+2] for i in range(max(1,len(phrase)-1)))
    return words


def role_for(column):
    for role, aliases in ROLE_ALIASES.items():
        if normalized(column) in {normalized(a) for a in [role, *aliases]}:
            return role
    # Unknown roles are reusable only by exact header, never guessed synonyms.
    return 'field_' + hashlib.sha256(column.encode()).hexdigest()[:12]


class RecipeMemory:
    def __init__(self, store):
        self.store = store
        with store.connection() as db:
            db.executemany('INSERT OR IGNORE INTO field_roles VALUES (?,?)',
                           [(r, canonical_json(a)) for r, a in ROLE_ALIASES.items()])

    def resolve(self, roles, columns, supplied=None):
        columns = sorted(set(columns))
        supplied = supplied or {}
        if not isinstance(supplied, dict) or set(supplied) - set(roles):
            raise PlanError('Mapping contains unknown roles')
        with self.store.connection() as db:
            aliases = {r[0]: json.loads(r[1]) for r in db.execute('SELECT * FROM field_roles')}
            historical = {r['role']: r['column_name'] for r in db.execute(
                'SELECT * FROM field_mappings WHERE schema_hash=?', (schema_hash(columns),))}
        mapping, unresolved, evidence = {}, {}, {}
        for role in roles:
            if role in supplied:
                choices = [supplied[role]] if supplied[role] in columns else []
                source = 'explicit'
            elif historical.get(role) in columns:
                choices, source = [historical[role]], 'confirmed_history'
            else:
                names = {normalized(a) for a in [role, *aliases.get(role, [])]}
                choices = [c for c in columns if normalized(c) in names]
                source = 'exact_alias'
            if len(choices) == 1:
                mapping[role], evidence[role] = choices[0], source
            else:
                # Similarity is a suggestion, not write authorization.
                suggestions = sorted(columns, key=lambda c: SequenceMatcher(None, normalized(role), normalized(c)).ratio(), reverse=True)[:3]
                unresolved[role] = choices or suggestions
        if len(set(mapping.values())) != len(mapping):
            raise PlanError('Two distinct roles mapped to the same column; review required')
        return {'status': 'needs_mapping' if unresolved else 'mapped', 'mapping': mapping,
                'unresolved': unresolved, 'evidence': evidence, 'schema_hash': schema_hash(columns)}

    def confirm_mapping(self, resolved):
        with self.store.connection() as db:
            db.executemany('INSERT OR REPLACE INTO field_mappings VALUES (?,?,?,?,?)',
                           [(resolved['schema_hash'], role, column, 'preview_confirmed', time.time())
                            for role, column in resolved['mapping'].items()])

    def create(self, plan, source_type='manual', status='draft', *, connection=None):
        validate_plan(plan)
        if status != 'draft':
            raise PlanError('New templates always start as draft')
        rid, now = 'recipe_' + uuid.uuid4().hex, time.time()
        with nullcontext(connection) if connection is not None else self.store.connection() as db:
            db.execute('INSERT INTO recipes VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                       (rid, plan['name'], plan.get('intent', ''), plan.get('intent', plan['name']), source_type,
                        'draft', now, now, None, 0, 0))
            db.execute('INSERT INTO recipe_versions VALUES (?,?,?,?,?,?,?)',
                       (uuid.uuid4().hex, rid, 1, canonical_json(plan), canonical_json(plan['required_roles']),
                        canonical_json(plan.get('parameters', {})), now))
        return rid

    def get(self, recipe_id):
        with self.store.connection() as db:
            row = db.execute('SELECT r.*,v.version,v.plan_json FROM recipes r JOIN recipe_versions v USING(recipe_id) '
                             'WHERE r.recipe_id=? AND r.status<>? ORDER BY v.version DESC LIMIT 1', (recipe_id, 'archived')).fetchone()
        if row is None:
            raise PlanError('Recipe not found')
        return dict(row)

    def activate(self, recipe_id):
        self.get(recipe_id)
        with self.store.connection() as db:
            db.execute("UPDATE recipes SET status='active',updated_at=? WHERE recipe_id=?", (time.time(), recipe_id))

    def search(self, intent, columns, limit=3):
        wanted = intent_tokens(intent)
        with self.store.connection() as db:
            rows = db.execute("SELECT r.*,v.plan_json,v.version FROM recipes r JOIN recipe_versions v USING(recipe_id) "
                              "WHERE r.status IN ('draft','active') AND v.version=(SELECT MAX(version) FROM recipe_versions WHERE recipe_id=r.recipe_id) "
                              'ORDER BY r.updated_at DESC LIMIT 2000').fetchall()
        candidates = []
        for row in rows:
            plan = json.loads(row['plan_json'])
            terms = intent_tokens(row['name'] + ' ' + row['intent'])
            if 'complaint_text' in plan['required_roles']:
                terms.add('complaint')
            overlap = len(wanted & terms)
            if not overlap:
                continue
            resolved = self.resolve(plan['required_roles'], columns)
            # Both query coverage and candidate specificity matter: a long,
            # unrelated template mentioning one matching topic is not confident.
            lexical = .5 * overlap / max(1, len(wanted)) + .5 * overlap / max(1, len(terms))
            coverage = len(resolved['mapping']) / len(plan['required_roles'])
            candidates.append({'recipe_id': row['recipe_id'], 'name': row['name'], 'status': row['status'],
                               'score': round(0.75 * lexical + 0.25 * coverage, 3),
                               'mapping_status': resolved['status'], 'required_roles': plan['required_roles']})
        return sorted(candidates, key=lambda c: (-c['score'], c['name']))[:min(3, max(1, limit))]

    def remember_query(self, file_id, args, result):
        if result.get('status') != 'ok' or not result.get('matches'):
            return
        with self.store.connection() as db:
            db.execute('INSERT OR REPLACE INTO recipe_query_context VALUES (?,?,?,?)',
                       (file_id, canonical_json({'query': args.get('query', ''), 'filters': args.get('filters')}),
                        canonical_json([m['record_id'] for m in result['matches']]), time.time()))

    def candidate_from_patch(self, file_id, args, result):
        if args.get('dry_run') or result.get('status') != 'ok' or result.get('failed', 0) or result.get('modified', 0) == 0:
            return None
        with self.store.connection() as db:
            context = db.execute('SELECT * FROM recipe_query_context WHERE file_id=?', (file_id,)).fetchone()
        operations = args.get('operations') or []
        if not context or time.time() - context['created_at'] > 1800 or not operations:
            return None
        if {o['record_id'] for o in operations} != set(json.loads(context['matches_json'])):
            return None
        patterns = {(o['column'], o['operation'], canonical_json(o.get('value'))) for o in operations}
        if len(patterns) != 1:
            return None
        column, operation, value = next(iter(patterns))
        if operation != 'set':
            return None
        query = json.loads(context['query_json'])
        if not query['query'] or query['filters']:
            return None
        role = role_for(column)
        description_role = 'complaint_text' if re.search('物流|投诉|配送|快递|logistic|complaint', query['query'], re.I) else 'product_description'
        plan = {'ir_version': 1, 'name': query['query'][:60] + '复核', 'intent': query['query'],
                'required_roles': [description_role, role], 'parameters': {'status': json.loads(value)},
                'steps': [{'id': 'find', 'type': 'semantic_query', 'role': description_role, 'query': query['query']},
                          {'id': 'update', 'type': 'patch', 'source': 'find', 'role': role, 'operation': 'set', 'value': '${status}'},
                          {'id': 'total', 'type': 'aggregate', 'source': 'update', 'metric': 'count'}]}
        rid = self.create(plan, 'history')
        with self.store.connection() as db:
            db.execute('DELETE FROM recipe_query_context WHERE file_id=?', (file_id,))
        return rid
