"""Excel-driven recovery, plus bounded remote verification; never a full KB dump."""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path

from openpyxl import load_workbook

from .locking import bridge_lock
from .models import Record
from .utils import canonical_json, fingerprint_data, row_data, unique_headers, extract_record_id, build_content
from .weknora_client import WeknoraError


def file_hash(path):
    with open(path, "rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def prepare_patch_intent(store, file_row, records):
    intent_id = str(uuid.uuid4())
    payload = {"before_hash": file_hash(file_row["file_path"]), "records": [asdict(r) for r in records]}
    with store.connection() as connection:
        connection.execute("INSERT INTO patch_intents(id,file_id,file_path,payload_json,created_at,updated_at) VALUES (?,?,?,?,?,?)",
                           (intent_id, file_row["file_id"], file_row["file_path"], canonical_json(payload), time.time(), time.time()))
    return intent_id


def confirm_patch_intent(store, outbox, intent_id):
    with store.connection() as connection:
        intent = connection.execute("SELECT * FROM patch_intents WHERE id=?", (intent_id,)).fetchone()
    payload = json.loads(intent["payload_json"])
    path = Path(intent["file_path"])
    stat = path.stat()
    if file_hash(path) == payload["before_hash"]:
        with store.connection() as connection:
            connection.execute("UPDATE patch_intents SET status='cancelled',updated_at=? WHERE id=?", (time.time(), intent_id))
        return []
    records = [Record(**raw) for raw in payload["records"]]
    wanted = defaultdict(list)
    for record in records:
        wanted[(record.sheet, record.fingerprint)].append(record)
    found = defaultdict(list)
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        for sheet in workbook:
            rows = sheet.iter_rows(values_only=True)
            headers = unique_headers(next(rows, []))
            for row_number, values in enumerate(rows, 2):
                data = row_data(headers, values)
                identity = (sheet.title, fingerprint_data(data))
                if identity in wanted:
                    found[identity].append((row_number, data))
    finally:
        workbook.close()
    for identity, targets in wanted.items():
        candidates = found[identity]
        if len(targets) != 1 or len(candidates) != 1:
            raise WeknoraError("saved patch cannot be uniquely confirmed in Excel; inspect patch intent", category="ambiguous")
        targets[0].row_hint, targets[0].data = candidates[0]
        targets[0].content = build_content(targets[0].record_id, str(path), targets[0].sheet,
                                           targets[0].record_key, targets[0].data)
        targets[0].rag_status = "pending" if outbox.client else "local_only"
        targets[0].rag_error = None
    current = path.stat()
    if (current.st_size, current.st_mtime_ns) != (stat.st_size, stat.st_mtime_ns):
        raise WeknoraError("Excel changed during saved-patch verification", category="ambiguous")
    with store.connection() as connection:
        store.upsert_records(connection, records)
        task_ids = [outbox.enqueue(connection, r, rearm=True) for r in records]
        connection.execute("UPDATE files SET file_size=?,modified_time_ns=?,status='ready' WHERE file_id=?",
                           (stat.st_size, stat.st_mtime_ns, intent["file_id"]))
        connection.execute("UPDATE patch_intents SET status='completed',last_error=NULL,updated_at=? WHERE id=?",
                           (time.time(), intent_id))
    return task_ids


def recover_patch_intents(store, outbox, file_id=None):
    with store.connection() as connection:
        intents = connection.execute("SELECT id FROM patch_intents WHERE status IN ('prepared','blocked')" +
                                     (" AND file_id=?" if file_id else "") + " ORDER BY created_at",
                                     (file_id,) if file_id else ()).fetchall()
    for intent in intents:
        try:
            confirm_patch_intent(store, outbox, intent[0])
        except Exception:
            with store.connection() as connection:
                connection.execute("UPDATE patch_intents SET status='blocked',last_error='Excel verification requires reconciliation',updated_at=? WHERE id=?",
                                   (time.time(), intent[0]))
            raise


def reconcile_local(store, outbox, *, file_id=None, force=False, deadline=None):
    from .indexer import ExcelIndexer
    report = {"files_checked": 0, "rescanned": 0, "blocked_files": 0, "errors": []}
    with store.connection() as connection:
        files = connection.execute("SELECT * FROM files" + (" WHERE file_id=?" if file_id else ""),
                                   (file_id,) if file_id else ()).fetchall()
    for file_row in files:
        if deadline and time.monotonic() >= deadline:
            break
        report["files_checked"] += 1
        try:
            recover_patch_intents(store, outbox, file_row["file_id"])
            fresh = store.get_file_by_id(file_row["file_id"])
            stat = Path(fresh["file_path"]).stat()
            if force or (stat.st_size, stat.st_mtime_ns) != (fresh["file_size"], fresh["modified_time_ns"]):
                ExcelIndexer(store, outbox.client, outbox)._index(fresh["file_path"], True, defer_sync=True)
                report["rescanned"] += 1
            with store.connection() as connection:
                for row in connection.execute("SELECT * FROM records WHERE file_id=? AND (rag_status<>'synced' OR weknora_entry_id IS NULL)", (file_row["file_id"],)):
                    outbox.enqueue(connection, store.row_to_record(row), rearm=True)
        except Exception as error:
            report["blocked_files"] += 1
            if len(report["errors"]) < 5:
                report["errors"].append({"file_id": file_row["file_id"], "error_type": type(error).__name__,
                                         "message": "Excel unavailable or ambiguous; reconcile required"})
            with store.connection() as connection:
                connection.execute("UPDATE files SET status='reconcile_blocked' WHERE file_id=?", (file_row["file_id"],))
                connection.execute("""UPDATE outbox_tasks SET status='blocked',error_category='ambiguous',
                    last_error='Excel unavailable or ambiguous; reconcile required',locked_at=NULL,worker_id=NULL
                    WHERE file_id=? AND status IN ('pending','retry')""", (file_row["file_id"],))
    return report


def reconcile(store, outbox, *, file_id=None, force_excel=True, remote_limit=20, max_seconds=60):
    deadline = time.monotonic() + max_seconds
    with bridge_lock(store):
        outbox.recover_processing()
        report = reconcile_local(store, outbox, file_id=file_id, force=force_excel, deadline=deadline)
        report.update(remote_checked=0, remote_missing=0, remote_conflicts=0)
        if not outbox.client:
            return {**report, "outbox": outbox.get_outbox_stats(file_id)}
        outbox.client.deadline = deadline
        try:
            # Count is diagnostic only: a KB may contain other files/unmanaged FAQs.
            report["remote_count"] = outbox.client.list_entries(page_size=1).get("total")
            with store.connection() as connection:
                rows = connection.execute("SELECT * FROM records WHERE weknora_entry_id IS NOT NULL" +
                                          (" AND file_id=?" if file_id else "") +
                                          " ORDER BY CASE WHEN rag_status='synced' THEN 1 ELSE 0 END,updated_at LIMIT ?",
                                          (*([file_id] if file_id else []), remote_limit)).fetchall()
            for row in rows:
                if time.monotonic() >= deadline:
                    break
                entry = outbox.client.get_entry(row["weknora_entry_id"])
                report["remote_checked"] += 1
                if entry and extract_record_id(entry.get("answers")) != row["record_id"]:
                    report["remote_conflicts"] += 1
                    with store.connection() as connection:
                        task_id = outbox.enqueue(connection, store.row_to_record(row), rearm=True)
                        connection.execute("UPDATE outbox_tasks SET status='blocked',error_category='conflict',last_error='remote entry belongs to a different record' WHERE id=?", (task_id,))
                    continue
                remote_fingerprints = [a for a in (entry.get("answers", []) if entry else []) if a.startswith("fingerprint=")]
                if (not entry or entry.get("standard_question") != row["content"]
                        or (remote_fingerprints and f"fingerprint={row['fingerprint']}" not in remote_fingerprints)):
                    report["remote_missing"] += 1
                    with store.connection() as connection:
                        connection.execute("UPDATE records SET rag_status='pending' WHERE record_id=?", (row["record_id"],))
                        outbox.enqueue(connection, store.row_to_record(row), rearm=True)
        except WeknoraError as error:
            report["remote_error_category"] = error.category
        finally:
            outbox.client.deadline = None
        return {**report, "outbox": outbox.get_outbox_stats(file_id)}
