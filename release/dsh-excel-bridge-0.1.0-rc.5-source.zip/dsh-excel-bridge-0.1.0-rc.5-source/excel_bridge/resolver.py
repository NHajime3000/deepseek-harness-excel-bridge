"""Model-facing workflow routing. Internal identities never come from tool arguments."""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path

from .locking import bridge_lock
from .plan_ir import PlanError
from .procedure import ProcedureEngine
from .utils import canonical_json


def public_summary(result):
    """Whitelist a bounded projection; locators and complete plans stay in SQLite."""
    allowed = {'status', 'name', 'file', 'matched', 'modified', 'sheets', 'columns', 'mapping',
               'risks', 'examples', 'step_count', 'steps_completed', 'message', 'error',
               'unresolved', 'available_columns', 'sync_status', 'chunks_completed', 'chunks_total',
               'stage', 'rules_count', 'candidates', 'approval_state'}
    return {key: value for key, value in result.items() if key in allowed}


class RecipeResolver:
    def __init__(self, memory):
        self.memory = memory

    def resolve(self, instruction, columns):
        candidates = self.memory.search(instruction, columns, limit=3)
        descriptions = [{key: row[key] for key in ('name', 'score', 'mapping_status')} for row in candidates]
        if not candidates:
            return {'status': 'no_recipe_match', 'candidates': []}
        first = candidates[0]
        if first['score'] < .7 or (len(candidates) > 1 and first['score'] - candidates[1]['score'] < .1):
            return {'status': 'needs_review', 'candidates': descriptions,
                    'message': '历史方案置信度不足或存在歧义；未写入 Excel，请补充处理要求。'}
        recipe = self.memory.get(first['recipe_id'])
        plan = json.loads(recipe['plan_json'])
        mapping = self.memory.resolve(plan['required_roles'], columns)
        if mapping['status'] != 'mapped':
            return {**mapping, 'available_columns': columns[:40],
                    'message': '历史方案的字段缺失或有歧义；请由管理员确认字段映射，未写入 Excel。'}
        return {'status': 'resolved', 'recipe_id': recipe['recipe_id'], 'version': recipe['version'],
                'plan': plan, 'mapping': mapping['mapping']}


def procedure_run(bridge, args, *, session_key=None):
    if not bridge.config.workflow.procedure_enabled:
        return {'status': 'disabled', 'message': 'Procedure 功能未启用。'}
    if not isinstance(args, dict) or set(args) - {'instruction', 'files'}:
        return {'status': 'invalid_arguments', 'message': '只传 instruction 和 files。编号、映射和确认由后端管理。'}
    instruction, files = args.get('instruction'), args.get('files')
    if not isinstance(instruction, str) or not 1 <= len(instruction.strip()) <= 2400:
        return {'status': 'invalid_arguments', 'message': 'instruction 必须包含任务说明。'}
    if not isinstance(files, list) or not 1 <= len(files) <= 2 or any(not isinstance(f, str) or not f.strip() for f in files):
        return {'status': 'invalid_arguments', 'message': 'files 需要一个 XLSX 和可选的 DOCX、MD 或 TXT SOP。'}
    paths = []
    for file in files:
        path = Path(file).expanduser()
        path = (bridge.config.workspace / path).resolve() if not path.is_absolute() else path.resolve()
        if not path.is_file():
            return {'status': 'invalid_file', 'message': '指定文件不存在，请核对用户提供的路径。未猜测其他文件。'}
        paths.append(path)
    excel = [p for p in paths if p.suffix.lower() == '.xlsx']
    sources = [p for p in paths if p.suffix.lower() in {'.docx', '.md', '.txt'}]
    if len(excel) != 1 or len(sources) != len(paths) - 1:
        return {'status': 'invalid_file', 'message': '只支持一个 XLSX 及最多一个 SOP 文档。'}
    if sources and sources[0].stat().st_size > 8_000_000:
        return {'status': 'needs_review', 'message': 'SOP 超过 8 MB 限制；未读取全文或写入 Excel。'}
    # No shared fallback session: a missing host identity must fail closed.
    if not isinstance(session_key, str) or not 1 <= len(session_key) <= 200:
        return {'status': 'needs_review', 'message': '缺少可信 DSH 会话上下文，无法关联运行；未写入 Excel。'}
    file = str(excel[0])
    request = {'instruction': instruction.strip(), 'files': [str(p) for p in paths],
               'sop_hash': hashlib.sha256(sources[0].read_bytes()).hexdigest() if sources else None}
    request_hash = hashlib.sha256(canonical_json(request).encode()).hexdigest()
    engine = ProcedureEngine(bridge)
    with bridge_lock(bridge.store):
        with bridge.store.connection() as db:
            binding = db.execute('SELECT * FROM workflow_bindings WHERE session_key=? AND file_path=?', (session_key, file)).fetchone()
        if binding and binding['request_hash'] != request_hash:
            # A changed instruction is a new request, never an approval or a resume.
            if binding['run_id']:
                from .approvals import ApprovalStore
                with bridge.store.connection() as db:
                    for row in db.execute("SELECT approval_id,state FROM workflow_approvals WHERE kind='procedure' AND subject=?", (binding['run_id'],)).fetchall():
                        if row['state'] not in {'COMPLETED', 'INVALIDATED'}:
                            ApprovalStore._transition(db, row['approval_id'], 'INVALIDATED', 'changed_request')
            return {'status': 'needs_review', 'message': '本会话任务说明或 SOP 已改变；请新建会话重新预览，旧审批不适用于新任务。'}
        if binding and binding['run_id']:
            return public_summary(engine.resume(binding['run_id']))
        from .sop import SopCompiler
        compiler = SopCompiler(bridge.store, bridge.config.workflow)
        pid = binding['procedure_id'] if binding else None
        recipe_id, plan, mapping = None, None, None
        if not pid and sources:
            pid = compiler.ingest(sources[0])
        if not pid:
            indexer = engine._components(file)[0]
            indexed = indexer.index(file)
            if indexed.get('status') not in {'ok', 'partial'}:
                return public_summary(indexed)
            columns = engine._columns(engine._records(bridge.store.resolve_file(file)['file_id']))
            resolved = RecipeResolver(engine.memory).resolve(instruction, columns) if bridge.config.workflow.recipe_enabled else {'status': 'no_recipe_match'}
            if resolved['status'] == 'resolved':
                recipe_id, plan, mapping = resolved['recipe_id'], resolved['plan'], resolved['mapping']
            elif resolved['status'] != 'no_recipe_match':
                return public_summary(resolved)
            elif re.search(r'上次|上回|之前|以前|历史|沿用|复用|last time|previous|reuse', instruction, re.I):
                return {'status': 'no_recipe_match', 'message': '没有可信历史方案。请提供具体处理规则或 SOP；未修改 Excel。'}
            else:
                folder = bridge.config.state_dir / 'procedures'
                folder.mkdir(exist_ok=True)
                reference = folder / ('instruction_' + request_hash + '.txt')
                reference.write_text(instruction, encoding='utf-8')
                pid = compiler.ingest(reference)
        with bridge.store.connection() as db:
            db.execute('INSERT OR IGNORE INTO workflow_bindings VALUES (?,?,?,?,?,?,?)',
                       (session_key, file, request_hash, pid, None, canonical_json(request), time.time()))
        if pid:
            compiled = compiler.compile_next(pid)
            if compiled['status'] != 'validated':
                return public_summary(compiled)
            with bridge.store.connection() as db:
                plan = json.loads(db.execute('SELECT plan_json FROM procedures WHERE procedure_id=?', (pid,)).fetchone()[0])
        preview = engine.prepare(file, plan, mapping=mapping, recipe_id=recipe_id, procedure_id=pid,
                                 source_type='sop' if sources else 'generated')
        if preview.get('run_id'):
            with bridge.store.connection() as db:
                db.execute('UPDATE workflow_bindings SET run_id=? WHERE session_key=? AND file_path=?',
                           (preview['run_id'], session_key, file))
        return public_summary(preview)
