from __future__ import annotations

from typing import Any

from .config import BridgeConfig
from .indexer import ExcelIndexer
from .patcher import ExcelPatcher
from .query import ExcelQuery
from .storage import LocatorStore
from .utils import bound_result
from .weknora_client import WeknoraClient
from .outbox import Outbox
from .workspace import WorkspaceManager, WorkspaceError, RoutedOutbox
from .weknora_client import WeknoraError
from .locking import bridge_lock
from .reconcile import file_hash
from pathlib import Path
import time


class ExcelBridge:
    def __init__(self, config: BridgeConfig):
        self.config = config
        config.state_dir.mkdir(parents=True, exist_ok=True)
        self.store = LocatorStore(config.database_path)
        self.workspaces = WorkspaceManager(self.store, config)
        self.workspace_mode = config.weknora.enabled and not config.weknora.knowledge_base_id
        self.weknora = WeknoraClient(config.weknora) if config.weknora.enabled else None
        self.outbox = Outbox(self.store, self.weknora, config.outbox)
        self.indexer = ExcelIndexer(self.store, self.weknora, self.outbox)
        self.querier = ExcelQuery(self.store, self.weknora)
        self.patcher = ExcelPatcher(self.store, self.weknora, config.backup_dir, self.outbox)
        if self.workspace_mode:
            self.outbox = RoutedOutbox(self.workspaces)

    def _managed(self, file):
        mapping = self.workspaces.get(file)
        return self.workspace_mode or (mapping is not None and mapping['mode'] == 'workspace')

    def excel_index(self, arguments: dict[str, Any]) -> dict[str, Any]:
        file = arguments.get("file")
        if not isinstance(file, str) or not file.strip():
            raise ValueError("file is required")
        force = arguments.get("force_reindex", False)
        if not isinstance(force, bool):
            raise ValueError("force_reindex must be boolean")
        if self._managed(file):
            try:
                mapping, result, _ = self.workspaces.ensure_index(file.strip(), force=force)
                return bound_result({**result, 'workspace': mapping['kb_status']})
            except WorkspaceError as error:
                return error.result(file)
        return bound_result(self.indexer.index(file.strip(), force))

    def excel_query(self, arguments: dict[str, Any]) -> dict[str, Any]:
        result = self._excel_query(arguments)
        if self.config.workflow.recipe_enabled and result.get('status') == 'ok':
            from .recipes import RecipeMemory
            RecipeMemory(self.store).remember_query(self.store.resolve_file(arguments['file'])['file_id'], arguments, result)
        return result

    def _excel_query(self, arguments: dict[str, Any]) -> dict[str, Any]:
        file = arguments.get("file")
        query = arguments.get("query")
        if not isinstance(file, str) or not file.strip():
            raise ValueError("file is required")
        if not isinstance(query, str):
            raise ValueError("query is required")
        if self._managed(file):
            deadline = time.monotonic() + self.config.query_budget_seconds
            try:
                # Auto-query now mutates the index. Serialize with patch/worker;
                # a busy large index must not consume the 60-second tool timeout.
                with bridge_lock(self.store, timeout=min(5, self.config.query_budget_seconds)):
                    mapping, _, components = self.workspaces.ensure_index(file.strip(), query=True, deadline=deadline)
                    if query.strip() and mapping['kb_status'] != 'ready':
                        return {'status': 'indexing', 'file': mapping['file_name'], 'workspace': mapping['kb_status'],
                                'message': '索引尚在同步；稍后重试查询，或调用 excel_index 继续。'}
                    components[1].weknora.deadline = deadline
                    result = components[1].query(mapping['file_path'], query, arguments.get('filters'),
                                                  arguments.get('limit', self.config.default_query_limit))
                    return {**result, 'workspace': mapping['kb_status']}
            except WorkspaceError as error:
                return error.result(file)
            except WeknoraError as error:
                mapping = self.workspaces.get(file)
                if mapping and error.category == 'not_found':
                    self.workspaces._update(mapping['file_id'], kb_status='orphaned', error_category='remote_kb_missing')
                return {'status': 'workspace_error', 'file': Path(file).name, 'category': error.category,
                        'message': '语义索引暂不可用；请恢复服务或运行 Workspace 对账。'}
            except TimeoutError:
                return {'status': 'indexing', 'file': Path(file).name, 'message': '索引或写入正在进行，请稍后重试。'}
        return self.querier.query(
            file.strip(), query, arguments.get("filters"), arguments.get("limit", self.config.default_query_limit)
        )

    def excel_patch(self, arguments: dict[str, Any]) -> dict[str, Any]:
        # This is the public Python/CLI/DSH boundary. No caller-supplied flag
        # can disable the approval gate. Procedure uses its separately gated engine.
        if not isinstance(arguments, dict) or set(arguments) - {'file', 'operations', 'selector', 'operation', 'dry_run'}:
            raise ValueError('Unknown patch argument; tool arguments cannot authorize approvals')
        if type(arguments.get('dry_run', False)) is not bool:
            raise ValueError('dry_run must be boolean')
        with bridge_lock(self.store):
            result = self._approved_patch(arguments)
        if self.config.workflow.recipe_enabled:
            # Candidate persistence must never turn an already saved Excel into
            # an apparent failed patch that a caller might repeat.
            try:
                from .recipes import RecipeMemory
                candidate = RecipeMemory(self.store).candidate_from_patch(self.store.resolve_file(arguments['file'])['file_id'], arguments, result)
                if candidate:
                    result['recipe_candidate'] = {'recipe_id': candidate, 'status': 'draft'}
            except Exception:
                result['recipe_note'] = '本次写入结果不变；候选方案未保存。'
        return result

    def _approved_patch(self, arguments):
        from .approvals import ApprovalStore
        file = arguments.get('file')
        preview = self._excel_patch({**arguments, 'dry_run': True})
        if preview.get('status') != 'preview':
            return preview
        high_impact = preview.get('matched', 0) >= self.config.workflow.preview_threshold or len(preview.get('sheets', [])) > 1
        if not high_impact:
            return preview if arguments.get('dry_run', False) else self._excel_patch(arguments)
        source = self.store.resolve_file(file)
        # Re-preview between hashes to fence external editors as well as Bridge writers.
        before_hash = file_hash(Path(source['file_path']))
        preview = self._excel_patch({**arguments, 'dry_run': True})
        after_hash = file_hash(Path(source['file_path']))
        if before_hash != after_hash:
            return {'status': 'needs_review', 'message': '预览期间源文件变化，请重新预览。'}
        request = {k: v for k, v in arguments.items() if k != 'dry_run'}
        request['file'] = source['file_path']
        snapshot = {'file_id': source['file_id'], 'source_hash': after_hash,
                    'request': request, 'preview': preview}
        approvals = ApprovalStore(self.store)
        approval = approvals.freeze('patch', source['file_id'], snapshot, preview)
        if arguments.get('dry_run', False) or approval['state'] not in {'APPROVED', 'EXECUTING'}:
            return {**preview, **approvals.waiting(approval),
                    'message': '批量或跨表写入需要管理员批准冻结预览。批准后重复相同 patch 参数；confirm=true 无效。'}
        # A crash with an uncertain saved workbook must not blindly repeat arithmetic.
        if approval['state'] == 'EXECUTING':
            return {'status': 'needs_review', 'message': '上次批量写入中断，请先运行恢复与对账；不要重复修改。'}
        approvals.transition(approval['approval_id'], 'EXECUTING')
        result = self._excel_patch(arguments)
        if result.get('status') in {'ok', 'partial'}:
            approvals.transition(approval['approval_id'], 'COMPLETED')
        return result

    def procedure_run(self, arguments, *, session_key=None):
        from .resolver import procedure_run
        return bound_result(procedure_run(self, arguments, session_key=session_key))

    def _excel_patch(self, arguments: dict[str, Any]) -> dict[str, Any]:
        file = arguments.get("file")
        if not isinstance(file, str) or not file.strip():
            raise ValueError("file is required")
        dry_run = arguments.get("dry_run", False)
        if not isinstance(dry_run, bool):
            raise ValueError("dry_run must be boolean")
        if self._managed(file):
            try:
                with bridge_lock(self.store):
                    mapping = self.workspaces.ensure_workspace(file)
                    if not self.store.get_file_by_id(mapping['file_id']):
                        mapping, _, _ = self.workspaces.ensure_index(file)
                    patcher = self.workspaces.components(mapping)[2]
                    result = patcher.patch(mapping['file_path'], operations=arguments.get('operations'),
                        selector=arguments.get('selector'), operation=arguments.get('operation'), dry_run=dry_run)
                    if not dry_run:
                        stats = self.outbox.get_outbox_stats(mapping['file_id'])
                        ready = not any(stats[s] for s in ('pending','retry','processing','failed','blocked'))
                        self.workspaces._update(mapping['file_id'], kb_status='ready' if ready else 'syncing',
                                                file_hash=file_hash(Path(mapping['file_path'])),
                                                last_synced_at=time.time() if ready else None)
                    return result
            except WorkspaceError as error:
                return error.result(file)
        return self.patcher.patch(
            file.strip(),
            operations=arguments.get("operations"),
            selector=arguments.get("selector"),
            operation=arguments.get("operation"),
            dry_run=dry_run,
        )
