from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator

from .models import Record
from .utils import canonical_json, canonical_path


SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    file_id TEXT PRIMARY KEY,
    file_path TEXT NOT NULL UNIQUE,
    file_name TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    modified_time_ns INTEGER NOT NULL,
    indexed_at TEXT NOT NULL,
    status TEXT NOT NULL,
    primary_key_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS records (
    record_id TEXT PRIMARY KEY,
    file_id TEXT NOT NULL REFERENCES files(file_id) ON DELETE CASCADE,
    sheet TEXT NOT NULL,
    row_hint INTEGER NOT NULL,
    record_key_json TEXT NOT NULL,
    record_key_hash TEXT NOT NULL DEFAULT '',
    fingerprint TEXT NOT NULL,
    data_json TEXT NOT NULL,
    content TEXT NOT NULL,
    weknora_document_id TEXT,
    weknora_chunk_id TEXT,
    weknora_entry_id INTEGER,
    rag_status TEXT NOT NULL DEFAULT 'pending',
    rag_error TEXT,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_records_file_id ON records(file_id);
CREATE INDEX IF NOT EXISTS idx_records_file_sheet ON records(file_id, sheet);
CREATE INDEX IF NOT EXISTS idx_records_fingerprint ON records(fingerprint);
CREATE INDEX IF NOT EXISTS idx_records_file_fingerprint ON records(file_id, sheet, fingerprint);
CREATE INDEX IF NOT EXISTS idx_records_key_hash ON records(file_id, sheet, record_key_hash);
CREATE INDEX IF NOT EXISTS idx_records_weknora_entry ON records(weknora_entry_id);
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class LocatorStore:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=60)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA synchronous = FULL")
        connection.execute("PRAGMA temp_store = FILE")
        return connection

    def initialize(self) -> None:
        with self.connection() as connection:
            connection.executescript(SCHEMA)
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            if version > 4:
                raise RuntimeError(f"unsupported SQLite schema version: {version}")
            # Additive migration from the shipped v0 database. No locator rewrite.
            connection.executescript(OUTBOX_SCHEMA)
            connection.executescript(WORKSPACE_SCHEMA)
            from .workflow_schema import WORKFLOW_SCHEMA
            connection.executescript(WORKFLOW_SCHEMA)
            # A legacy binding is adopted only from persisted destination evidence.
            saved = connection.execute("SELECT value FROM bridge_meta WHERE key='remote_scope'").fetchone()
            if saved:
                scope = json.loads(saved[0])
                if scope and scope.get('kb_id'):
                    connection.execute("""INSERT OR IGNORE INTO file_workspaces
                        (file_id,file_path,file_name,base_url,tenant_id,knowledge_base_id,knowledge_base_name,
                         kb_status,kb_created_by_bridge,mode,created_at,updated_at)
                        SELECT file_id,file_path,file_name,?,?,?,'legacy','ready',0,'legacy',0,0 FROM files""",
                                       (scope['base_url'], scope.get('tenant_id'), scope['kb_id']))
            connection.execute("PRAGMA user_version = 4")

    def file_id_for_path(self, path: Path) -> str:
        from .utils import make_file_id
        with self.connection() as connection:
            row = connection.execute("SELECT file_id FROM files WHERE file_path=? COLLATE NOCASE", (canonical_path(path),)).fetchone()
            if row is None:
                row = connection.execute("SELECT file_id FROM file_workspaces WHERE file_path=? COLLATE NOCASE", (canonical_path(path),)).fetchone()
        return row[0] if row else make_file_id(path)

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        connection = self.connect()
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def resolve_file(self, reference: str) -> sqlite3.Row:
        candidate = Path(reference).expanduser()
        with self.connection() as connection:
            if candidate.is_absolute() or candidate.exists():
                path = canonical_path(candidate)
                row = connection.execute(
                    "SELECT * FROM files WHERE file_path = ? COLLATE NOCASE", (path,)
                ).fetchone()
                if row is not None:
                    return row
            rows = connection.execute(
                "SELECT * FROM files WHERE file_name = ? COLLATE NOCASE ORDER BY indexed_at DESC LIMIT 2",
                (candidate.name,),
            ).fetchall()
        if not rows:
            raise FileNotFoundError(f"indexed Excel file not found: {reference}")
        if len(rows) > 1:
            raise ValueError(f"file name is ambiguous; pass an absolute path: {reference}")
        return rows[0]

    def get_file_by_id(self, file_id: str) -> sqlite3.Row | None:
        with self.connection() as connection:
            return connection.execute(
                "SELECT * FROM files WHERE file_id = ?", (file_id,)
            ).fetchone()

    def get_record(self, record_id: str) -> Record | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM records WHERE record_id = ?", (record_id,)
            ).fetchone()
        return self.row_to_record(row) if row else None

    def get_records(self, record_ids: Iterable[str]) -> dict[str, Record]:
        ids = list(dict.fromkeys(record_ids))
        result: dict[str, Record] = {}
        with self.connection() as connection:
            for start in range(0, len(ids), 500):
                batch = ids[start : start + 500]
                placeholders = ",".join("?" for _ in batch)
                for row in connection.execute(
                    f"SELECT * FROM records WHERE record_id IN ({placeholders})", batch
                ):
                    record = self.row_to_record(row)
                    result[record.record_id] = record
        return result

    def find_by_entry_id(self, file_id: str, entry_id: int) -> Record | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM records WHERE file_id = ? AND weknora_entry_id = ?",
                (file_id, entry_id),
            ).fetchone()
        return self.row_to_record(row) if row else None

    def find_by_key_hash(self, file_id: str, sheet: str, key_hash: str) -> list[Record]:
        with self.connection() as connection:
            rows = connection.execute(
                "SELECT * FROM records WHERE file_id = ? AND sheet = ? AND record_key_hash = ?",
                (file_id, sheet, key_hash),
            ).fetchall()
        return [self.row_to_record(row) for row in rows]

    def find_by_fingerprint(self, file_id: str, sheet: str, fingerprint: str) -> list[Record]:
        with self.connection() as connection:
            rows = connection.execute(
                "SELECT * FROM records WHERE file_id = ? AND sheet = ? AND fingerprint = ?",
                (file_id, sheet, fingerprint),
            ).fetchall()
        return [self.row_to_record(row) for row in rows]

    def upsert_file(
        self,
        connection: sqlite3.Connection,
        *,
        file_id: str,
        file_path: str,
        file_name: str,
        file_size: int,
        modified_time_ns: int,
        status: str,
        primary_keys: dict[str, list[str]],
    ) -> None:
        connection.execute(
            """
            INSERT INTO files(file_id, file_path, file_name, file_size, modified_time_ns,
                              indexed_at, status, primary_key_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(file_id) DO UPDATE SET
                file_path=excluded.file_path,
                file_name=excluded.file_name,
                file_size=excluded.file_size,
                modified_time_ns=excluded.modified_time_ns,
                indexed_at=excluded.indexed_at,
                status=excluded.status,
                primary_key_json=excluded.primary_key_json
            """,
            (
                file_id,
                file_path,
                file_name,
                file_size,
                modified_time_ns,
                utc_now(),
                status,
                canonical_json(primary_keys),
            ),
        )

    def replace_file_records(
        self,
        connection: sqlite3.Connection,
        file_id: str,
        records: Iterable[Record],
        keep_ids: set[str],
    ) -> None:
        old = connection.execute(
            "SELECT record_id FROM records WHERE file_id = ?", (file_id,)
        ).fetchall()
        delete_ids = [row[0] for row in old if row[0] not in keep_ids]
        for start in range(0, len(delete_ids), 500):
            batch = delete_ids[start : start + 500]
            connection.execute(
                f"DELETE FROM records WHERE record_id IN ({','.join('?' for _ in batch)})",
                batch,
            )
        self.upsert_records(connection, records)

    def upsert_records(
        self, connection: sqlite3.Connection, records: Iterable[Record]
    ) -> None:
        now = utc_now()
        connection.executemany(
            """
            INSERT INTO records(
                record_id, file_id, sheet, row_hint, record_key_json, record_key_hash,
                fingerprint, data_json, content, weknora_document_id, weknora_chunk_id,
                weknora_entry_id, rag_status, rag_error, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(record_id) DO UPDATE SET
                file_id=excluded.file_id,
                sheet=excluded.sheet,
                row_hint=excluded.row_hint,
                record_key_json=excluded.record_key_json,
                record_key_hash=excluded.record_key_hash,
                fingerprint=excluded.fingerprint,
                data_json=excluded.data_json,
                content=excluded.content,
                weknora_document_id=excluded.weknora_document_id,
                weknora_chunk_id=excluded.weknora_chunk_id,
                weknora_entry_id=excluded.weknora_entry_id,
                rag_status=excluded.rag_status,
                rag_error=excluded.rag_error,
                updated_at=excluded.updated_at
            """,
            (
                (
                    record.record_id,
                    record.file_id,
                    record.sheet,
                    record.row_hint,
                    canonical_json(record.record_key),
                    record.record_key_hash,
                    record.fingerprint,
                    canonical_json(record.data),
                    record.content,
                    record.weknora_document_id,
                    record.weknora_chunk_id,
                    record.weknora_entry_id,
                    record.rag_status,
                    record.rag_error,
                    now,
                )
                for record in records
            ),
        )

    @staticmethod
    def row_to_record(row: sqlite3.Row) -> Record:
        return Record(
            record_id=row["record_id"],
            file_id=row["file_id"],
            sheet=row["sheet"],
            row_hint=row["row_hint"],
            record_key=json.loads(row["record_key_json"]),
            record_key_hash=row["record_key_hash"],
            fingerprint=row["fingerprint"],
            data=json.loads(row["data_json"]),
            content=row["content"],
            weknora_document_id=row["weknora_document_id"],
            weknora_chunk_id=row["weknora_chunk_id"],
            weknora_entry_id=row["weknora_entry_id"],
            rag_status=row["rag_status"],
            rag_error=row["rag_error"],
        )


OUTBOX_SCHEMA = """
CREATE TABLE IF NOT EXISTS bridge_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS outbox_tasks (
    id TEXT PRIMARY KEY,
    task_type TEXT NOT NULL CHECK(task_type IN ('rag_upsert','rag_replace','rag_delete','reconcile_record')),
    record_id TEXT NOT NULL,
    file_id TEXT NOT NULL,
    sheet TEXT NOT NULL,
    operation_key TEXT NOT NULL UNIQUE,
    payload_json TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('pending','processing','retry','completed','failed','blocked','superseded')),
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 8,
    next_retry_at REAL NOT NULL DEFAULT 0,
    last_error TEXT,
    error_category TEXT,
    remote_task_id TEXT,
    remote_entry_id INTEGER,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    completed_at REAL,
    locked_at REAL,
    worker_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_outbox_due ON outbox_tasks(status,next_retry_at,created_at);
CREATE INDEX IF NOT EXISTS idx_outbox_ready_order ON outbox_tasks(created_at)
    WHERE status IN ('pending','retry');
CREATE INDEX IF NOT EXISTS idx_outbox_record ON outbox_tasks(record_id,created_at);
CREATE INDEX IF NOT EXISTS idx_outbox_file ON outbox_tasks(file_id,status);
CREATE INDEX IF NOT EXISTS idx_outbox_remote ON outbox_tasks(remote_task_id);
-- A pre-save journal closes the Excel replace / SQLite commit crash window.
CREATE TABLE IF NOT EXISTS patch_intents (
    id TEXT PRIMARY KEY,
    file_id TEXT NOT NULL,
    file_path TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'prepared',
    last_error TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_patch_intents_file ON patch_intents(file_id,status);
"""

WORKSPACE_SCHEMA = """
CREATE TABLE IF NOT EXISTS file_workspaces (
    file_id TEXT PRIMARY KEY,
    file_path TEXT NOT NULL UNIQUE COLLATE NOCASE,
    file_name TEXT NOT NULL,
    base_url TEXT,
    tenant_id TEXT,
    knowledge_base_id TEXT,
    knowledge_base_name TEXT NOT NULL,
    kb_status TEXT NOT NULL CHECK(kb_status IN ('creating','ready','syncing','error','deleted','orphaned','deleting')),
    kb_created_by_bridge INTEGER NOT NULL DEFAULT 0,
    mode TEXT NOT NULL DEFAULT 'workspace',
    intent_token TEXT,
    phase TEXT NOT NULL DEFAULT 'prepared',
    error_category TEXT,
    last_error TEXT,
    file_hash TEXT,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    last_indexed_at REAL,
    last_synced_at REAL,
    deleted_at REAL
);
CREATE INDEX IF NOT EXISTS idx_workspaces_status ON file_workspaces(kb_status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_workspace_owned_kb ON file_workspaces(base_url,tenant_id,knowledge_base_id)
    WHERE kb_created_by_bridge=1 AND knowledge_base_id IS NOT NULL;
"""
