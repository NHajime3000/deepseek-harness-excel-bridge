from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable

from .config import MAX_RETURN_CHARS


RECORD_MARKER = "excel-record:"
_INVALID_HEADER = re.compile(r"\s+")
_SEMANTIC_HEADER_HINTS = (
    "description",
    "name",
    "title",
    "summary",
    "product",
    "item",
    "category",
    "country",
    "region",
    "city",
    "address",
    "status",
    "note",
    "comment",
    "complaint",
    "feedback",
    "投诉",
    "客诉",
    "反馈",
    "type",
    "描述",
    "名称",
    "标题",
    "摘要",
    "商品",
    "产品",
    "类别",
    "分类",
    "国家",
    "地区",
    "城市",
    "地址",
    "状态",
    "备注",
    "评论",
    "类型",
)
_LOCATOR_HEADER_SUFFIXES = ("id", "code", "number", "no", "date", "time")


def json_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            return str(value)
        # Match openpyxl.compat.strings.safe_string's XLSX numeric wire format.
        # Otherwise 2.95 * 1.1 is cached as 3.2450000000000006 but reopens as
        # 3.245, changing a keyless fingerprint immediately after our own save.
        normalized = float(format(value, ".16g"))
        return int(normalized) if normalized.is_integer() else normalized
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral() else float(value)
    return str(value)


def canonical_json(value: Any) -> str:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=json_value
    )


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def canonical_path(path: Path) -> str:
    return str(path.expanduser().resolve())


def make_file_id(path: Path) -> str:
    return "file_" + sha256_text(canonical_path(path).casefold())[:24]


def record_key_hash(key: dict[str, Any]) -> str:
    if not key:
        return ""
    return sha256_text(canonical_json(key))


def make_record_id(
    file_id: str,
    sheet: str,
    key: dict[str, Any],
    fingerprint: str,
    occurrence: int = 1,
) -> str:
    identity = canonical_json(key) if key else f"{fingerprint}#{occurrence}"
    return "rec_" + sha256_text(f"{file_id}\0{sheet}\0{identity}")[:24]


def fingerprint_data(data: dict[str, Any]) -> str:
    meaningful = {
        key: json_value(value)
        for key, value in data.items()
        if value is not None and value != ""
    }
    return sha256_text(canonical_json(meaningful))


def unique_headers(values: Iterable[Any]) -> list[str]:
    headers: list[str] = []
    seen: dict[str, int] = {}
    for index, raw in enumerate(values, 1):
        base = str(raw).strip() if raw is not None and str(raw).strip() else f"Column{index}"
        count = seen.get(base, 0) + 1
        seen[base] = count
        headers.append(base if count == 1 else f"{base}__{count}")
    return headers


def row_data(headers: list[str], values: Iterable[Any]) -> dict[str, Any]:
    converted = [json_value(value) for value in values]
    if len(converted) < len(headers):
        converted.extend([None] * (len(headers) - len(converted)))
    return dict(zip(headers, converted[: len(headers)], strict=True))


def is_blank_record(data: dict[str, Any]) -> bool:
    return all(value is None or value == "" for value in data.values())


def build_content(
    record_id: str,
    file_path: str,
    sheet: str,
    key: dict[str, Any],
    data: dict[str, Any],
) -> str:
    """Build compact semantic text while SQLite remains the full row store.

    Locator metadata (record hash, file, sheet and business IDs) is deliberately
    kept out of the embedding prompt. The FAQ answer carries the record ID, and
    import progress carries an input index, so none of that high-token entropy is
    required for round-tripping a WeKnora result back to SQLite.
    """
    short_locator = record_id.removeprefix("rec_")[:12]
    del file_path, sheet, key

    meaningful = [
        (name, value)
        # Index staging uses canonical JSON; patch reads workbook column order.
        # A semantic representation must not change just because dict order does.
        for name, value in sorted(data.items())
        if value is not None and value != ""
    ]

    def compact_header(name: str) -> str:
        return re.sub(r"[^\w\u3400-\u9fff]", "", name.casefold())

    semantic = []
    for name, value in meaningful:
        normalized = compact_header(name)
        if any(hint in normalized for hint in _SEMANTIC_HEADER_HINTS):
            semantic.append((name, value))
    if not semantic:
        # Generic fallback for sheets without familiar headers: keep human text,
        # but drop obvious IDs/codes/dates that add tokens without semantic value.
        semantic = [
            (name, value)
            for name, value in meaningful
            if isinstance(value, str)
            and any(character.isalpha() for character in value)
            and not compact_header(name).endswith(_LOCATOR_HEADER_SUFFIXES)
        ]
    if not semantic:
        semantic = meaningful[:8]

    lines: list[str] = []
    remaining = 2_000
    for name, value in semantic:
        line = f"{name}: {value}"
        if len(line) > remaining:
            line = line[: max(0, remaining - 3)] + "..."
        if line:
            lines.append(line)
            remaining -= len(line) + 1
        if remaining <= 0:
            break
    # FAQ standard questions must be unique. A 48-bit stable suffix avoids
    # duplicate product descriptions without paying the embedding cost of the
    # full record hash and file/sheet locator metadata.
    lines.append(f"_rid: {short_locator}")
    return "\n".join(lines)


def extract_record_id(*values: Any) -> str | None:
    pattern = re.compile(r"(?:\[?excel-record:|record_id=)(rec_[0-9a-f]{24})\b\]?", re.IGNORECASE)
    for value in values:
        if isinstance(value, str):
            match = pattern.search(value)
            if match:
                return match.group(1).lower()
        elif isinstance(value, list):
            found = extract_record_id(*value)
            if found:
                return found
    return None


def resolve_column(data: dict[str, Any], requested: str) -> str | None:
    if requested in data:
        return requested
    folded = requested.strip().casefold()
    for key in data:
        if key.casefold() == folded:
            return key
    compact = _INVALID_HEADER.sub("", folded)
    for key in data:
        if _INVALID_HEADER.sub("", key.casefold()) == compact:
            return key
    return None


def _comparable(value: Any) -> tuple[str, Any]:
    if isinstance(value, bool):
        return ("bool", value)
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        try:
            return ("number", Decimal(str(value)))
        except InvalidOperation:
            pass
    if isinstance(value, str):
        stripped = value.strip()
        try:
            return ("number", Decimal(stripped))
        except InvalidOperation:
            pass
        try:
            return ("date", datetime.fromisoformat(stripped.replace("Z", "+00:00")))
        except ValueError:
            return ("text", stripped.casefold())
    if isinstance(value, (date, datetime)):
        return ("date", value)
    return ("text", str(value).casefold())


def _compare(left: Any, right: Any, operator: str) -> bool:
    if left is None or right is None:
        if operator == "eq":
            return left is None and right is None
        if operator == "ne":
            return not (left is None and right is None)
        return False
    left_kind, left_value = _comparable(left)
    right_kind, right_value = _comparable(right)
    if left_kind != right_kind:
        left_value, right_value = str(left).casefold(), str(right).casefold()
    if operator == "eq":
        return left_value == right_value
    if operator == "ne":
        return left_value != right_value
    if operator == "lt":
        return left_value < right_value
    if operator == "lte":
        return left_value <= right_value
    if operator == "gt":
        return left_value > right_value
    if operator == "gte":
        return left_value >= right_value
    raise ValueError(f"unsupported filter operator: {operator}")


def validate_filters(filters: dict[str, Any] | None) -> None:
    if filters is None:
        return
    if not isinstance(filters, dict):
        raise ValueError("filters must be an object")
    allowed = {"eq", "ne", "lt", "lte", "gt", "gte", "between", "in", "contains"}
    for column, condition in filters.items():
        if not isinstance(column, str) or not column.strip():
            raise ValueError("filter column names must be nonempty strings")
        if isinstance(condition, list):
            raise ValueError(f'filter {column}: use {{"in": [...]}} for a list')
        if not isinstance(condition, dict):
            continue
        if not condition:
            raise ValueError(f"filter {column} must contain an operator")
        for operator, expected in condition.items():
            op = operator.casefold()
            if op not in allowed:
                raise ValueError(f"unsupported filter operator: {operator}")
            if op == "contains" and not isinstance(expected, str):
                raise ValueError(f'filter {column}.contains must be a string, e.g. {{"contains":"christmas"}}; not an array')
            if op == "between" and (not isinstance(expected, list) or len(expected) != 2):
                raise ValueError(f"filter {column}.between must contain two values")
            if op == "in" and not isinstance(expected, list):
                raise ValueError(f"filter {column}.in must be an array")
            if op not in {"in", "between"} and isinstance(expected, (list, dict)):
                raise ValueError(f"filter {column}.{operator} expects a scalar value")


def validate_filter_columns(filters: dict[str, Any] | None, columns: Iterable[str]) -> None:
    if not filters:
        return
    available = dict.fromkeys(columns)
    missing = [name for name in filters if resolve_column(available, name) is None]
    if missing:
        raise ValueError(
            f"Unknown filter column(s): {', '.join(missing)}. Available columns: "
            f"{', '.join(list(available)[:40])}. For a semantic-only query omit filters; do not invent columns."
        )


def matches_filters(data: dict[str, Any], filters: dict[str, Any] | None) -> bool:
    if not filters:
        return True
    for requested, condition in filters.items():
        column = resolve_column(data, requested)
        if column is None:
            return False
        actual = data[column]
        if isinstance(condition, dict):
            for operator, expected in condition.items():
                op = operator.casefold()
                if op == "between":
                    if not isinstance(expected, list) or len(expected) != 2:
                        raise ValueError(f"filter {requested}.between must contain two values")
                    if not (_compare(actual, expected[0], "gte") and _compare(actual, expected[1], "lte")):
                        return False
                elif op == "in":
                    if not isinstance(expected, list) or not any(_compare(actual, item, "eq") for item in expected):
                        return False
                elif op == "contains":
                    if str(expected).casefold() not in str(actual).casefold():
                        return False
                elif not _compare(actual, expected, op):
                    return False
        elif not _compare(actual, condition, "eq"):
            return False
    return True


def bound_result(value: dict[str, Any], max_chars: int = MAX_RETURN_CHARS) -> dict[str, Any]:
    def encoded() -> str:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=json_value)

    if len(encoded()) <= max_chars:
        return value
    value["truncated"] = True
    for list_key in ("matches", "examples", "failures"):
        items = value.get(list_key)
        if isinstance(items, list):
            while items and len(encoded()) > max_chars:
                items.pop()
            if list_key == "matches" and isinstance(value.get("count"), int):
                value["count"] = len(items)
    if len(encoded()) > max_chars:
        for key, item in list(value.items()):
            if isinstance(item, str) and len(item) > 256:
                value[key] = item[:253] + "..."
    return value
