from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
import urllib.parse
from dataclasses import dataclass
from typing import Any, Iterable

from .config import WeknoraConfig
from .models import Record
from .utils import extract_record_id


class WeknoraError(RuntimeError):
    def __init__(self, message: str, *, status: int | None = None,
                 category: str = "temporary", uncertain: bool = False):
        super().__init__(message)
        self.status = status
        self.category = category
        self.uncertain = uncertain


@dataclass(frozen=True, slots=True)
class WeknoraBinding:
    entry_id: int
    document_id: str | None
    chunk_id: str | None = None


class WeknoraClient:
    """Client for the verified WeKnora batch FAQ ingestion and search contract."""

    def __init__(self, config: WeknoraConfig):
        self.config = config
        self.deadline: float | None = None

    def _request(
        self, method: str, path: str, body: dict[str, Any] | None = None
    ) -> Any:
        if self.deadline and time.monotonic() >= self.deadline:
            raise WeknoraError('request budget exhausted before submission')
        url = f"{self.config.base_url}{path}"
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if self.config.api_key:
            headers["X-API-Key"] = self.config.api_key
        if self.config.tenant_id:
            headers["X-Tenant-ID"] = self.config.tenant_id
        request = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(
                request, timeout=min(self.config.request_timeout, max(0.1, self.deadline - time.monotonic()))
                if self.deadline else self.config.request_timeout
            ) as response:
                raw = response.read()
        except urllib.error.HTTPError as error:
            # Do not persist arbitrary server response bodies (they may echo credentials).
            category = "authorization" if error.code in (401, 403) else "not_found" if error.code == 404 else "configuration" if 400 <= error.code < 500 and error.code != 429 else "temporary"
            raise WeknoraError(f"{method} {path} returned HTTP {error.code}",
                               status=error.code, category=category,
                               uncertain=method == "POST" and error.code >= 500) from error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            reason = getattr(error, "reason", error)
            refused = isinstance(reason, ConnectionRefusedError) or getattr(reason, "winerror", None) == 10061
            raise WeknoraError(f"{method} {path} transport failure ({type(reason).__name__})",
                               uncertain=method == "POST" and not refused) from error
        try:
            payload = json.loads(raw.decode("utf-8")) if raw else {}
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise WeknoraError(f"{method} {path} returned invalid JSON", uncertain=method == "POST") from error
        if isinstance(payload, dict) and payload.get("success") is False:
            raise WeknoraError(
                f"{method} {path} returned success=false", uncertain=method == "POST"
            )
        return payload.get("data", payload) if isinstance(payload, dict) else payload

    def verify_knowledge_base(self) -> dict[str, Any]:
        assert self.config.knowledge_base_id
        data = self._request(
            "GET", f"/knowledge-bases/{self.config.knowledge_base_id}"
        )
        if not isinstance(data, dict):
            raise WeknoraError("knowledge base response is not an object")
        kb_type = str(data.get("type", "")).casefold()
        if kb_type and kb_type != "faq":
            raise WeknoraError(
                f"knowledge base has type {kb_type!r}; an FAQ knowledge base is required", category="configuration"
            )
        return data

    def list_knowledge_bases(self) -> list[dict[str, Any]]:
        result = self._request('GET', '/knowledge-bases')
        if not isinstance(result, list):
            raise WeknoraError('invalid knowledge base listing', category='configuration')
        return result

    def create_knowledge_base(self, name: str, reference: str) -> dict[str, Any]:
        if not self.config.embedding_model_id:
            raise WeknoraError('embedding model must be configured once for automatic workspaces', category='configuration')
        result = self._request('POST', '/knowledge-bases', {
            'name': name, 'description': reference, 'type': 'faq',
            'embedding_model_id': self.config.embedding_model_id,
            'faq_config': {'index_mode': 'question_only', 'question_index_mode': 'combined'}})
        if not isinstance(result, dict) or not result.get('id'):
            raise WeknoraError('KB create response missing ID', category='uncertain', uncertain=True)
        return result

    def get_knowledge_base(self, kb_id: str) -> dict[str, Any] | None:
        try:
            return self._request('GET', f'/knowledge-bases/{urllib.parse.quote(kb_id, safe="")}')
        except WeknoraError as error:
            if error.status == 404:
                return None
            raise

    def delete_knowledge_base(self, kb_id: str) -> None:
        try:
            self._request('DELETE', f'/knowledge-bases/{urllib.parse.quote(kb_id, safe="")}')
        except WeknoraError as error:
            if error.status != 404:
                raise

    def _wait_for_import(self, task_id: str) -> dict[str, Any]:
        deadline = time.monotonic() + self.config.task_timeout
        while True:
            data = self._request("GET", f"/faq/import/progress/{task_id}")
            if not isinstance(data, dict):
                raise WeknoraError("FAQ import progress is not an object")
            status = str(data.get("status", ""))
            if status == "completed":
                return data
            if status == "failed":
                raise WeknoraError(
                    f"FAQ import {task_id} failed: {data.get('error') or data.get('message') or 'unknown error'}"
                )
            if time.monotonic() >= deadline:
                raise WeknoraError(f"FAQ import {task_id} timed out")
            time.sleep(self.config.poll_interval)

    def upsert_records(self, records: list[Record]) -> dict[str, WeknoraBinding]:
        if not records:
            return {}
        assert self.config.knowledge_base_id
        entries = [
            {
                "standard_question": record.content,
                "similar_questions": [],
                "negative_questions": [],
                "answers": [f"record_id={record.record_id}"],
                "answer_strategy": "all",
                "tag_id": 0,
                "tag_name": "",
                "is_enabled": True,
                "is_recommended": False,
            }
            for record in records
        ]
        started = self._request(
            "POST",
            f"/knowledge-bases/{self.config.knowledge_base_id}/faq/entries",
            {"entries": entries, "mode": "append", "knowledge_id": "", "dry_run": False},
        )
        if not isinstance(started, dict) or not started.get("task_id"):
            raise WeknoraError("FAQ batch upsert did not return task_id")
        progress = self._wait_for_import(str(started["task_id"]))
        failed = int(progress.get("failed_count", 0) or 0)
        if failed:
            details = progress.get("failed_entries") or []
            raise WeknoraError(
                f"FAQ batch upsert failed for {failed} record(s): {json.dumps(details[:3], ensure_ascii=False)}"
            )
        bindings: dict[str, WeknoraBinding] = {}
        for item in progress.get("success_entries") or []:
            if not isinstance(item, dict):
                continue
            source_index = item.get("index")
            record_id = (
                records[source_index].record_id
                if isinstance(source_index, int) and 0 <= source_index < len(records)
                else extract_record_id(item.get("standard_question"))
            )
            seq_id = item.get("seq_id")
            if record_id and isinstance(seq_id, int):
                bindings[record_id] = WeknoraBinding(
                    entry_id=seq_id,
                    document_id=str(progress.get("knowledge_id") or "") or None,
                )
        missing = [record.record_id for record in records if record.record_id not in bindings]
        if missing:
            raise WeknoraError(
                "FAQ import completed without locator ids for "
                f"{len(missing)} record(s); first missing record: {missing[0]}"
            )
        return bindings

    def start_import(self, records: list[Record]) -> str:
        """POST only. Caller MUST commit task_id before any progress polling."""
        entries = [{
            "standard_question": record.content,
            "answers": [f"record_id={record.record_id}", f"fingerprint={record.fingerprint}"],
            "similar_questions": [], "negative_questions": [],
            "answer_strategy": "all", "is_enabled": True, "is_recommended": False,
        } for record in records]
        result = self._request("POST", f"/knowledge-bases/{self.config.knowledge_base_id}/faq/entries",
                               {"entries": entries, "mode": "append", "knowledge_id": "", "dry_run": False})
        if not isinstance(result, dict) or not result.get("task_id"):
            raise WeknoraError("FAQ POST did not return task_id", uncertain=True)
        return str(result["task_id"])

    def get_import_progress(self, task_id: str) -> dict[str, Any]:
        result = self._request("GET", f"/faq/import/progress/{urllib.parse.quote(task_id, safe='')}")
        if not isinstance(result, dict):
            raise WeknoraError("invalid FAQ progress response")
        return result

    def get_entry(self, entry_id: int) -> dict[str, Any] | None:
        try:
            return self._request("GET", f"/knowledge-bases/{self.config.knowledge_base_id}/faq/entries/{int(entry_id)}")
        except WeknoraError as error:
            if error.status == 404:
                return None
            raise

    def list_entries(self, *, keyword: str = "", page_size: int = 10) -> dict[str, Any]:
        # Verified handler/faq.go: keyword + search_field, NOT semantic search.
        query = urllib.parse.urlencode({"page": 1, "page_size": page_size,
                                       "keyword": keyword, "search_field": "answers"})
        result = self._request("GET", f"/knowledge-bases/{self.config.knowledge_base_id}/faq/entries?{query}")
        if not isinstance(result, dict) or not isinstance(result.get("data"), list):
            raise WeknoraError("invalid FAQ listing response", category="conflict")
        return {**result, "entries": result["data"]}

    def find_record_entries(self, record_id: str) -> list[dict[str, Any]]:
        result = self.list_entries(keyword=f"record_id={record_id}")
        if int(result.get("total", 0)) > 10:
            raise WeknoraError("too many remote entries for record", category="conflict")
        return [entry for entry in result["entries"] if extract_record_id(entry.get("answers")) == record_id]

    def delete_entries(self, entry_ids: Iterable[int]) -> None:
        assert self.config.knowledge_base_id
        ids = list(dict.fromkeys(int(value) for value in entry_ids))
        for start in range(0, len(ids), self.config.batch_size):
            batch = ids[start : start + self.config.batch_size]
            if batch:
                self._request(
                    "DELETE",
                    f"/knowledge-bases/{self.config.knowledge_base_id}/faq/entries",
                    {"ids": batch},
                )

    def replace_records(self, records: list[Record]) -> dict[str, WeknoraBinding]:
        old_ids = [
            record.weknora_entry_id
            for record in records
            if record.weknora_entry_id is not None
        ]
        self.delete_entries(old_ids)
        bindings: dict[str, WeknoraBinding] = {}
        for start in range(0, len(records), self.config.batch_size):
            batch = records[start : start + self.config.batch_size]
            bindings.update(self.upsert_records(batch))
        return bindings

    def search(self, query: str, match_count: int) -> list[dict[str, Any]]:
        assert self.config.knowledge_base_id
        data = self._request(
            "POST",
            f"/knowledge-bases/{self.config.knowledge_base_id}/faq/search",
            {
                "query_text": query,
                "vector_threshold": self.config.vector_threshold,
                "match_count": min(max(1, match_count), 50),
                "first_priority_tag_ids": [],
                "second_priority_tag_ids": [],
                "only_recommended": False,
            },
        )
        if not isinstance(data, list):
            raise WeknoraError("FAQ search response is not an array")
        return [item for item in data if isinstance(item, dict)]
