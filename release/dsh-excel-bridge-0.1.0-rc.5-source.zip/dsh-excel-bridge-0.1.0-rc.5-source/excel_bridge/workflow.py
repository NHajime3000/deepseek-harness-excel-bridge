"""Single workflow entrance shared by DSH and the administrator CLI."""
from __future__ import annotations
import json
import uuid
from pathlib import Path

from .plan_ir import PlanError, validate_plan
from .procedure import ProcedureEngine
from .sop import SopCompiler


def procedure_run(bridge, args):
    if not bridge.config.workflow.procedure_enabled:
        return {'status': 'disabled', 'message': 'Procedure 功能未启用，请在插件设置中开启。'}
    for flag in ('dry_run', 'confirm'):
        if flag in args and type(args[flag]) is not bool:
            raise PlanError(flag + ' must be boolean')
    engine = ProcedureEngine(bridge)
    if args.get('run_id'):
        with bridge.store.connection() as db:
            known = db.execute('SELECT 1 FROM procedure_runs WHERE run_id=?', (args['run_id'],)).fetchone()
        if not known:
            return {'status':'invalid_arguments', 'message':'run_id 不存在，请勿编造或重复重试编号。新历史复用任务只传 files 和 instruction；新 SOP 任务只传 files 和 procedure_file。'}
        if args.get('dry_run', False):
            return engine.status(args['run_id'])
        return engine.resume(args['run_id'], confirm=args.get('confirm', False))
    files = args.get('files')
    if not isinstance(files, list) or len(files) != 1 or not isinstance(files[0], str):
        raise PlanError('This release executes one XLSX per run; files must contain exactly one path')
    file = str(Path(files[0]).expanduser().resolve())
    if Path(file).suffix.lower() != '.xlsx' or not Path(file).is_file():
        raise PlanError('A real .xlsx input is required')
    recipe_id, procedure_id, plan = args.get('recipe_id'), args.get('procedure_id'), None
    if sum(bool(args.get(k)) for k in ('recipe_id','procedure_id','procedure_file')) > 1:
        return {'status':'invalid_arguments','message':'只选择一个方案来源，不要同时填入多个编号或 SOP 文件。编号必须来自工具返回。'}
    compiler = SopCompiler(bridge.store, bridge.config.workflow)
    if args.get('procedure_file'):
        source = Path(args['procedure_file']).expanduser().resolve()
        if source.suffix.lower() == '.json':
            if source.stat().st_size > 64000:
                raise PlanError('Plan file exceeds 64000 bytes')
            plan = validate_plan(json.loads(source.read_text(encoding='utf-8-sig')))
        else:
            procedure_id = compiler.ingest(source)
    if procedure_id:
        compiled = compiler.compile_next(procedure_id)
        if compiled['status'] != 'validated':
            return compiled
        with bridge.store.connection() as db:
            plan = json.loads(db.execute('SELECT plan_json FROM procedures WHERE procedure_id=?', (procedure_id,)).fetchone()[0])
    if not plan and recipe_id:
        if not bridge.config.workflow.recipe_enabled:
            raise PlanError('Recipe feature is disabled')
        plan = json.loads(engine.memory.get(recipe_id)['plan_json'])
    if not plan:
        instruction = args.get('instruction', '')
        if not isinstance(instruction, str) or not 1 <= len(instruction) <= 2400:
            raise PlanError('Provide a short instruction, an SOP file, a recipe or a saved run')
        indexer, _, _, _ = engine._components(file)
        indexer.index(file)
        columns = engine._columns(engine._records(bridge.store.resolve_file(file)['file_id']))
        candidates = engine.memory.search(instruction, columns) if bridge.config.workflow.recipe_enabled else []
        if candidates:
            first = candidates[0]
            if first['score'] >= .7 and (len(candidates) == 1 or first['score'] - candidates[1]['score'] >= .1):
                recipe_id = first['recipe_id']
                plan = json.loads(engine.memory.get(recipe_id)['plan_json'])
            else:
                return {'status': 'needs_recipe', 'recipes': candidates, 'message': '存在多个历史方案，请选择后预览。'}
        else:
            folder = bridge.config.state_dir / 'procedures'
            folder.mkdir(exist_ok=True)
            reference = folder / ('instruction_' + uuid.uuid4().hex + '.txt')
            reference.write_text(instruction, encoding='utf-8')
            procedure_id = compiler.ingest(reference)
            compiled = compiler.compile_next(procedure_id)
            if compiled['status'] != 'validated':
                return compiled
            with bridge.store.connection() as db:
                plan = json.loads(db.execute('SELECT plan_json FROM procedures WHERE procedure_id=?', (procedure_id,)).fetchone()[0])
    # Even dry_run=false never bypasses initial preview or existing schema mapping.
    return engine.prepare(file, plan, mapping=args.get('mapping'), recipe_id=recipe_id, procedure_id=procedure_id,
                          source_type='sop' if procedure_id else 'manual')
