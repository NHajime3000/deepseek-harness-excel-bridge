"""Admin workflow operations; not additional DSH tools. JSON input on stdin."""
import argparse
import json
import sys
from .maintenance import load_config
from .service import ExcelBridge
from .recipes import RecipeMemory
from .plan_ir import validate_plan


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['run', 'resume', 'approvals', 'approve', 'recipe-create', 'recipe-activate', 'recipe-search', 'validate'])
    parser.add_argument('--connection-file')
    parser.add_argument('--workspace')
    args = parser.parse_args()
    payload = json.loads(sys.stdin.read(128000) or '{}')
    bridge = ExcelBridge(load_config(args.connection_file, args.workspace))
    memory = RecipeMemory(bridge.store)
    if args.command == 'run':
        from .workflow import procedure_run
        result = procedure_run(bridge, payload)
    elif args.command == 'resume':
        from .procedure import ProcedureEngine
        result = ProcedureEngine(bridge).resume(payload['run_id'])
    elif args.command in {'approvals', 'approve'}:
        from .approvals import ApprovalStore
        import getpass
        approvals = ApprovalStore(bridge.store)
        result = {'approvals': approvals.list_pending()} if args.command == 'approvals' else approvals.approve(
            payload['approval_id'], payload['plan_hash'], actor=getpass.getuser())
    elif args.command == 'validate':
        validate_plan(payload)
        result = {'status': 'valid'}
    elif args.command == 'recipe-create':
        result = {'status': 'draft', 'recipe_id': memory.create(payload)}
    elif args.command == 'recipe-activate':
        memory.activate(payload['recipe_id'])
        result = {'status': 'active'}
    else:
        result = {'recipes': memory.search(payload['instruction'], payload['columns'])}
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
