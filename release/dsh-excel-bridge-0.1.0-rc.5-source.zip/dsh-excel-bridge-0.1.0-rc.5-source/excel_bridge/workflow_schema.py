"""Additive v3 schema. Execution locators live in runs, never in templates."""
WORKFLOW_SCHEMA = """
CREATE TABLE IF NOT EXISTS recipes (
 recipe_id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
 intent TEXT NOT NULL, source_type TEXT NOT NULL CHECK(source_type IN ('history','sop','manual','generated')),
 status TEXT NOT NULL CHECK(status IN ('draft','active','archived')),
 created_at REAL NOT NULL, updated_at REAL NOT NULL, last_used_at REAL,
 success_count INTEGER NOT NULL DEFAULT 0, failure_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS recipe_versions (
 version_id TEXT PRIMARY KEY, recipe_id TEXT NOT NULL REFERENCES recipes(recipe_id), version INTEGER NOT NULL,
 plan_json TEXT NOT NULL, required_roles_json TEXT NOT NULL, parameters_json TEXT NOT NULL,
 created_at REAL NOT NULL, UNIQUE(recipe_id,version)
);
CREATE TABLE IF NOT EXISTS field_roles (role TEXT PRIMARY KEY, aliases_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS field_mappings (
 schema_hash TEXT NOT NULL, role TEXT NOT NULL, column_name TEXT NOT NULL,
 source TEXT NOT NULL, confirmed_at REAL NOT NULL, PRIMARY KEY(schema_hash,role)
);
CREATE TABLE IF NOT EXISTS procedures (
 procedure_id TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL,
 plan_json TEXT, source_type TEXT NOT NULL, source_hash TEXT,
 status TEXT NOT NULL, created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS procedure_chunks (
 procedure_id TEXT NOT NULL REFERENCES procedures(procedure_id), ordinal INTEGER NOT NULL,
 text TEXT NOT NULL, result_json TEXT, status TEXT NOT NULL, error TEXT,
 PRIMARY KEY(procedure_id,ordinal)
);
CREATE TABLE IF NOT EXISTS procedure_runs (
 run_id TEXT PRIMARY KEY, procedure_id TEXT NOT NULL REFERENCES procedures(procedure_id),
 file_id TEXT NOT NULL REFERENCES files(file_id), status TEXT NOT NULL, current_step INTEGER NOT NULL DEFAULT 0,
 plan_json TEXT NOT NULL, mapping_json TEXT NOT NULL, preview_json TEXT NOT NULL,
 checkpoint_json TEXT NOT NULL, source_hash TEXT NOT NULL, confirmation_hash TEXT,
 created_at REAL NOT NULL, updated_at REAL NOT NULL, error TEXT
);
CREATE TABLE IF NOT EXISTS procedure_step_runs (
 run_id TEXT NOT NULL REFERENCES procedure_runs(run_id), step_id TEXT NOT NULL, ordinal INTEGER NOT NULL,
 status TEXT NOT NULL, input_summary TEXT NOT NULL, output_locator TEXT NOT NULL,
 summary_json TEXT NOT NULL, started_at REAL, completed_at REAL, error TEXT,
 PRIMARY KEY(run_id,step_id)
);
CREATE TABLE IF NOT EXISTS procedure_items (
 run_id TEXT NOT NULL REFERENCES procedure_runs(run_id), step_id TEXT NOT NULL, record_id TEXT NOT NULL,
 before_json TEXT NOT NULL, after_json TEXT NOT NULL, operation_json TEXT,
 PRIMARY KEY(run_id,step_id,record_id)
);
CREATE TABLE IF NOT EXISTS recipe_runs (
 run_id TEXT PRIMARY KEY REFERENCES procedure_runs(run_id), recipe_id TEXT NOT NULL REFERENCES recipes(recipe_id),
 version INTEGER NOT NULL, file_id TEXT NOT NULL, status TEXT NOT NULL,
 resolved_mapping_json TEXT NOT NULL, preview_json TEXT NOT NULL, result_json TEXT,
 started_at REAL NOT NULL, completed_at REAL, error TEXT
);
CREATE TABLE IF NOT EXISTS recipe_query_context (
 file_id TEXT PRIMARY KEY, query_json TEXT NOT NULL, matches_json TEXT NOT NULL, created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_procedure_runs_status ON procedure_runs(status,updated_at);
CREATE INDEX IF NOT EXISTS idx_recipe_runs_recipe ON recipe_runs(recipe_id,file_id,status);
CREATE TABLE IF NOT EXISTS workflow_bindings (
 session_key TEXT NOT NULL, file_path TEXT NOT NULL, request_hash TEXT NOT NULL,
 procedure_id TEXT, run_id TEXT, request_json TEXT NOT NULL, created_at REAL NOT NULL,
 PRIMARY KEY(session_key,file_path)
);
CREATE TABLE IF NOT EXISTS workflow_approvals (
 approval_id TEXT PRIMARY KEY, kind TEXT NOT NULL, subject TEXT NOT NULL,
 plan_hash TEXT NOT NULL, snapshot_json TEXT NOT NULL, preview_json TEXT NOT NULL,
 state TEXT NOT NULL, created_at REAL NOT NULL, approved_at REAL, approved_by TEXT,
 UNIQUE(kind,subject,plan_hash)
);
CREATE TABLE IF NOT EXISTS approval_events (
 event_id INTEGER PRIMARY KEY AUTOINCREMENT, approval_id TEXT NOT NULL,
 state TEXT NOT NULL, created_at REAL NOT NULL, actor TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS compiler_passes (
 procedure_id TEXT NOT NULL, stage TEXT NOT NULL, item_key TEXT NOT NULL,
 input_hash TEXT NOT NULL, result_json TEXT NOT NULL, usage_json TEXT NOT NULL,
 elapsed_seconds REAL NOT NULL, created_at REAL NOT NULL,
 PRIMARY KEY(procedure_id,stage,item_key)
);
"""
