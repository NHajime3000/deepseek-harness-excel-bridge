"""File-scoped, crash-recoverable KB lifecycle; no model-facing KB administration."""
from __future__ import annotations

import json
import re
import time
import uuid
import zipfile
from dataclasses import replace
from pathlib import Path

from openpyxl import load_workbook

from .faults import checkpoint
from .indexer import ExcelIndexer
from .locking import bridge_lock
from .outbox import Outbox, STATUSES
from .patcher import ExcelPatcher
from .query import ExcelQuery
from .reconcile import file_hash, reconcile
from .utils import canonical_path, make_file_id
from .weknora_client import WeknoraClient, WeknoraError


class WorkspaceError(RuntimeError):
    def __init__(self, category, message, status='workspace_error'):
        super().__init__(message)
        self.category, self.status = category, status

    def result(self, file):
        return {'status': self.status, 'file': Path(file).name, 'message': str(self), 'category': self.category}


class WorkspaceManager:
    def __init__(self, store, config):
        self.store, self.config = store, config
        self.client = WeknoraClient(config.weknora) if config.weknora.enabled else None

    def get(self, reference):
        candidate = Path(reference).expanduser()
        with self.store.connection() as connection:
            row = connection.execute('SELECT * FROM file_workspaces WHERE file_id=? OR file_path=? COLLATE NOCASE',
                                     (str(reference), canonical_path(candidate))).fetchone()
            if row:
                return row
            # An absolute/new path must never silently match another file's name.
            if candidate.is_absolute() or candidate.exists():
                return None
            rows = connection.execute('SELECT * FROM file_workspaces WHERE file_name=? COLLATE NOCASE', (candidate.name,)).fetchall()
            if len(rows) > 1:
                raise WorkspaceError('ambiguous', '文件名不唯一，请提供完整路径。')
            return rows[0] if rows else None

    def _update(self, file_id, **values):
        values['updated_at'] = time.time()
        with self.store.connection() as connection:
            connection.execute(f"UPDATE file_workspaces SET {','.join(k+'=?' for k in values)} WHERE file_id=?", (*values.values(), file_id))
        return self.get(file_id)

    def _check_destination(self, mapping):
        if not self.client:
            raise WorkspaceError('configuration', 'WeKnora 已禁用；文件 Workspace 操作暂停，不会发送远端请求。')
        if (mapping['base_url'] != self.config.weknora.base_url
                or str(mapping['tenant_id'] or '') != str(self.config.weknora.tenant_id or '')):
            raise WorkspaceError('configuration', '连接目的地与文件的持久绑定不同；请恢复原连接配置。')

    def ensure_workspace(self, file, *, retry=False):
        with bridge_lock(self.store):
            mapping = self.get(file)
            path = Path(mapping['file_path']) if mapping else Path(file).expanduser().resolve()
            if mapping and mapping['kb_status'] in ('deleted', 'deleting'):
                raise WorkspaceError('deleted', 'Workspace 已删除或正在删除，不会自动重建。')
            if not path.is_file():
                if mapping:
                    self._update(mapping['file_id'], kb_status='orphaned', error_category='local_file_missing', last_error='local_file_missing')
                raise WorkspaceError('local_file_missing', 'Excel 文件不存在；已保留知识库，请核对路径或重新绑定。')
            if path.suffix.casefold() != '.xlsx':
                raise WorkspaceError('configuration', '仅支持 .xlsx 文件。')
            if not mapping:
                if not self.config.weknora.auto_create_kb:
                    raise WorkspaceError('configuration', '自动建库已禁用，请启用 Excel Bridge 自动建库配置。')
                file_id = self.store.file_id_for_path(path)
                name = 'excel_' + re.sub(r'[^\w\-]', '_', path.stem)[:60] + '_' + file_id.removeprefix('file_')[:12]
                token = 'excel-bridge-workspace:' + uuid.uuid4().hex
                now = time.time()
                with self.store.connection() as connection:
                    connection.execute("""INSERT INTO file_workspaces(file_id,file_path,file_name,base_url,tenant_id,
                        knowledge_base_name,kb_status,kb_created_by_bridge,intent_token,created_at,updated_at)
                        VALUES (?,?,?,?,?,?,'creating',1,?,?,?)""", (file_id, canonical_path(path), path.name,
                        self.config.weknora.base_url, self.config.weknora.tenant_id, name, token, now, now))
                mapping = self.get(file_id)
            self._check_destination(mapping)
            if mapping['kb_status'] in ('deleted', 'deleting'):
                raise WorkspaceError('deleted', '此文件 Workspace 已解除或正在解除索引；请使用维护命令处理，不会自动重建。')
            if mapping['kb_status'] == 'error' and not retry and mapping['error_category'] in ('authorization','configuration','conflict','uncertain'):
                raise WorkspaceError(mapping['error_category'], 'Workspace 创建被阻止；修复连接或权限后运行 workspace-reconcile --retry。')
            if mapping['knowledge_base_id']:
                return mapping
            if not self.client:
                raise WorkspaceError('configuration', 'WeKnora 已禁用。')
            try:
                if not self.config.weknora.embedding_model_id:
                    raise WeknoraError('configure an embedding model once for workspace mode', category='configuration')
                # A create response can be lost. Search exact name AND random
                # persisted ownership reference, never adopt another user's KB.
                if mapping['phase'] == 'posting':
                    same_name = [kb for kb in self.client.list_knowledge_bases() if kb.get('name') == mapping['knowledge_base_name']]
                    matches = [kb for kb in same_name if kb.get('description') == mapping['intent_token'] and kb.get('type') == 'faq']
                    if len(matches) == 1 and len(same_name) == 1:
                        return self._update(mapping['file_id'], knowledge_base_id=matches[0]['id'], kb_status='syncing', phase='bound', error_category=None, last_error=None)
                    # A listing with no match is NOT proof that an outstanding
                    # server request cannot commit later. Refuse blind POST.
                    raise WeknoraError('KB creation outcome cannot be uniquely confirmed', category='conflict' if same_name else 'uncertain')
                self._update(mapping['file_id'], kb_status='creating', phase='posting')
                created = self.client.create_knowledge_base(mapping['knowledge_base_name'], mapping['intent_token'])
                checkpoint('FAIL_AFTER_KB_CREATE')
                mapping = self._update(mapping['file_id'], knowledge_base_id=created['id'], kb_status='syncing', phase='bound', error_category=None, last_error=None)
                if not self.client.get_knowledge_base(created['id']):
                    raise WeknoraError('new knowledge base missing', category='not_found')
                return mapping
            except WeknoraError as error:
                # Only explicit rejection / connection refusal permits resubmission.
                phase = self.get(mapping['file_id'])['phase']
                if phase == 'posting' and not error.uncertain and error.category not in ('uncertain','conflict'):
                    phase = 'prepared'
                self._update(mapping['file_id'], kb_status='error', error_category=error.category,
                             last_error='KB setup failed; correct configuration or recover the persisted intent', phase=phase)
                raise WorkspaceError(error.category, '知识库暂不可用，已保留建库进度；恢复服务后重试查询。') from None

    def components(self, mapping, *, seconds=None):
        self._check_destination(mapping)
        if mapping['kb_status'] in ('deleted','deleting','orphaned'):
            raise WorkspaceError(mapping['kb_status'], 'Workspace 当前不可用，请检查文件或运行维护对账。')
        client = WeknoraClient(replace(self.config.weknora, knowledge_base_id=mapping['knowledge_base_id']))
        config = self.config.outbox if seconds is None else replace(self.config.outbox, immediate_seconds=max(.1, seconds))
        worker = Outbox(self.store, client, config, file_id=mapping['file_id'])
        return ExcelIndexer(self.store, client, worker), ExcelQuery(self.store, client), ExcelPatcher(self.store, client, self.config.backup_dir, worker), worker

    def small_enough(self, path):
        # query's actual DSH timeout is 60s. Bound discovery before reading cells,
        # including highly compressed XLSX or shared-string-heavy workbooks.
        if path.stat().st_size > 2_000_000:
            return False, None
        with zipfile.ZipFile(path) as archive:
            if sum(i.file_size for i in archive.infolist()) > 8_000_000:
                return False, None
        book = load_workbook(path, read_only=True)
        count = 0
        try:
            for sheet in book:
                for _ in sheet.iter_rows(min_row=2, values_only=True):
                    count += 1
                    if count > self.config.query_index_max_rows:
                        return False, count
        finally:
            book.close()
        return True, count

    def ensure_index(self, file, *, force=False, query=False, deadline=None):
        with bridge_lock(self.store):
            mapping = self.get(file)
            path = Path(mapping['file_path']) if mapping else Path(file).expanduser().resolve()
            existing = self.store.get_file_by_id(mapping['file_id']) if mapping else None
            changed = not existing or not path.is_file() or (path.stat().st_size, path.stat().st_mtime_ns) != (existing['file_size'], existing['modified_time_ns'])
            if query and changed and path.is_file():
                if not self.config.auto_index_on_query:
                    raise WorkspaceError('indexing_required', '自动索引已禁用，请先调用 excel_index。', 'indexing_required')
                small, estimate = self.small_enough(path)
                if not small:
                    raise WorkspaceError('large_file', '首次或增量索引预计超过查询时限，请调用 excel_index(file)，完成后再查询。', 'indexing_required')
            if self.client:
                self.client.deadline = deadline
            try:
                mapping = self.ensure_workspace(file)
            finally:
                if self.client:
                    self.client.deadline = None
            if deadline and time.monotonic() >= deadline:
                raise WorkspaceError('budget', '建库进度已保存，请重试查询继续索引。', 'indexing')
            indexer, querier, patcher, worker = self.components(mapping, seconds=max(.1, deadline-time.monotonic()) if deadline else None)
            worker.client.deadline = deadline
            indexed = indexer.index(mapping['file_path'], force)
            stats = worker.get_outbox_stats(mapping['file_id'])
            pending = sum(stats[s] for s in ('pending','processing','retry','blocked','failed'))
            mapping = self._update(mapping['file_id'], kb_status='syncing' if pending else 'ready',
                                   last_indexed_at=time.time(), last_synced_at=None if pending else time.time(),
                                   file_hash=file_hash(path) if changed or force or not mapping['file_hash'] else mapping['file_hash'],
                                   error_category=None, last_error=None)
            return mapping, indexed, (indexer, querier, patcher, worker)

    def list_workspaces(self):
        with self.store.connection() as connection:
            return [dict(r) for r in connection.execute('SELECT * FROM file_workspaces ORDER BY created_at')]

    def rebind(self, file, new_path):
        with bridge_lock(self.store):
            mapping = self.get(file)
            if not mapping:
                raise WorkspaceError('not_found', 'Workspace 不存在。')
            self._check_destination(mapping)
            if mapping['kb_status'] in ('deleted','deleting'):
                raise WorkspaceError('deleted', '已删除或删除中的 Workspace 不允许重新绑定。')
            path = Path(new_path).expanduser().resolve()
            if not path.is_file() or not mapping['file_hash'] or file_hash(path) != mapping['file_hash']:
                raise WorkspaceError('ambiguous', '新文件与已知内容摘要不一致，拒绝猜测身份。')
            collision = self.get(str(path))
            if collision and collision['file_id'] != mapping['file_id']:
                raise WorkspaceError('ambiguous', '新路径已经绑定其他文件。')
            if Path(mapping['file_path']).exists() and canonical_path(path) != mapping['file_path']:
                raise WorkspaceError('ambiguous', '原文件仍存在；副本不能自动认定为移动。')
            with self.store.connection() as connection:
                if connection.execute("SELECT 1 FROM patch_intents WHERE file_id=? AND status IN ('prepared','blocked')", (mapping['file_id'],)).fetchone():
                    raise WorkspaceError('ambiguous', '存在未确认的写入，请先恢复后再移动。')
                connection.execute('UPDATE files SET file_path=?,file_name=?,file_size=?,modified_time_ns=? WHERE file_id=?',
                                   (canonical_path(path), path.name, path.stat().st_size, path.stat().st_mtime_ns, mapping['file_id']))
            return dict(self._update(mapping['file_id'], file_path=canonical_path(path), file_name=path.name, kb_status='syncing', error_category=None, last_error=None))

    def delete_workspace(self, file):
        with bridge_lock(self.store):
            mapping = self.get(file)
            if not mapping:
                raise WorkspaceError('not_found', 'Workspace 不存在。')
            self._check_destination(mapping)
            if mapping['kb_status'] == 'deleted':
                return {'status':'deleted', 'file':mapping['file_name']}
            # Legacy user-owned/shared KBs are never deleted by this operation.
            if not mapping['kb_created_by_bridge']:
                raise WorkspaceError('legacy', '旧模式知识库非 Bridge 独占所有；拒绝删除，请保留旧连接或人工解除。')
            mapping = self._update(mapping['file_id'], kb_status='deleting')
            with self.store.connection() as connection:
                active = connection.execute("SELECT * FROM outbox_tasks WHERE file_id=? AND status NOT IN ('completed','superseded')", (mapping['file_id'],)).fetchall()
                connection.execute("UPDATE outbox_tasks SET status='blocked',error_category='workspace_deleting' WHERE file_id=? AND status NOT IN ('completed','superseded')", (mapping['file_id'],))
            try:
                for task in active:
                    if task['remote_task_id']:
                        progress = self.client.get_import_progress(task['remote_task_id'])
                        if progress.get('status') not in ('completed','failed'):
                            return {'status':'deleting', 'message':'等待已提交的远端任务结束；请重试维护删除。'}
                    elif json.loads(task['payload_json']).get('phase') == 'posting':
                        raise WeknoraError('unknown import outcome prevents safe workspace deletion', category='uncertain')
                if mapping['knowledge_base_id']:
                    self.client.delete_knowledge_base(mapping['knowledge_base_id'])
                    checkpoint('FAIL_AFTER_KB_DELETE')
                    if self.client.get_knowledge_base(mapping['knowledge_base_id']):
                        return {'status':'deleting', 'message':'远端仍在删除，请稍后重试。'}
                elif mapping['phase'] == 'posting':
                    raise WeknoraError('unknown KB creation outcome', category='uncertain')
            except WeknoraError as error:
                self._update(mapping['file_id'], error_category=error.category, last_error='KB deletion requires retry/reconciliation')
                return {'status':'deleting', 'category':error.category, 'message':'未忘记知识库绑定，修复后重试删除。'}
            with self.store.connection() as connection:
                connection.execute("UPDATE files SET status='workspace_deleted' WHERE file_id=?", (mapping['file_id'],))
                connection.execute("UPDATE outbox_tasks SET status='superseded',completed_at=?,worker_id=NULL,locked_at=NULL WHERE file_id=? AND status NOT IN ('completed','superseded')", (time.time(), mapping['file_id']))
            self._update(mapping['file_id'], kb_status='deleted', deleted_at=time.time(), phase='deleted', error_category=None, last_error=None)
            return {'status':'deleted', 'file':mapping['file_name'], 'local_records':'retained_for_audit'}

    def reconcile(self, file=None, *, retry=False, max_seconds=45, remote_limit=20):
        results = []
        mappings = [self.get(file)] if file else self.list_workspaces()
        deadline = time.monotonic() + max_seconds
        for mapping in mappings:
            if not mapping or time.monotonic() >= deadline:
                break
            try:
                if mapping['kb_status'] == 'deleted':
                    continue
                if mapping['kb_status'] == 'deleting':
                    results.append(self.delete_workspace(mapping['file_id']))
                    continue
                mapping = self.ensure_workspace(mapping['file_id'], retry=retry)
                self._check_destination(mapping)
                if not self.client.get_knowledge_base(mapping['knowledge_base_id']):
                    self._update(mapping['file_id'], kb_status='orphaned', error_category='remote_kb_missing', last_error='remote_kb_missing')
                    results.append({'file':mapping['file_name'], 'status':'orphaned', 'reason':'remote_kb_missing'})
                    continue
                if mapping['kb_status'] == 'orphaned':
                    mapping = self._update(mapping['file_id'], kb_status='syncing')
                worker = self.components(mapping)[3]
                result = reconcile(self.store, worker, file_id=mapping['file_id'], max_seconds=max(.1, deadline-time.monotonic()), remote_limit=remote_limit)
                results.append({'file':mapping['file_name'], **result})
            except (WorkspaceError, WeknoraError) as error:
                results.append({'file':mapping['file_name'], 'status':'orphaned' if getattr(error,'category','')=='local_file_missing' else 'error',
                                'reason':error.category})
        return {'workspaces':results}


class RoutedOutbox:
    """Maintenance facade: never mix two file destinations in an HTTP batch."""
    def __init__(self, manager):
        self.manager = manager
        self.store = manager.store
        self.stats = Outbox(self.store, None, manager.config.outbox)

    def get_outbox_stats(self, file_id=None):
        return self.stats.get_outbox_stats(file_id)

    def run_until_idle(self, *, file_id=None, max_tasks=100000, max_seconds=45):
        deadline = time.monotonic() + max_seconds
        processed, errors = 0, []
        for mapping in self.manager.list_workspaces():
            if file_id and mapping['file_id'] != file_id:
                continue
            if mapping['kb_status'] in ('deleted','deleting'):
                continue
            if processed >= max_tasks or time.monotonic() >= deadline:
                break
            try:
                mapping = self.manager.ensure_workspace(mapping['file_id'])
                if not self.store.get_file_by_id(mapping['file_id']):
                    # Recover the gap between durable KB binding and first index.
                    mapping, _, _ = self.manager.ensure_index(mapping['file_id'], deadline=deadline)
                worker = self.manager.components(mapping)[3]
                result = worker.run_until_idle(max_tasks=max_tasks-processed, max_seconds=max(.1, deadline-time.monotonic()))
                processed += result['processed']
                stats = worker.get_outbox_stats(mapping['file_id'])
                ready = not any(stats[s] for s in ('pending','retry','processing','failed','blocked'))
                self.manager._update(mapping['file_id'], kb_status='ready' if ready else 'syncing', last_synced_at=time.time() if ready else None)
            except WorkspaceError as error:
                errors.append({'file':mapping['file_name'], 'category':error.category})
        return {'processed':processed, **self.get_outbox_stats(file_id), 'workspace_errors':errors[:5]}

    def run_once(self, **kwargs):
        return self.run_until_idle(max_tasks=self.manager.config.weknora.batch_size, **kwargs)
