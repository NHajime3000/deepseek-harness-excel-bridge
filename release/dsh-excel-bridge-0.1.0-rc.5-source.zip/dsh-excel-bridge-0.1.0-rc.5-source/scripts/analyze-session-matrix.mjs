import {readFileSync, readdirSync, writeFileSync, existsSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {resolve, join} from 'node:path'
const root=resolve(process.argv[2])
const expected={normal:'waiting_confirmation',renamed:'waiting_confirmation',missing:'needs_mapping',
  two:'needs_review',none:'no_recipe_match',low:'needs_review',wrong:'invalid_file',ambiguous:'needs_mapping'}
const cases=[]
for (const dir of readdirSync(root,{withFileTypes:true}).filter(d=>d.isDirectory()).sort((a,b)=>a.name.localeCompare(b.name))) {
  const r=JSON.parse(readFileSync(join(root,dir.name,'session-report.json'),'utf8'))
  const calls=r.history.filter(e=>e.type==='tool/call').map(e=>e.data)
  const results=r.history.filter(e=>e.type==='tool/result').flatMap(e=>e.data.message.content)
    .flatMap(c=>c.content||[]).filter(c=>c.type==='text').map(c=>{try{return JSON.parse(c.text)}catch{return {raw:c.text}}})
  const workflow=calls.filter(c=>c.name==='procedure_run').map(c=>{try{return JSON.parse(c.arguments)}catch{return {invalid_json:true}}})
  const contract=workflow.length>0 && workflow.every(a=>Object.keys(a).sort().join(',')==='files,instruction'
    && typeof a.instruction==='string' && a.instruction.trim() && Array.isArray(a.files) && a.files.length===1
    && a.files[0].replaceAll('\\','/').toLowerCase()===join(root,dir.name,r.scenario==='wrong'?'不存在.xlsx':'待处理.xlsx').replaceAll('\\','/').toLowerCase())
  const status=results.at(-1)?.status||'no_backend_status'
  let unchanged=r.workbookUnchanged??null
  if(process.argv[3]){
    const fixture=r.scenario==='normal'?'投诉A.xlsx':r.scenario==='missing'?'缺字段.xlsx':r.scenario==='ambiguous'?'字段歧义.xlsx':'投诉B.xlsx'
    const file=join(root,dir.name,r.scenario==='wrong'?'不存在.xlsx':'待处理.xlsx')
    const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex')
    unchanged=r.scenario==='wrong'?!existsSync(file):hash(file)===hash(join(resolve(process.argv[3]),fixture))
  }
  const usages=r.history.filter(e=>e.type==='assistant/message').map(e=>e.usage||{})
  cases.push({case:dir.name,scenario:r.scenario,sessionId:r.sessionId,turnStatus:r.status,backendStatus:status,
    expected:expected[r.scenario],contractPassed:!!contract,workbookUnchanged:unchanged,
    passed:!!contract&&r.status==='completed'&&status===expected[r.scenario]&&unchanged!==false,
    statuses:results.map(r=>r.status||'tool_error'),toolNames:calls.map(c=>c.name),toolCalls:calls.length,
    modelSteps:r.projections.sessionStats?.steps,context:r.maxObservedContext,
    maxActualInputTokens:Math.max(0,...usages.map(u=>(u.inputTokens||0)+(u.cacheReadTokens||0))),
    systemTokens:r.projections.contextBreakdown?.systemTokens,toolsTokens:r.projections.contextBreakdown?.toolsTokens,
    dialogTokens:r.projections.contextBreakdown?.messageTokens,
    overflow:JSON.stringify(r.history).match(/context (?:size|window|overflow|limit)|exceed.{0,20}context/ig)?.length||0})
}
const report={sessions:cases.length,uniqueSessions:new Set(cases.map(c=>c.sessionId)).size,passed:cases.filter(c=>c.passed).length,
  contractPassed:cases.filter(c=>c.contractPassed).length,maxContext:Math.max(...cases.map(c=>c.context)),
  maxActualInputTokens:Math.max(...cases.map(c=>c.maxActualInputTokens)),overflowEvents:cases.reduce((n,c)=>n+c.overflow,0),
  interpretation:'Pass means expected routing/approval stop, not automatic workbook modification. Context is sampled DSH pressure/projection; actual input includes cache reads.',cases}
writeFileSync(join(root,'matrix-analysis.json'),JSON.stringify(report,null,2))
console.log(JSON.stringify(report))
