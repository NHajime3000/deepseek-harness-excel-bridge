import {readFileSync,writeFileSync} from 'node:fs'
import {gunzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {resolve,join} from 'node:path'
const [archive,installed,output]=process.argv.slice(2)
if (!archive||!installed||!output) throw new Error('archive installed-package output-report required')
const blob=readFileSync(archive), tar=gunzipSync(blob), files=[]
const conn=JSON.parse(readFileSync(process.env.EXCEL_BRIDGE_AUDIT_CONNECTION,'utf8'))
const secrets=Object.entries(conn).filter(([k,v])=>/key|secret|token/i.test(k)&&typeof v==='string'&&v.length>=8).map(([,v])=>v)
const hash=data=>createHash('sha256').update(data).digest('hex')
for (let offset=0; offset+512<=tar.length;) {
  const header=tar.subarray(offset,offset+512)
  const name=header.subarray(0,100).toString().split('\0')[0]
  if (!name) break
  const size=parseInt(header.subarray(124,136).toString().replaceAll('\0','').trim(),8)||0
  const data=tar.subarray(offset+512,offset+512+size)
  offset+=512+Math.ceil(size/512)*512
  if (header[156]===53) continue
  if (!name.startsWith('package/')||name.includes('..')||/\.real_validation|\.xlsx$|\.db$|connection.*\.json|node_modules/.test(name)) throw new Error('Unexpected archive target')
  const file=name.slice(8), text=data.toString('utf8')
  if (secrets.some(s=>text.includes(s))) throw new Error('Credential in release: '+file)
  if (/(?:[CDE]:[\\/](?:DSH_plugin|deepseekHarness|test2|Users))/.test(text)) throw new Error('Host-specific path in release: '+file)
  const installedData=readFileSync(join(resolve(installed),file))
  if (hash(installedData)!==hash(data)) throw new Error('Installed artifact differs: '+file)
  files.push({file,bytes:data.length,sha256:hash(data)})
}
const report={archive:archive.split(/[\\/]/).at(-1),sha256:hash(blob),files,entryCount:files.length,
  installedFilesMatch:true,realCredentialScan:'passed',hostPathScan:'passed',remotePublished:false}
writeFileSync(output,JSON.stringify(report,null,2))
console.log(JSON.stringify({...report,files:undefined}))
