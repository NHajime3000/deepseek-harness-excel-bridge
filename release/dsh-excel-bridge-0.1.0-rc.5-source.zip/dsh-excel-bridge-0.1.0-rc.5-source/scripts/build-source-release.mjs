// Build an explicit public source allowlist. Never copy workspaces, credentials or virtualenvs.
import {readdirSync,readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs'
import {resolve,relative,join,dirname} from 'node:path'
import {fileURLToPath} from 'node:url'
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..')
const version=JSON.parse(readFileSync(join(root,'package.json'),'utf8')).version
if (!/^[0-9A-Za-z.-]+$/.test(version)) throw new Error('Invalid release version')
const dest=join(root,'release',`dsh-excel-bridge-${version}-source`)
if (existsSync(dest)) throw new Error('Source release exists; retain evidence and use a new version/directory')
const files=['package.json','pyproject.toml','requirements.txt','README.md','LICENSE','.gitignore','cordis.patch.yml']
for (const folder of ['src','excel_bridge','tests','docs']) {
  for (const entry of readdirSync(join(root,folder),{withFileTypes:true})) {
    if (entry.isFile() && /\.(py|mjs|js|md|yml)$/.test(entry.name)) files.push(join(folder,entry.name))
  }
}
// Legacy RC3 drivers used confirm/run_id as model arguments; retain them only as local historical evidence.
for (const name of ['run-tests.mjs','setup-python.ps1','dsh-rpc.mjs','dsh-rc-validation.mjs','verify-rc-ui.mjs',
                     'rc4-compiler-validation.py','rc5-dsh-case.mjs','analyze-session-matrix.mjs',
                     'audit-release.mjs','build-source-release.mjs']) files.push(join('scripts',name))
const secrets=process.env.EXCEL_BRIDGE_AUDIT_CONNECTION ? Object.entries(JSON.parse(readFileSync(process.env.EXCEL_BRIDGE_AUDIT_CONNECTION,'utf8')))
  .filter(([k,v])=>/key|secret|token/i.test(k)&&typeof v==='string'&&v.length>=8).map(([,v])=>v) : []
const audit=[]
for (const file of files) {
  let content=readFileSync(join(root,file),'utf8')
  if (file.startsWith('docs') && /methodology|outbox-recovery|workspace-lifecycle/.test(file)) {
    content=content.replace(/[CDE]:[\\/][^\s`"<>\r\n)]+/g,'<operator-local-path>')
    content='<!-- Public export: operator-local paths redacted; original evidence stays outside this release. -->\n'+content
  }
  if (secrets.some(secret=>content.includes(secret))) throw new Error('Credential leak detected in '+file)
  const target=join(dest,file)
  mkdirSync(dirname(target),{recursive:true});writeFileSync(target,content)
  audit.push(relative(dest,target).replaceAll('\\','/'))
}
writeFileSync(join(dest,'SOURCE-MANIFEST.json'),JSON.stringify({version,files:audit,credentialCheck:secrets.length?'passed':'not_configured',
  exclusions:['.real_validation','outputs','backups','workspaces','node_modules','.venv','Excel files','databases','credentials'],
  remotePublished:false},null,2))
console.log(JSON.stringify({source:dest,files:audit.length,remotePublished:false}))
