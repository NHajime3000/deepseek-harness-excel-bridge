// Explicit test-only driver. Credentials are copied in memory, never logged.
import { readFileSync, writeFileSync, mkdirSync, realpathSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { dshRpc } from './dsh-rpc.mjs'
const [stage, rootArg, label = 'ordinary', prompt] = process.argv.slice(2)
if (!stage || !rootArg) throw new Error('stage and evidence directory required')
const root = resolve(rootArg); mkdirSync(root, { recursive:true })
const path = join(root, `dsh-${label}.json`)
const target = process.env.EXCEL_BRIDGE_DSH_URL
if (!target) throw new Error('Set explicit test DSH URL')
if (stage === 'configure') {
  if (!process.env.EXCEL_BRIDGE_CONNECTION_FILE || !process.env.EXCEL_BRIDGE_PYTHON) throw new Error('Explicit test credentials/Python required')
  process.env.EXCEL_BRIDGE_DSH_URL = process.env.EXCEL_BRIDGE_SOURCE_DSH_URL || 'http://127.0.0.1:3080'
  const source = await dshRpc('settings.describe')
  const host = await dshRpc('host.describe')
  process.env.EXCEL_BRIDGE_DSH_URL = target
  async function update(ns, patch) {
    const current = (await dshRpc('settings.describe')).namespaces.find(n=>n.ns===ns)
    return dshRpc('settings.update',{ns,patch,expectedRevision:current.revision})
  }
  await update('llm-pi-ai', source.namespaces.find(n=>n.ns==='llm-pi-ai').value)
  await update('agent-default-model', {provider:host.provider,model:host.model})
  await update('excel-bridge', {enabled:true,config:{
    connectionFile:resolve(process.env.EXCEL_BRIDGE_CONNECTION_FILE), workspaceRoot:root,
    pythonPath:resolve(process.env.EXCEL_BRIDGE_PYTHON), procedureEnabled:true,recipeEnabled:true,
    compilerBaseUrl:'http://127.0.0.1:55555/v1',compilerModel:host.model,
  }})
  console.log(JSON.stringify({configured:true,url:target,model:host.model}))
} else {
  let report
  if (stage === 'start') {
    if (!prompt) throw new Error('Natural-language prompt required')
    const host = await dshRpc('host.describe')
    const session = await dshRpc('session.create',{cwd:root})
    await dshRpc('session.rename',{sessionId:session.sessionId,title:`Excel Bridge RC ${label} 验收`})
    await dshRpc('session.selectModel',{sessionId:session.sessionId,provider:host.provider,model:host.model,reasoningEffort:'off'})
    report={sessionId:session.sessionId,model:host.model,startedAt:new Date().toISOString(),prompts:[prompt]}
    writeFileSync(path,JSON.stringify(report,null,2))
    await dshRpc('session.prompt',{sessionId:session.sessionId,mode:'queue',content:[{type:'text',text:prompt}],clientTimeZone:'Asia/Hong_Kong'})
  } else {
    report=JSON.parse(readFileSync(path,'utf8'))
    if (stage==='prompt') {
      if (!prompt) throw new Error('Follow-up required')
      report.prompts.push(prompt)
      await dshRpc('session.prompt',{sessionId:report.sessionId,mode:'queue',content:[{type:'text',text:prompt}],clientTimeZone:'Asia/Hong_Kong'})
    }
  }
  const history=await dshRpc('session.history',{sessionId:report.sessionId,maxMessages:80})
  const events=history.events.map(e=>e.event)
  report.events=events.filter(e=>['tool/call','tool/result','assistant/message','turn/start','turn/end','step/end'].includes(e.type))
    .map(({type,seq,time,data})=>type==='assistant/message'?{type,seq,time,content:data.message.content.filter(c=>c.type!=='reasoning'),usage:data.usage}:{type,seq,time,data})
  report.projections=Object.fromEntries(Object.entries(history.projections?.values||{}).filter(([k])=>['sessionStats','tokenUsage','contextPressure','contextBreakdown'].includes(k)))
  report.headers=events.filter(e=>e.type==='request/header').map(e=>{
    const tools=e.data.header.tools
    return {seq:e.seq,tools:tools.map(t=>t.name),allToolChars:JSON.stringify(tools).length,
      bridgeToolChars:JSON.stringify(tools.filter(t=>t.name.startsWith('excel_')||t.name==='procedure_run')).length}
  })
  const start=events.filter(e=>e.type==='turn/start').at(-1), end=events.filter(e=>e.type==='turn/end').at(-1)
  report.status=start&&end&&start.data.turn===end.data.turn?end.data.reason.kind:'running'
  writeFileSync(path,JSON.stringify(report,null,2))
  console.log(JSON.stringify({sessionId:report.sessionId,status:report.status,calls:report.events.filter(e=>e.type==='tool/call').map(e=>e.data),projections:report.projections}))
}
