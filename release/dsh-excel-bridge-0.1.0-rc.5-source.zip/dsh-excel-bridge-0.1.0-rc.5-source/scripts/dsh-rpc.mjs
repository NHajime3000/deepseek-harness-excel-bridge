import { randomUUID } from 'node:crypto'
export async function dshRpc(method, payload = {}) {
  const origin = process.env.EXCEL_BRIDGE_DSH_URL || 'http://127.0.0.1:3080'
  const response = await fetch(`${origin}/api/${method}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Origin': origin },
    body: JSON.stringify({ type: 'client-request', rpcId: randomUUID(), method, payload }),
    signal: AbortSignal.timeout(90000),
  })
  if (!response.ok) throw new Error(`${method}: HTTP ${response.status}: ${(await response.text()).slice(0, 500)}`)
  const body = await response.json()
  if (!body.result?.ok) throw new Error(`${method}: ${JSON.stringify(body.result?.error)}`)
  return body.result.value
}
