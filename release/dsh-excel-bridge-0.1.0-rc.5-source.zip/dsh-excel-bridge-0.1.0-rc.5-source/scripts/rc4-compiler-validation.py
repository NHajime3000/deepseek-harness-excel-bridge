"""Actual compiler trials. Never repair rejected plans or count fixtures as compilation."""
import argparse
import json
import time
from pathlib import Path
from excel_bridge.config import BridgeConfig, WeknoraConfig, WorkflowConfig
from excel_bridge.service import ExcelBridge
from excel_bridge.sop import SopCompiler

parser = argparse.ArgumentParser()
parser.add_argument('--root', required=True)
parser.add_argument('--sop', required=True)
parser.add_argument('--endpoint', required=True)
parser.add_argument('--model', required=True)
args = parser.parse_args()
root = Path(args.root).resolve(); root.mkdir(parents=True, exist_ok=True)
config = BridgeConfig(root, WeknoraConfig(enabled=False), workflow=WorkflowConfig(
    procedure_enabled=True, compiler_provider='local_openai_compatible_endpoint',
    compiler_base_url=args.endpoint, compiler_model=args.model))
bridge = ExcelBridge(config)
compiler = SopCompiler(bridge.store, config.workflow)
pid = compiler.ingest(args.sop)
started = time.monotonic()
results = []
for _ in range(140):
    result = compiler.compile_next(pid)
    results.append(result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    if result['status'] != 'compiling': break
with bridge.store.connection() as db:
    passes = [dict(row) for row in db.execute('SELECT stage,item_key,usage_json,elapsed_seconds,LENGTH(result_json) AS result_chars FROM compiler_passes WHERE procedure_id=? ORDER BY created_at', (pid,))]
report = {'source': str(Path(args.sop).resolve()), 'provider': config.workflow.compiler_provider,
          'model': args.model, 'endpoint': args.endpoint, 'status': result['status'], 'results': results,
          'elapsed_seconds': time.monotonic()-started, 'passes': passes, 'manual_plan_repair': False}
(root / 'compiler-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
