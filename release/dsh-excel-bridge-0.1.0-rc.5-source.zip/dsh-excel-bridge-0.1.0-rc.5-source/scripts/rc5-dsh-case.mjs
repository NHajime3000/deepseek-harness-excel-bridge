// Bounded real DSH session driver; no internal workflow IDs in model prompts.
import {mkdirSync,readFileSync,writeFileSync,existsSync} from 'node:fs'
import {resolve,join} from 'node:path'
import {dshRpc} from './dsh-rpc.mjs'
const [rootArg,label,prompt,priorReport]=process.argv.slice(2)
if(!rootArg||!label||!prompt||!/^[-a-z0-9]+$/.test(label))throw Error('root label prompt [prior-session-report] required')
if(process.env.EXCEL_BRIDGE_DSH_URL!=='http://127.0.0.1:3082')throw Error('Isolated test DSH required')
const root=resolve(rootArg), path=join(root,`dsh-${label}.json`)
mkdirSync(root,{recursive:true}); if(existsSync(path))throw Error('Preserve prior evidence; choose a new label')
const old=priorReport?JSON.parse(readFileSync(resolve(priorReport),'utf8')):null
const session=old||await dshRpc('session.create',{cwd:root})
if(!old)await dshRpc('session.selectModel',{sessionId:session.sessionId,provider:'rc4-local',model:'qwen3-4b-thinking-2507.Q4_K_M',reasoningEffort:'off'})
const before=await dshRpc('session.history',{sessionId:session.sessionId,maxMessages:100})
const previousSeq=Math.max(0,...before.events.map(e=>e.event.seq))
await dshRpc('session.prompt',{sessionId:session.sessionId,mode:'queue',content:[{type:'text',text:prompt}],clientTimeZone:'Asia/Hong_Kong'})
const report={sessionId:session.sessionId,prompt,started:new Date().toISOString(),status:'running',maxObservedContext:0,history:[],projections:{}}
writeFileSync(path,JSON.stringify(report,null,2))
const deadline=Date.now()+240000
while(Date.now()<deadline){
  await new Promise(r=>setTimeout(r,2000))
  const history=await dshRpc('session.history',{sessionId:session.sessionId,maxMessages:150})
  const events=history.events.map(e=>e.event), values=history.projections?.values||{}
  report.projections=values
  report.maxObservedContext=Math.max(report.maxObservedContext,values.contextPressure?.pressureTokens||0,values.contextPressure?.projectedTokens||0)
  report.history=events.filter(e=>['tool/call','tool/result','turn/end','step/end','request/header','assistant/message'].includes(e.type))
    .map(e=>e.type==='request/header'?{type:e.type,seq:e.seq,tools:e.data.header.tools.map(t=>t.name),schemaChars:JSON.stringify(e.data.header.tools).length}:
      e.type==='assistant/message'?{type:e.type,seq:e.seq,content:e.data.message.content.filter(c=>c.type!=='reasoning'),usage:e.data.usage}:e)
  const end=events.findLast(e=>e.type==='turn/end'&&e.seq>previousSeq)
  if(end){report.status=end.data.reason.kind;break}
  writeFileSync(path,JSON.stringify(report,null,2))
}
if(report.status==='running'){await dshRpc('session.cancel',{sessionId:session.sessionId});report.status='test_timeout'}
report.completed=new Date().toISOString();writeFileSync(path,JSON.stringify(report,null,2))
console.log(JSON.stringify({sessionId:report.sessionId,status:report.status,maxObservedContext:report.maxObservedContext}))
