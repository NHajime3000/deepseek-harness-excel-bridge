import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { join } from 'node:path'

const root = new URL('..', import.meta.url)
const rootPath = decodeURIComponent(root.pathname.replace(/^\/(?:([A-Za-z]:))/, '$1'))
const localPython = process.platform === 'win32' ? join(rootPath, '.venv', 'Scripts', 'python.exe') : join(rootPath, '.venv', 'bin', 'python')
const python = process.env.EXCEL_BRIDGE_PYTHON || (existsSync(localPython) ? localPython : 'python')

for (const [command, args] of [
  [process.execPath, ['--test', 'tests/node_plugin.test.mjs']],
  [python, ['-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py', '-v']],
]) {
  const result = spawnSync(command, args, { cwd: rootPath, stdio: 'inherit', env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } })
  if (result.status !== 0) process.exit(result.status ?? 1)
}
