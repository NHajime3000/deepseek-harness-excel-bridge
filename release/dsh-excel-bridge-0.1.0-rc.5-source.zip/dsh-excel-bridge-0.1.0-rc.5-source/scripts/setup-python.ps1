param([string]$Python = 'python', [string]$VenvPath = '', [switch]$Install)
$ErrorActionPreference = 'Stop'
$pluginRoot = Split-Path -Parent $PSScriptRoot
if (-not $VenvPath) { $VenvPath = Join-Path $pluginRoot '.venv' }
if (-not $Install) {
    Write-Output 'This opt-in helper creates a venv and downloads dependencies from your configured pip index.'
    Write-Output 'Review requirements.txt, then rerun with -Install. No installation has been performed.'
    exit 0
}
if (Test-Path -LiteralPath $VenvPath) { throw 'Venv target exists. Use your existing Python or choose a new VenvPath.' }
& $Python -m venv $VenvPath
if ($LASTEXITCODE -ne 0) { throw 'Python venv creation failed' }
$venvPython = Join-Path $VenvPath 'Scripts/python.exe'
& $venvPython -m pip install -r (Join-Path $pluginRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed' }
Write-Output "Configure the plugin Python executable as: $venvPython"
