import assert from 'node:assert/strict'
import {createRequire} from 'node:module'
import {writeFileSync,mkdirSync} from 'node:fs'
import {resolve} from 'node:path'
import {dshRpc} from './dsh-rpc.mjs'
import {randomUUID} from 'node:crypto'
const require=createRequire(import.meta.url)
const {chromium}=require(require.resolve('playwright',{paths:[process.env.EXCEL_BRIDGE_BROWSER_MODULES||process.cwd()]}))
const root=resolve(process.argv[2]); mkdirSync(root,{recursive:true})
const origin=process.env.EXCEL_BRIDGE_DSH_URL
if (!origin) throw new Error('Explicit test DSH URL required')
const browser=await chromium.launch({channel:'msedge',headless:true})
let secretProbe=false
async function waitEnabled(value) {
  for(let attempt=0;attempt<40;attempt++){
    const current=(await dshRpc('settings.describe')).namespaces.find(n=>n.ns==='excel-bridge')
    if(current.value.enabled===value)return
    await new Promise(r=>setTimeout(r,250))
  }
  throw Error('UI toggle did not persist')
}
async function cleanupProbe() {
  for(let attempt=0;attempt<5;attempt++){
    const current=(await dshRpc('settings.describe')).namespaces.find(n=>n.ns==='excel-bridge')
    try{
      await dshRpc('settings.mutate',{ns:'excel-bridge',ops:[{op:'unset',path:['config','compilerApiKey']},{op:'set',path:['enabled'],value:true}],expectedRevision:current.revision})
      return
    }catch(error){if(!String(error).includes('settings-conflict')||attempt===4)throw error}
  }
}
try {
  const initial=(await dshRpc('settings.describe')).namespaces.find(n=>n.ns==='excel-bridge')
  if (initial.secrets.some(s=>s.path.join('.')==='config.compilerApiKey'&&s.set)) throw new Error('Refusing to overwrite existing compiler credential')
  const marker='test-only-'+randomUUID()
  await dshRpc('settings.update',{ns:'excel-bridge',patch:{config:{compilerApiKey:marker}},expectedRevision:initial.revision})
  secretProbe=true
  const page=await browser.newPage({viewport:{width:1280,height:960}})
  await page.goto(origin,{waitUntil:'networkidle'})
  const welcome = page.getByRole('button',{name:'继续',exact:true})
  if (await welcome.isVisible()) await welcome.click()
  await page.getByRole('button',{name:'设置',exact:true}).click()
  await page.getByRole('button',{name:'插件',exact:true}).click()
  const card=page.locator('section').filter({has:page.getByRole('heading',{name:'Excel Bridge',exact:true})})
  await card.getByText('配置',{exact:true}).click()
  const report={url:origin,cardVisible:await card.isVisible(),fields:await card.locator('label').allTextContents(),
    apiKeyType:await card.getByLabel('API Key',{exact:true}).getAttribute('type'),
    compilerKeyType:await card.getByLabel('SOP 编译 API Key（如需要）',{exact:true}).getAttribute('type')}
  assert.equal(report.apiKeyType,'password');assert.equal(report.compilerKeyType,'password')
  const redacted=(await dshRpc('settings.describe')).namespaces.find(n=>n.ns==='excel-bridge')
  assert.ok(!JSON.stringify(redacted).includes(marker))
  assert.ok(redacted.secrets.some(s=>s.path.join('.')==='config.compilerApiKey'&&s.set))
  report.secretTransportRedacted=true
  await card.getByLabel('默认结果数（1–20）',{exact:true}).fill('5')
  await card.getByRole('button',{name:'保存配置',exact:true}).click()
  await card.getByRole('status').filter({hasText:'配置已保存'}).waitFor()
  const saved=(await dshRpc('settings.describe')).namespaces.find(n=>n.ns==='excel-bridge')
  assert.equal(saved.value.config.defaultQueryLimit,5)
  assert.ok(saved.secrets.some(s=>s.path.join('.')==='config.compilerApiKey'&&s.set))
  report.otherSettingsSavePreservesSecret=true
  await page.screenshot({path:resolve(root,'settings.png'),fullPage:true})
  await page.reload({waitUntil:'networkidle'})
  const ns=(await dshRpc('settings.describe')).namespaces.find(n=>n.ns==='excel-bridge')
  report.persisted={enabled:ns.value.enabled,procedureEnabled:ns.value.config.procedureEnabled,recipeEnabled:ns.value.config.recipeEnabled}
  assert.deepEqual(report.persisted,{enabled:true,procedureEnabled:true,recipeEnabled:true})
  await page.getByRole('button',{name:'设置',exact:true}).click()
  await page.getByRole('button',{name:'插件',exact:true}).click()
  const toggle=card.getByLabel('启用 Excel Bridge 工具',{exact:false})
  // This is server-controlled: click returns before the persisted state is rendered.
  // Playwright uncheck/check assert synchronously and can reject a successful click.
  await toggle.click()
  await waitEnabled(false)
  for(let i=0;i<40 && await toggle.isChecked();i++)await page.waitForTimeout(100)
  assert.equal(await toggle.isChecked(),false)
  await toggle.click()
  await waitEnabled(true)
  for(let i=0;i<40 && !await toggle.isChecked();i++)await page.waitForTimeout(100)
  assert.equal(await toggle.isChecked(),true)
  report.uiDisableEnable=true
  report.status='passed';writeFileSync(resolve(root,'settings.json'),JSON.stringify(report,null,2))
  console.log(JSON.stringify(report))
} finally {
  if (secretProbe) {
    await cleanupProbe()
  }
  await browser.close()
}
