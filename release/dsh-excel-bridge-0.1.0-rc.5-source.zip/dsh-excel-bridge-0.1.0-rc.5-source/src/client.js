/* DSH's browser module-loader contract; no private RPC or bundled React copy. */
window.__ModuleLoader__.load({
  id: 'dsh-excel-bridge',
  factory: require => {
    const React = require('react')
    const h = React.createElement
    const fields = [
      ['pythonPath', 'Python executable'], ['workspaceRoot', 'Workspace / SQLite root'],
      ['connectionFile', '连接文件（推荐；本机 JSON）'], ['baseUrl', 'WeKnora Base URL'],
      ['apiKey', 'API Key', 'password'], ['tenantId', 'Tenant'],
      ['embeddingModelId', 'Embedding model ID（配置一次）'],
      ['autoCreateKb', '自动创建文件知识库', 'checkbox'],
      ['autoIndexOnQuery', '查询时自动索引', 'checkbox'],
      ['defaultQueryLimit', '默认结果数（1–20）', 'number'],
      ['batchSize', '索引批大小（100–500）', 'number'],
      ['recoveryEnabled', '启用后台 Outbox 恢复', 'checkbox', false],
      ['recoveryIntervalSeconds', '后台恢复间隔秒', 'number'],
      ['outboxMaxAttempts', 'Outbox 最大失败尝试次数', 'number'],
      ['outboxImmediateSeconds', '调用内同步预算秒', 'number'],
      ['recipeEnabled', '启用 Recipe Memory', 'checkbox', false],
      ['procedureEnabled', '启用 Procedure 统一工具', 'checkbox', false],
      ['previewThreshold', '批量写入预警行数', 'number'],
      ['procedureMaxRecords', 'Procedure 最大输入行数', 'number'],
      ['procedureStepsPerCall', '每次调用最多步骤', 'number'],
      ['compilerProvider', 'Compiler provider：current_dsh_model / openai_compatible / local_openai_compatible_endpoint / manual_review'],
      ['compilerBaseUrl', 'SOP 编译模型 API 地址（含 /v1）'],
      ['compilerModel', 'SOP 编译模型名称（不更改 DSH 默认模型）'],
      ['compilerApiKey', 'SOP 编译 API Key（如需要）', 'password'],
      ['knowledgeBaseId', '旧模式 KB ID（可选，留空推荐自动 Workspace）']
    ]
    function Panel({ scope, connection }) {
      const [snap, setSnap] = React.useState(() => scope.getSnapshot())
      const [draft, setDraft] = React.useState(null)
      const [notice, setNotice] = React.useState('')
      React.useEffect(() => scope.subscribe(() => setSnap(scope.getSnapshot())), [scope])
      const state = snap.value || {}
      const config = draft || state.config || {}
      const save = async () => {
        try {
          if (!connection.isLoopback) throw new Error('Remote settings are read-only')
          const ops = Object.entries(config).filter(([key,value]) => !['apiKey','compilerApiKey'].includes(key) || value)
            .map(([key,value])=>({op:'set',path:['config',key],value}))
          const response = await connection.api.settings.mutate({ns:'excel-bridge',ops,expectedRevision:snap.revision})
          if (!response.result.ok) throw new Error('Settings update rejected')
          setDraft(null); setNotice('配置已保存，新调用生效。')
        } catch { setNotice('保存失败，请检查配置；未显示敏感错误详情。') }
      }
      return h('section', { style: { padding: 16, border: '1px solid var(--border-color, #8884)', borderRadius: 8 } },
        h('h3', null, 'Excel Bridge'),
        h('p', null, 'Excel 查询与安全写回，支持可选的 Recipe 和 SOP 工作流。'),
        h('label', null, h('input', { type: 'checkbox', checked: state.enabled !== false,
          onChange: e => scope.set('enabled', e.target.checked).catch(() => setNotice('开关保存失败。')) }), ' 启用 Excel Bridge 工具'),
        h('details', null, h('summary', null, '配置'),
          h('p', null, '普通字段留空继承连接文件；密码留空保留已存值。API Key 不回传浏览器或工具结果。不要在聊天中粘贴凭据。'),
          ...fields.map(([key, label, type = 'text', fallback = true]) => h('label', { key, style: { display: 'grid', gap: 4, margin: '10px 0' } }, label,
            h('input', { type, autoComplete: 'off',
              ...(type === 'checkbox' ? { checked: config[key] ?? fallback } : { value: config[key] ?? '' }),
              onChange: e => setDraft({ ...config, [key]: type === 'checkbox' ? e.target.checked : type === 'number' && e.target.value ? Number(e.target.value) : e.target.value }) }))),
          h('button', { onClick: save }, '保存配置')),
        notice ? h('p', { role: 'status' }, notice) : null)
    }
    return { inject: ['settingsScope','connection'], apply(ctx) {
      const slots = ctx.get('slots')
      if (!slots) return
      const scope = ctx.settingsScope.bind({ namespace: 'excel-bridge', decode: section => section || {} })
      const connection = ctx.get('connection')
      slots.inject('settings.plugin.item', () => slots.register(
        { name: 'settings.plugin.item', key: 'excel-bridge' }, () => h(Panel, { scope, connection })))
    } }
  }
})
