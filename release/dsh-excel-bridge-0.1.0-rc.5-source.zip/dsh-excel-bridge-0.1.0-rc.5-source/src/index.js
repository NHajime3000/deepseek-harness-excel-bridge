import { spawn } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { delimiter, join } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-excel-bridge'
export const inject = ['tools', 'settings']

const packageRoot = fileURLToPath(new URL('..', import.meta.url))
const MAX_STDOUT = 16_384
const MAX_STDERR = 8_192

function text(value) {
  return [{ type: 'text', text: JSON.stringify(value) }]
}

function resolvedConfig(raw = {}) {
  const supplied = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}
  let connection = {}
  try {
    if (supplied.connectionFile) connection = JSON.parse(readFileSync(supplied.connectionFile, 'utf8').replace(/^\uFEFF/, ''))
  } catch { throw new Error('dsh-excel-bridge: connection file is unreadable or invalid JSON') }
  const config = { ...connection, ...Object.fromEntries(Object.entries(supplied).filter(([, value]) => value !== undefined && value !== '')) }
  const batchSize = Number(config.batchSize ?? 200)
  const defaultQueryLimit = Number(config.defaultQueryLimit ?? 5)
  if (!Number.isInteger(defaultQueryLimit) || defaultQueryLimit < 1 || defaultQueryLimit > 20) {
    throw new Error('dsh-excel-bridge: defaultQueryLimit must be an integer from 1 to 20')
  }
  if (!Number.isInteger(batchSize) || batchSize < 100 || batchSize > 500) {
    throw new Error('dsh-excel-bridge: batchSize must be an integer from 100 to 500')
  }
  const localPython = process.platform === 'win32' ? join(packageRoot, '.venv', 'Scripts', 'python.exe') : join(packageRoot, '.venv', 'bin', 'python')
  const integer = (key, fallback, min, max) => {
    const value = Number(config[key] ?? fallback)
    if (!Number.isInteger(value) || value < min || value > max) throw new Error(`dsh-excel-bridge: invalid ${key}`)
    return value
  }
  const compilerProvider = config.compilerProvider || 'local_openai_compatible_endpoint'
  if (!['current_dsh_model', 'openai_compatible', 'local_openai_compatible_endpoint', 'disabled', 'manual_review'].includes(compilerProvider)) {
    throw new Error('dsh-excel-bridge: invalid compilerProvider')
  }
  return {
    pythonPath: typeof config.pythonPath === 'string' && config.pythonPath
      ? config.pythonPath
      : existsSync(localPython) ? localPython : 'python',
    workspaceRoot: typeof config.workspaceRoot === 'string' && config.workspaceRoot ? config.workspaceRoot : process.cwd(),
    baseUrl: typeof config.baseUrl === 'string' && config.baseUrl ? config.baseUrl : 'http://localhost:8080/api/v1',
    apiKey: typeof config.apiKey === 'string' && config.apiKey ? config.apiKey : undefined,
    tenantId: config.tenantId == null || config.tenantId === '' ? undefined : String(config.tenantId),
    knowledgeBaseId: typeof config.knowledgeBaseId === 'string' && config.knowledgeBaseId ? config.knowledgeBaseId : undefined,
    batchSize,
    requestTimeoutMs: Number(config.requestTimeoutMs ?? 30_000),
    taskTimeoutMs: Number(config.taskTimeoutMs ?? 600_000),
    vectorThreshold: Number(config.vectorThreshold ?? 0.3),
    weknoraEnabled: config.weknoraEnabled !== false,
    autoCreateKb: config.autoCreateKb !== false,
    autoIndexOnQuery: config.autoIndexOnQuery !== false,
    embeddingModelId: config.embeddingModelId || undefined,
    defaultQueryLimit,
    procedureEnabled: config.procedureEnabled === true,
    recipeEnabled: config.recipeEnabled === true,
    previewThreshold: integer('previewThreshold', 20, 1, 10000),
    procedureMaxRecords: integer('procedureMaxRecords', 100000, 1, 1000000),
    procedureStepsPerCall: integer('procedureStepsPerCall', 8, 1, 64),
    compilerProvider,
    compilerBaseUrl: config.compilerBaseUrl || '', compilerModel: config.compilerModel || '',
    compilerApiKey: config.compilerApiKey || '',
    outboxMaxAttempts: integer('outboxMaxAttempts', 8, 1, 100),
    outboxImmediateSeconds: integer('outboxImmediateSeconds', 30, 1, 600),
    recoveryEnabled: config.recoveryEnabled === true,
    recoveryIntervalSeconds: integer('recoveryIntervalSeconds', 60, 15, 3600),
  }
}

function backendEnvironment(config) {
  return {
    ...process.env,
    PYTHONUTF8: '1',
    PYTHONIOENCODING: 'utf-8',
    PYTHONPATH: [packageRoot, process.env.PYTHONPATH].filter(Boolean).join(delimiter),
    EXCEL_BRIDGE_WORKSPACE: config.workspaceRoot,
    EXCEL_BRIDGE_WEKNORA_BASE_URL: config.baseUrl,
    EXCEL_BRIDGE_WEKNORA_API_KEY: config.apiKey ?? '',
    EXCEL_BRIDGE_WEKNORA_TENANT_ID: config.tenantId ?? '',
    EXCEL_BRIDGE_WEKNORA_KNOWLEDGE_BASE_ID: config.knowledgeBaseId ?? '',
    EXCEL_BRIDGE_BATCH_SIZE: String(config.batchSize),
    EXCEL_BRIDGE_REQUEST_TIMEOUT: String(config.requestTimeoutMs / 1000),
    EXCEL_BRIDGE_TASK_TIMEOUT: String(config.taskTimeoutMs / 1000),
    EXCEL_BRIDGE_VECTOR_THRESHOLD: String(config.vectorThreshold),
    EXCEL_BRIDGE_WEKNORA_ENABLED: String(config.weknoraEnabled),
    EXCEL_BRIDGE_AUTO_CREATE_KB: String(config.autoCreateKb),
    EXCEL_BRIDGE_AUTO_INDEX_ON_QUERY: String(config.autoIndexOnQuery),
    EXCEL_BRIDGE_EMBEDDING_MODEL_ID: config.embeddingModelId ?? '',
    EXCEL_BRIDGE_DEFAULT_QUERY_LIMIT: String(config.defaultQueryLimit),
    EXCEL_BRIDGE_PROCEDURE_ENABLED: String(config.procedureEnabled),
    EXCEL_BRIDGE_RECIPE_ENABLED: String(config.recipeEnabled),
    EXCEL_BRIDGE_PREVIEW_THRESHOLD: String(config.previewThreshold),
    EXCEL_BRIDGE_PROCEDURE_MAX_RECORDS: String(config.procedureMaxRecords),
    EXCEL_BRIDGE_PROCEDURE_STEPS_PER_CALL: String(config.procedureStepsPerCall),
    EXCEL_BRIDGE_COMPILER_BASE_URL: config.compilerBaseUrl,
    EXCEL_BRIDGE_COMPILER_PROVIDER: config.compilerProvider,
    EXCEL_BRIDGE_COMPILER_MODEL: config.compilerModel,
    EXCEL_BRIDGE_COMPILER_API_KEY: config.compilerApiKey,
    EXCEL_BRIDGE_OUTBOX_MAX_ATTEMPTS: String(config.outboxMaxAttempts),
    EXCEL_BRIDGE_OUTBOX_IMMEDIATE_SECONDS: String(config.outboxImmediateSeconds),
    // Do not accidentally inherit the operator's legacy global destination.
    WEKNORA_KNOWLEDGE_BASE_ID: '', WEKNORA_API_KEY: '', WEKNORA_TENANT_ID: '',
  }
}

function runBackend(config, tool, args, signal, sessionKey = '') {
  return new Promise((resolve, reject) => {
    const argv = tool === '_recover' ? ['-m', 'excel_bridge.maintenance', 'recover', '--max-tasks', '1000', '--max-seconds', '10'] : ['-m', 'excel_bridge.cli', tool]
    const child = spawn(config.pythonPath, argv, {
      cwd: config.workspaceRoot,
      env: { ...backendEnvironment(config), EXCEL_BRIDGE_SESSION_KEY: sessionKey },
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe'],
    })
    let stdout = ''
    let stderr = ''
    let exceeded = false
    const abort = () => child.kill()
    signal?.addEventListener('abort', abort, { once: true })
    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    child.stdout.on('data', chunk => {
      stdout += chunk
      if (stdout.length > MAX_STDOUT) {
        exceeded = true
        child.kill()
      }
    })
    child.stderr.on('data', chunk => {
      if (stderr.length < MAX_STDERR) stderr += chunk.slice(0, MAX_STDERR - stderr.length)
    })
    child.once('error', reject)
    child.once('close', code => {
      signal?.removeEventListener('abort', abort)
      if (exceeded) return reject(new Error(`${tool}: backend exceeded output limit`))
      let value
      try {
        value = JSON.parse(stdout)
      } catch {
        return reject(new Error(`${tool}: invalid backend response; check Python executable and dependencies`))
      }
      if (code !== 0) {
        let message = String(value?.error ?? `${tool}: backend exited ${code}`)
        for (const secret of [config.apiKey, config.compilerApiKey]) if (secret) message = message.replaceAll(secret, '[redacted]')
        return reject(new Error(message))
      }
      resolve(value)
    })
    child.stdin.end(JSON.stringify(args))
  })
}

const FILTERS = {
  type: 'object',
  description: 'Exact real-column filters. eq/ne take scalar values; in takes an array; contains takes a string.',
  additionalProperties: {
    anyOf: [
      { type: ['string', 'number', 'boolean', 'null'] },
      { type: 'object', properties: {
        eq: { type: ['string', 'number', 'boolean', 'null'] },
        ne: { type: ['string', 'number', 'boolean', 'null'] },
        lt: {}, lte: {}, gt: {}, gte: {},
        between: { type: 'array', minItems: 2, maxItems: 2 },
        in: { type: 'array' }, contains: { type: 'string' },
      }, additionalProperties: false },
    ],
  },
}

const OPERATION = {
  type: 'object',
  properties: {
    column: { type: 'string' },
    type: { type: 'string', enum: ['set', 'numeric_add', 'numeric_multiply', 'append_column'] },
    value: { type: ['string', 'number', 'boolean', 'null'] },
  },
  required: ['column', 'type'],
  additionalProperties: false,
}

const OUTPUT = {
  schema: { type: 'object', additionalProperties: true },
  render: (_args, value) => text(value),
}

export function createTools(config, host = {}) {
  config = resolvedConfig(config)
  const execute = tool => async (args, run = {}) => {
    let callConfig = config
    if (config.compilerProvider === 'current_dsh_model' && tool === 'procedure_run') {
      const model = run.agent?.options?.model
      const provider = run.agent?.options?.provider
      const profile = host.settings?.get?.('llm-pi-ai')?.providers?.[provider]
      if (!model || !profile?.baseURL || profile.api !== 'openai-completions') {
        return { status: 'needs_review', message: '当前 DSH 模型无法解析为独立 OpenAI-compatible 编译端点，请显式配置 Compiler。默认模型未改变。' }
      }
      // Cordis rejects direct access to undeclared services. Like DSH's own
      // llm-pi-ai adapter, query this optional service through Context.get().
      const credentialService = profile.apiKeyEnv ? host.get?.('credentials') : undefined
      const credential = profile.apiKeyEnv ? await credentialService?.resolve?.(profile.apiKeyEnv) : undefined
      if (profile.apiKeyEnv && !credential?.value) {
        run.concludeTurn?.()
        return { status: 'needs_review', message: '当前 DSH 模型的凭证引用无法解析，请检查模型配置；未发送编译请求或修改文件。' }
      }
      callConfig = { ...config, compilerBaseUrl: profile.baseURL, compilerModel: model,
        compilerApiKey: credential?.value || '', compilerProvider: 'openai_compatible' }
    }
    const result = await runBackend(callConfig, tool, args, run.signal, String(run.agent?.id || ''))
    // A waiting/review result ends this turn, avoiding self-retries by a small model.
    if (tool === 'procedure_run' && !['compiling', 'running', 'syncing'].includes(result.status)) run.concludeTurn?.()
    return result
  }
  const tools = [
    {
      name: 'excel_index',
      description: 'Build or refresh a large .xlsx index. Usually query ensures it automatically.',
      parameters: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          force_reindex: { type: 'boolean' },
        },
        required: ['file'],
        additionalProperties: false,
      },
      output: OUTPUT,
      timeoutMs: 3_600_000,
      execute: execute('excel_index'),
    },
    {
      name: 'excel_query',
      description: 'Search .xlsx; auto-create KB/index. Meaning-based search: query text, omit filters. Exact column match: empty query, filters with scalar values. Use excel_index if indexing_required.',
      parameters: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          query: { type: 'string' },
          filters: FILTERS,
          limit: { type: 'integer' },
        },
        required: ['file', 'query'],
        additionalProperties: false,
      },
      output: OUTPUT,
      timeoutMs: 60_000,
      isConcurrencySafe: () => false,
      execute: execute('excel_query'),
    },
    {
      name: 'excel_patch',
      description: 'Safely update .xlsx by record_id or selector; auto-sync its index. Use IDs returned by query.',
      parameters: {
        type: 'object',
        properties: {
          file: { type: 'string' },
          operations: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                record_id: { type: 'string' },
                column: { type: 'string' },
                operation: { type: 'string', enum: ['set', 'numeric_add', 'numeric_multiply', 'append_column'] },
                value: { type: ['string', 'number', 'boolean', 'null'] },
              },
              required: ['record_id', 'column', 'operation'],
              additionalProperties: false,
            },
          },
          selector: FILTERS,
          operation: OPERATION,
          dry_run: { type: 'boolean' },
        },
        required: ['file'],
        additionalProperties: false,
      },
      output: OUTPUT,
      timeoutMs: 3_600_000,
      execute: execute('excel_patch'),
    },
  ]
  if (config.procedureEnabled) tools.push({
    name: 'procedure_run',
    description: 'Apply a previous workflow or SOP to XLSX. Pass the user instruction and exact file paths only. Backend resolves recipes, mapping, preview, approval and progress. Never invent file contents. Continue with the same inputs after administrator approval.',
    parameters: { type: 'object', properties: {
      instruction: { type: 'string', minLength: 1, maxLength: 2400 },
      files: { type: 'array', items: { type: 'string' }, minItems: 1, maxItems: 2 },
    }, required: ['instruction', 'files'], additionalProperties: false },
    output: OUTPUT, timeoutMs: 3_600_000, isConcurrencySafe: () => false, execute: execute('procedure_run'),
  })
  return tools
}

export function apply(ctx, rawConfig) {
  const defaults = rawConfig || {}
  const schema = value => {
    const config = { ...defaults, ...(value?.config || {}) }
    resolvedConfig(config) // Reject invalid config without printing secrets.
    return { enabled: value?.enabled !== false, config }
  }
  const stringKeys = ['pythonPath','workspaceRoot','connectionFile','baseUrl','tenantId','knowledgeBaseId','embeddingModelId','compilerProvider','compilerBaseUrl','compilerModel']
  const booleanKeys = ['weknoraEnabled','autoCreateKb','autoIndexOnQuery','recipeEnabled','procedureEnabled','recoveryEnabled']
  const numberKeys = ['batchSize','defaultQueryLimit','requestTimeoutMs','taskTimeoutMs','vectorThreshold','previewThreshold','procedureMaxRecords','procedureStepsPerCall','outboxMaxAttempts','outboxImmediateSeconds','recoveryIntervalSeconds']
  const configFields = Object.fromEntries([
    ...stringKeys.map(key=>[key,{type:'string',meta:{}}]),
    ...booleanKeys.map(key=>[key,{type:'boolean',meta:{}}]),
    ...numberKeys.map(key=>[key,{type:'number',meta:{}}]),
    ...['apiKey','compilerApiKey'].map(key=>[key,{type:'string',meta:{role:'secret'}}]),
  ])
  // DSH's real settings service walks live schema.type/dict to redact secrets.
  // A password HTML input alone does not protect the settings transport.
  Object.assign(schema, {type:'object',meta:{},dict:{enabled:{type:'boolean',meta:{}},config:{type:'object',meta:{},dict:configFields}}})
  schema.toJSON = () => ({ type:schema.type, meta:schema.meta, dict:schema.dict })
  const scope = ctx.settings?.register('excel-bridge', schema)
  let disposers = []
  let recoveryTimer
  let recoveryAbort
  let recoveryBusy = false
  const register = value => {
    const next = schema(value)
    const tools = next.enabled ? createTools(next.config, ctx) : []
    for (const dispose of disposers) if (typeof dispose === 'function') dispose()
    clearInterval(recoveryTimer)
    recoveryAbort?.abort()
    disposers = tools.map(tool => ctx.tools.register(tool))
    const config = resolvedConfig(next.config)
    if (next.enabled && config.recoveryEnabled) {
      const recover = async () => {
        if (recoveryBusy) return
        recoveryBusy = true
        recoveryAbort = new AbortController()
        try { await runBackend(config, '_recover', {}, recoveryAbort.signal) }
        catch { /* Queue state is durable; do not log credentials or source payloads. */ }
        finally { recoveryBusy = false }
      }
      recoveryTimer = setInterval(recover, config.recoveryIntervalSeconds * 1000)
      recoveryTimer.unref?.()
      void recover()
    }
  }
  register(scope?.get())
  ctx.on?.('settings/updated', (ns, value) => { if (ns === 'excel-bridge') register(value) })
  ctx.on?.('dispose', () => {
    clearInterval(recoveryTimer); recoveryAbort?.abort()
    for (const dispose of disposers) if (typeof dispose === 'function') dispose()
  })
}
