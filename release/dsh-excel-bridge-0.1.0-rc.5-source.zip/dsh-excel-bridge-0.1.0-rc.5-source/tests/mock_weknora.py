from __future__ import annotations

import json
import re
import threading
import uuid
from urllib.parse import urlsplit, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any


class MockState:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.next_id = 100_000_000
        self.entries: dict[int, dict[str, Any]] = {}
        self.tasks: dict[str, dict[str, Any]] = {}
        self.upsert_batches: list[int] = []
        self.delete_batches: list[int] = []
        self.search_calls = 0
        self.http_status = 0
        self.post_status = 0
        self.partial_fail_indexes: set[int] = set()
        self.progress_calls: list[str] = []

    def upsert(self, payload: dict[str, Any]) -> str:
        task_id = str(uuid.uuid4())
        successes = []
        with self.lock:
            entries = payload.get("entries") or []
            self.upsert_batches.append(len(entries))
            for index, entry in enumerate(entries):
                if index in self.partial_fail_indexes:
                    continue
                seq_id = self.next_id
                self.next_id += 1
                stored = dict(entry)
                stored.update(
                    {
                        "id": seq_id,
                        "chunk_id": f"chunk-{seq_id}",
                        "knowledge_id": "faq-document",
                        "knowledge_base_id": "kb-test",
                    }
                )
                self.entries[seq_id] = stored
                successes.append(
                    {
                        "index": index,
                        "seq_id": seq_id,
                        "standard_question": entry["standard_question"],
                    }
                )
            self.tasks[task_id] = {
                "task_id": task_id,
                "kb_id": "kb-test",
                "knowledge_id": "faq-document",
                "status": "completed",
                "progress": 100,
                "total": len(entries),
                "processed": len(entries),
                "success_count": len(entries),
                "failed_count": len(entries) - len(successes),
                "success_entries": successes,
            }
        return task_id

    def delete(self, ids: list[int]) -> None:
        with self.lock:
            self.delete_batches.append(len(ids))
            for seq_id in ids:
                self.entries.pop(seq_id, None)

    def search(self, query: str, count: int) -> list[dict[str, Any]]:
        normalized = query.casefold()
        if "圣诞" in normalized:
            terms = ["christmas", "tree", "decoration", "圣诞"]
        elif "待评估" in normalized:
            terms = ["待评估"]
        else:
            terms = [term for term in re.split(r"\W+", normalized) if term]
            if normalized:
                terms.append(normalized)
        results = []
        with self.lock:
            self.search_calls += 1
            for entry in self.entries.values():
                content = str(entry.get("standard_question", "")).casefold()
                hits = sum(1 for term in terms if term in content)
                if not hits:
                    continue
                result = dict(entry)
                result["score"] = hits / max(1, len(terms))
                result["matched_question"] = entry.get("standard_question", "")
                results.append(result)
        return sorted(results, key=lambda item: (-item["score"], item["id"]))[:count]


class MockWeknora:
    def __init__(self) -> None:
        self.state = MockState()
        state = self.state

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, _format: str, *_args: Any) -> None:
                return

            def _body(self) -> dict[str, Any]:
                length = int(self.headers.get("Content-Length", "0"))
                return json.loads(self.rfile.read(length) or b"{}")

            def _send(self, status: int, data: Any) -> None:
                raw = json.dumps(
                    {"success": status < 400, "data": data}, ensure_ascii=False
                ).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self) -> None:  # noqa: N802
                if state.http_status:
                    self._send(state.http_status, {})
                    return
                if self.path == "/api/v1/knowledge-bases/kb-test":
                    self._send(200, {"id": "kb-test", "type": "faq"})
                    return
                prefix = "/api/v1/faq/import/progress/"
                if self.path.startswith(prefix):
                    state.progress_calls.append(self.path[len(prefix):])
                    task = state.tasks.get(self.path[len(prefix) :])
                    self._send(200 if task else 404, task or {"message": "not found"})
                    return
                entries_path = "/api/v1/knowledge-bases/kb-test/faq/entries"
                if self.path.startswith(entries_path + "?"):
                    query = parse_qs(urlsplit(self.path).query)
                    keyword = query.get("keyword", [""])[0]
                    with state.lock:
                        entries = [e for e in state.entries.values() if not keyword or any(keyword in a for a in e.get("answers", []))]
                    self._send(200, {"data": entries[:int(query.get("page_size", [10])[0])], "total": len(entries)})
                    return
                if self.path.startswith(entries_path + "/"):
                    entry = state.entries.get(int(self.path.rsplit("/", 1)[1]))
                    self._send(200 if entry else 404, entry or {})
                    return
                self._send(404, {"message": "not found"})

            def do_POST(self) -> None:  # noqa: N802
                if state.http_status or state.post_status:
                    self._send(state.http_status or state.post_status, {})
                    return
                if self.path == "/api/v1/knowledge-bases/kb-test/faq/entries":
                    self._send(200, {"task_id": state.upsert(self._body())})
                    return
                if self.path == "/api/v1/knowledge-bases/kb-test/faq/search":
                    payload = self._body()
                    self._send(
                        200,
                        state.search(
                            str(payload.get("query_text", "")),
                            int(payload.get("match_count", 10)),
                        ),
                    )
                    return
                self._send(404, {"message": "not found"})

            def do_DELETE(self) -> None:  # noqa: N802
                if state.http_status:
                    self._send(state.http_status, {})
                    return
                if self.path == "/api/v1/knowledge-bases/kb-test/faq/entries":
                    state.delete(self._body().get("ids") or [])
                    self._send(200, {})
                    return
                self._send(404, {"message": "not found"})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.running = False

    def stop(self):
        if self.running:
            self.server.shutdown()
            self.server.server_close()
            self.thread.join(timeout=3)
            self.running = False

    def restart(self):
        address, handler = self.server.server_address, self.server.RequestHandlerClass
        self.server = ThreadingHTTPServer(address, handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.running = True

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.server.server_port}/api/v1"

    def __enter__(self) -> "MockWeknora":
        self.thread.start()
        self.running = True
        return self

    def __exit__(self, *_args: Any) -> None:
        self.stop()
