import assert from 'node:assert/strict'
import test from 'node:test'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

import { apply, createTools } from '../src/index.js'

test('current DSH compiler resolves credentials via Context.get without undeclared property access', async () => {
  const root=mkdtempSync(join(tmpdir(),'excel-bridge-host-'))
  try {
  const pythonPath = process.env.EXCEL_BRIDGE_PYTHON || resolve(process.platform === 'win32' ? '.venv/Scripts/python.exe' : '.venv/bin/python')
  let resolved = false
  const host = {
    settings: {get: () => ({providers:{test:{api:'openai-completions',baseURL:'http://127.0.0.1:1/v1',apiKeyEnv:'VALIDATION_ONLY'}}})},
    get: name => {assert.equal(name,'credentials');return {resolve:async ref => {assert.equal(ref,'VALIDATION_ONLY');resolved=true;return {value:'not-a-real-secret'}}}}
  }
  Object.defineProperty(host,'credentials',{get(){throw Error('cannot get credentials without inject')}})
  const tool=createTools({pythonPath,workspaceRoot:root,weknoraEnabled:false,procedureEnabled:true,compilerProvider:'current_dsh_model'},host).at(-1)
  const result=await tool.execute({instruction:'validate arguments',files:[]},{agent:{id:'trusted-host-session',options:{model:'test-model',provider:'test'}}})
  assert.equal(resolved,true)
  assert.equal(result.status,'invalid_arguments')
  } finally {rmSync(root,{recursive:true,force:true})}
})

test('current DSH compiler fails closed when its credential reference is unavailable', async () => {
  let stopped=false
  const host={settings:{get:()=>({providers:{test:{api:'openai-completions',baseURL:'http://127.0.0.1:1/v1',apiKeyEnv:'MISSING'}}})},get:()=>undefined}
  const tool=createTools({procedureEnabled:true,compilerProvider:'current_dsh_model'},host).at(-1)
  const result=await tool.execute({instruction:'x',files:['unused.xlsx']},{agent:{id:'session',options:{model:'test',provider:'test'}},concludeTurn:()=>{stopped=true}})
  assert.equal(result.status,'needs_review');assert.equal(stopped,true)
})

test('procedure opt-in adds only one bounded tool and preserves the three existing schemas', () => {
  const legacy = createTools({ weknoraEnabled: false })
  const enabled = createTools({ weknoraEnabled: false, procedureEnabled: true, recipeEnabled: true })
  const summary = tools => tools.map(({name, description, parameters}) => ({name, description, parameters}))
  assert.deepEqual(summary(enabled.slice(0, 3)), summary(legacy))
  assert.equal(enabled.length, 4)
  assert.equal(enabled[3].name, 'procedure_run')
  assert.ok(JSON.stringify(summary(enabled)).length < 3800)
  assert.deepEqual(Object.keys(enabled[3].parameters.properties), ['instruction', 'files'])
  assert.deepEqual(enabled[3].parameters.required, ['instruction', 'files'])
})

test('invalid workflow and recovery budgets are rejected without disclosing secrets', () => {
  for (const config of [{ previewThreshold: 0 }, { procedureStepsPerCall: 100 }, { recoveryIntervalSeconds: 1 }]) {
    assert.throws(() => createTools({ ...config, apiKey: 'secret-value' }), error => !error.message.includes('secret-value'))
  }
})

test('registers exactly the three compact Excel tools', () => {
  const registered = []
  apply({ tools: { register: tool => registered.push(tool) } }, {
    weknoraEnabled: false,
    workspaceRoot: process.cwd(),
  })
  assert.deepEqual(registered.map(tool => tool.name), ['excel_index', 'excel_query', 'excel_patch'])
  assert.equal(registered[0].parameters.required[0], 'file')
  assert.deepEqual(registered[1].parameters.required, ['file', 'query'])
  assert.deepEqual(registered[2].parameters.required, ['file'])
  assert.ok(JSON.stringify(registered.map(({ name, description, parameters }) => ({ name, description, parameters }))).length < 2800)
  assert.deepEqual(registered[1].parameters.properties.filters.additionalProperties.anyOf[1].properties.eq.type, ['string','number','boolean','null'])
})

test('rejects an unsafe WeKnora batch size at load time', () => {
  assert.throws(() => apply({ tools: { register() {} } }, { batchSize: 99 }), /batchSize/)
})

test('settings toggle unregisters tools, re-enable registers exactly three', () => {
  const registered = new Map()
  const listeners = {}
  let schema
  apply({
    settings: { register: (ns, decoder) => { assert.equal(ns, 'excel-bridge'); schema = decoder; return { get: () => decoder({}) } } },
    tools: { register: tool => { registered.set(tool.name, tool); return () => registered.delete(tool.name) } },
    on: (event, listener) => { listeners[event] = listener }
  }, { weknoraEnabled: false, workspaceRoot: process.cwd() })
  assert.equal(registered.size, 3)
  assert.equal(schema.dict.config.dict.apiKey.meta.role, 'secret')
  assert.equal(schema.dict.config.dict.compilerApiKey.meta.role, 'secret')
  listeners['settings/updated']('excel-bridge', schema({ enabled: false }))
  assert.equal(registered.size, 0)
  listeners['settings/updated']('excel-bridge', schema({ enabled: true }))
  assert.equal(registered.size, 3)
  listeners.dispose()
  assert.equal(registered.size, 0)
})

test('real Node/Python round trip preserves Chinese under a legacy Windows encoding', async () => {
  const root = mkdtempSync(join(tmpdir(), 'excel-bridge-unicode-'))
  const previousEncoding = process.env.PYTHONIOENCODING
  const previousUtf8 = process.env.PYTHONUTF8
  try {
    const pythonPath = process.env.EXCEL_BRIDGE_PYTHON || resolve(process.platform === 'win32' ? '.venv/Scripts/python.exe' : '.venv/bin/python')
    const file = join(root, '中文零售.xlsx')
    const created = spawnSync(pythonPath, ['-c', 'import sys; from openpyxl import Workbook; w=Workbook(); s=w.active; s.title="销售数据"; s.append(["ID","Description"]); s.append([1,"圣诞装饰品"]); w.save(sys.argv[1])', file], { encoding: 'utf8' })
    assert.equal(created.status, 0, created.stderr)
    process.env.PYTHONIOENCODING = 'gbk'
    process.env.PYTHONUTF8 = '0'
    const registered = []
    apply({ tools: { register: tool => registered.push(tool) } }, { pythonPath, workspaceRoot: root, weknoraEnabled: false })
    const call = (name, args) => registered.find(tool => tool.name === name).execute(args, {})
    const indexed = await call('excel_index', { file })
    assert.equal(indexed.file, '中文零售.xlsx')
    const found = await call('excel_query', { file, query: '', filters: { ID: 1 } })
    assert.equal(found.matches[0].sheet, '销售数据')
    assert.equal(found.matches[0].data.Description, '圣诞装饰品')
    const patched = await call('excel_patch', { file, operations: [{ record_id: found.matches[0].record_id, column: 'ReviewStatus', operation: 'set', value: '待评估' }] })
    assert.equal(patched.examples[0].new, '待评估')
    assert.ok(!JSON.stringify(patched).includes('\uFFFD'))
    const after = await call('excel_query', { file, query: '', filters: { ReviewStatus: '待评估' } })
    assert.equal(after.matches[0].data.ReviewStatus, '待评估')
  } finally {
    if (previousEncoding === undefined) delete process.env.PYTHONIOENCODING
    else process.env.PYTHONIOENCODING = previousEncoding
    if (previousUtf8 === undefined) delete process.env.PYTHONUTF8
    else process.env.PYTHONUTF8 = previousUtf8
    rmSync(root, { recursive: true, force: true })
  }
})
