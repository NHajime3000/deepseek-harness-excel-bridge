from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook, load_workbook

from excel_bridge import BridgeConfig, ExcelBridge, WeknoraConfig
from excel_bridge.config import MAX_RETURN_CHARS
from excel_bridge.utils import build_content
from tests.mock_weknora import MockWeknora


HEADERS = [
    "Invoice",
    "StockCode",
    "Description",
    "Quantity",
    "Price",
    "CustomerID",
    "Country",
]


def create_workbook(path: Path, rows: int) -> None:
    workbook = Workbook(write_only=True)
    sheet = workbook.create_sheet("销售 数据")
    sheet.append(HEADERS)
    for index in range(rows):
        christmas = index % 101 == 0
        sheet.append(
            [
                f"INV-{index:07d}",
                f"SKU-{index % 997:04d}",
                "WOODEN CHRISTMAS TREE DECORATION" if christmas else f"普通商品 {index}",
                (index % 9) + 1,
                round(1.0 + (index % 200) / 10, 2),
                f"C-{index % 1000:04d}",
                "France" if index % 7 == 0 else "United Kingdom",
            ]
        )
    workbook.save(path)


def bridge_for(root: Path, mock: MockWeknora) -> ExcelBridge:
    return ExcelBridge(
        BridgeConfig(
            workspace=root,
            weknora=WeknoraConfig(
                base_url=mock.base_url,
                knowledge_base_id="kb-test",
                batch_size=200,
                poll_interval=0.001,
                task_timeout=10,
            ),
        )
    )


class BridgeFlowTests(unittest.TestCase):
    def test_embedding_payload_is_semantic_not_locator_noise(self) -> None:
        content = build_content(
            "rec_0123456789abcdef01234567",
            r"E:\\private\\orders.xlsx",
            "Sheet1",
            {},
            {
                "Invoice": 489434,
                "StockCode": 85048,
                "Description": "15CM CHRISTMAS GLASS BALL 20 LIGHTS",
                "InvoiceDate": "2009-12-01T07:45:00",
                "Price": 6.95,
                "Country": "United Kingdom",
            },
        )
        self.assertIn("Description: 15CM CHRISTMAS GLASS BALL 20 LIGHTS", content)
        self.assertIn("Country: United Kingdom", content)
        self.assertIn("_rid: 0123456789ab", content)
        self.assertNotIn("rec_0123456789abcdef01234567", content)
        self.assertNotIn("orders.xlsx", content)
        self.assertNotIn("Invoice: 489434", content)

    def test_index_query_patch_relocate_and_batch(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "中文 零售.xlsx"
            create_workbook(path, 350)
            bridge = bridge_for(root, mock)

            indexed = bridge.excel_index({"file": str(path)})
            self.assertEqual(indexed["records"], 350)
            self.assertEqual(indexed["indexed"], 350)
            self.assertEqual(indexed["sheets"], 1)
            self.assertTrue(all(size <= 200 for size in mock.state.upsert_batches))
            self.assertNotIn("matches", indexed)

            queried = bridge.excel_query(
                {"file": path.name, "query": "找出看起来属于圣诞装饰品的商品", "limit": 5}
            )
            self.assertLessEqual(len(queried["matches"]), 5)
            self.assertTrue(queried["matches"])
            first = queried["matches"][0]
            self.assertTrue(first["record_id"].startswith("rec_"))
            self.assertEqual(first["sheet"], "销售 数据")
            query_chars = len(json.dumps(queried, ensure_ascii=False))
            self.assertLessEqual(query_chars, MAX_RETURN_CHARS)
            print(f"QUERY_RESULT_CHARS={query_chars}")

            patched = bridge.excel_patch(
                {
                    "file": path.name,
                    "operations": [
                        {
                            "record_id": first["record_id"],
                            "column": "ReviewStatus",
                            "operation": "set",
                            "value": "待评估",
                        }
                    ],
                }
            )
            self.assertEqual(patched["status"], "ok")
            self.assertEqual(patched["modified"], 1)
            self.assertEqual(patched["reindexed"], 1)
            self.assertTrue(Path(patched["backup"]).is_file())
            workbook = load_workbook(path, read_only=True)
            try:
                sheet = workbook["销售 数据"]
                headers = [cell.value for cell in next(sheet.iter_rows(max_row=1))]
                status_column = headers.index("ReviewStatus") + 1
                self.assertEqual(sheet.cell(first["row_hint"], status_column).value, "待评估")
            finally:
                workbook.close()

            after = bridge.excel_query(
                {"file": path.name, "query": "找出被标记为待评估的记录", "limit": 5}
            )
            self.assertEqual(after["matches"][0]["record_id"], first["record_id"])

            workbook = load_workbook(path)
            workbook["销售 数据"].insert_rows(2, amount=3)
            workbook.save(path)
            workbook.close()
            relocated = bridge.excel_patch(
                {
                    "file": path.name,
                    "operations": [
                        {
                            "record_id": first["record_id"],
                            "column": "Price",
                            "operation": "numeric_multiply",
                            "value": 2,
                        }
                    ],
                }
            )
            self.assertEqual(relocated["status"], "ok")
            self.assertEqual(relocated["modified"], 1)
            self.assertEqual(relocated["examples"][0]["row"], first["row_hint"] + 3)

            selector = {"Country": "France", "Price": {"lt": 5}}
            preview = bridge.excel_patch(
                {
                    "file": path.name,
                    "selector": selector,
                    "operation": {
                        "column": "Price",
                        "type": "numeric_multiply",
                        "value": 1.1,
                    },
                    "dry_run": True,
                }
            )
            self.assertEqual(preview["status"], "preview")
            self.assertGreater(preview["matched"], 0)
            self.assertLessEqual(len(preview["examples"]), 5)
            executed = bridge.excel_patch(
                {
                    "file": path.name,
                    "selector": selector,
                    "operation": {
                        "column": "Price",
                        "type": "numeric_multiply",
                        "value": 1.1,
                    },
                }
            )
            self.assertEqual(executed["status"], "ok")
            self.assertEqual(executed["modified"], preview["matched"])
            self.assertEqual(executed["reindexed"], preview["matched"])

    def test_incremental_index_only_syncs_changed_records(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "incremental.xlsx"
            create_workbook(path, 20)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            initial_batches = len(mock.state.upsert_batches)

            unchanged = bridge.excel_index({"file": str(path)})
            self.assertEqual(unchanged["unchanged"], 20)
            self.assertEqual(unchanged["indexed"], 0)
            self.assertEqual(len(mock.state.upsert_batches), initial_batches)

            workbook = load_workbook(path)
            workbook["销售 数据"]["C2"] = "CHRISTMAS STAR DECORATION"
            workbook.save(path)
            workbook.close()
            changed = bridge.excel_index({"file": str(path), "force_reindex": True})
            self.assertEqual(changed["updated"], 1)
            self.assertEqual(changed["unchanged"], 19)
            self.assertEqual(changed["indexed"], 1)
            self.assertEqual(mock.state.upsert_batches[-1], 1)

    def test_fallback_record_id_survives_patch_and_force_reindex(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "fallback.xlsx"
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "无主键"
            sheet.append(["Description", "Country"])
            sheet.append(["CHRISTMAS GLASS BALL", "EIRE"])
            sheet.append(["WOODEN STAR", "France"])
            workbook.save(path)
            workbook.close()
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            original = bridge.excel_query(
                {
                    "file": str(path),
                    "query": "",
                    "filters": {"Description": "CHRISTMAS GLASS BALL"},
                    "limit": 1,
                }
            )["matches"][0]
            bridge.excel_patch(
                {
                    "file": str(path),
                    "operations": [
                        {
                            "record_id": original["record_id"],
                            "column": "ReviewStatus",
                            "operation": "set",
                            "value": "链路已验证",
                        }
                    ],
                }
            )
            rechecked = bridge.excel_index(
                {"file": str(path), "force_reindex": True}
            )
            self.assertEqual(rechecked["indexed"], 0)
            self.assertEqual(rechecked["updated"], 0)
            self.assertEqual(rechecked["unchanged"], 2)
            after = bridge.excel_query(
                {
                    "file": str(path),
                    "query": "",
                    "filters": {"ReviewStatus": "链路已验证"},
                    "limit": 1,
                }
            )["matches"][0]
            self.assertEqual(after["record_id"], original["record_id"])

    def test_duplicate_business_key_is_ambiguous_even_at_old_row_hint(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "ambiguous.xlsx"
            create_workbook(path, 3)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            match = bridge.excel_query(
                {"file": path.name, "query": "圣诞装饰品", "limit": 1}
            )["matches"][0]

            workbook = load_workbook(path)
            sheet = workbook["销售 数据"]
            sheet.insert_rows(2)
            for column in range(1, sheet.max_column + 1):
                sheet.cell(2, column).value = sheet.cell(3, column).value
            workbook.save(path)
            workbook.close()

            result = bridge.excel_patch(
                {
                    "file": path.name,
                    "operations": [
                        {
                            "record_id": match["record_id"],
                            "column": "Price",
                            "operation": "numeric_add",
                            "value": 1,
                        }
                    ],
                }
            )
            self.assertEqual(result["status"], "error")
            self.assertEqual(result["modified"], 0)
            self.assertEqual(result["failures"][0]["status"], "ambiguous")

    def test_sqlite_schema_and_ambiguous_fingerprint_are_safe(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config = BridgeConfig(
                workspace=root,
                weknora=WeknoraConfig(enabled=False, knowledge_base_id=None),
            )
            bridge = ExcelBridge(config)
            connection = sqlite3.connect(config.database_path)
            try:
                tables = {
                    row[0]
                    for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    )
                }
                indexes = {
                    row[0]
                    for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='index'"
                    )
                }
            finally:
                connection.close()
            self.assertTrue({"files", "records"}.issubset(tables))
            self.assertTrue(
                {
                    "idx_records_file_id",
                    "idx_records_file_sheet",
                    "idx_records_fingerprint",
                    "idx_records_key_hash",
                }.issubset(indexes)
            )


class FiftyThousandRowAcceptanceTest(unittest.TestCase):
    def test_streaming_index_50000_rows(self) -> None:
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "acceptance-50000.xlsx"
            create_workbook(path, 50_000)
            bridge = bridge_for(root, mock)
            result = bridge.excel_index({"file": str(path)})
            self.assertEqual(result["records"], 50_000)
            self.assertEqual(result["added"], 50_000)
            self.assertEqual(sum(mock.state.upsert_batches), 50_000)
            self.assertEqual(max(mock.state.upsert_batches), 200)
            print(f"BENCHMARK_50000_SECONDS={result['elapsed_seconds']}")


if __name__ == "__main__":
    unittest.main()
