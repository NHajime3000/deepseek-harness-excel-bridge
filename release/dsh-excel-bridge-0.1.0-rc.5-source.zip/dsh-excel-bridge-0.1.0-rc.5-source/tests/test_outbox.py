from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from dataclasses import replace
from pathlib import Path

from openpyxl import load_workbook

from excel_bridge import ExcelBridge
from excel_bridge.config import OutboxConfig
from excel_bridge.reconcile import reconcile
from excel_bridge.storage import LocatorStore, SCHEMA
from tests.mock_weknora import MockWeknora
from tests.test_bridge import create_workbook, bridge_for
from tests.test_regressions import keyless_file


class OutboxTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mock = MockWeknora().__enter__()
        self.path = self.root / "零售.xlsx"
        create_workbook(self.path, 3)
        config = bridge_for(self.root, self.mock).config
        self.config = replace(config, outbox=OutboxConfig(retry_delays=(0,), lock_timeout=0))
        self.bridge = ExcelBridge(self.config)
        self.bridge.excel_index({"file": str(self.path)})
        self.record_id = self.bridge.excel_query({"file": str(self.path), "query": "", "filters": {"Country": "France"}})["matches"][0]["record_id"]

    def tearDown(self):
        self.mock.__exit__()
        self.temp.cleanup()

    def args(self, value="已恢复"):
        return {"file": str(self.path), "operations": [{"record_id": self.record_id, "column": "ReviewStatus", "operation": "set", "value": value}]}

    def tasks(self):
        with self.bridge.store.connection() as connection:
            return [dict(r) for r in connection.execute("SELECT * FROM outbox_tasks ORDER BY created_at,rowid")]

    def child(self, fault=None, command="patch"):
        env = {**os.environ, "PYTHONUTF8": "1", "EXCEL_BRIDGE_WORKSPACE": str(self.root),
               "EXCEL_BRIDGE_WEKNORA_BASE_URL": self.mock.base_url,
               "EXCEL_BRIDGE_WEKNORA_KNOWLEDGE_BASE_ID": "kb-test",
               "EXCEL_BRIDGE_OUTBOX_LOCK_TIMEOUT": "0", "EXCEL_BRIDGE_OUTBOX_RETRY_DELAYS": "0",
               "EXCEL_BRIDGE_POLL_INTERVAL": "0.001"}
        env.pop("EXCEL_BRIDGE_WEKNORA_API_KEY", None)
        if fault:
            env.update(EXCEL_BRIDGE_TEST_FAULTS="1", EXCEL_BRIDGE_FAIL_AT=fault)
        args = [sys.executable, "-m", "excel_bridge.cli", "excel_patch"] if command == "patch" else [sys.executable, "-m", "excel_bridge.maintenance", "recover", "--max-seconds", "10"]
        return subprocess.run(args, input=json.dumps(self.args()), text=True, encoding="utf-8", env=env, capture_output=True, timeout=30)

    def assert_synced(self, value="已恢复"):
        record = self.bridge.store.get_record(self.record_id)
        self.assertEqual(record.data["ReviewStatus"], value)
        self.assertEqual(record.rag_status, "synced")
        entries = self.mock.state.entries
        self.assertEqual(len(entries), 3)
        self.assertEqual(sum(f"record_id={self.record_id}" in e["answers"] for e in entries.values()), 1)
        self.assertIn(value, entries[record.weknora_entry_id]["standard_question"])
        self.assertEqual(sum(self.bridge.outbox.get_outbox_stats()[s] for s in ("pending", "retry", "processing", "failed", "blocked")), 0)

    def test_A_normal_patch_durable_completed(self):
        result = self.bridge.excel_patch(self.args())
        self.assertEqual(result["rag_sync"], {"completed": 1, "pending": 0, "failed": 0})
        self.assert_synced()
        report = reconcile(self.bridge.store, self.bridge.outbox, remote_limit=3)
        self.assertEqual(report["remote_missing"], 0)
        self.assert_synced()

    def test_B_connection_refused_then_fresh_process_recovers(self):
        self.mock.stop()
        result = self.bridge.excel_patch(self.args())
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["modified"], 1)
        self.assertEqual(self.tasks()[-1]["status"], "retry")
        self.assertEqual(self.bridge.store.get_record(self.record_id).data["ReviewStatus"], "已恢复")
        workbook = load_workbook(self.path)
        self.assertEqual(workbook.active["H2"].value, "已恢复")
        workbook.close()
        self.mock.restart()
        child = self.child(command="recover")
        self.assertEqual(child.returncode, 0, child.stderr)
        self.assert_synced()
        self.assertEqual(self.bridge.excel_query({"file": str(self.path), "query": "已恢复"})["count"], 1)

    def test_C_actual_exit_after_excel_save_recovers_journal(self):
        before = self.bridge.store.get_record(self.record_id).fingerprint
        child = self.child("FAIL_AFTER_EXCEL_SAVE")
        self.assertEqual(child.returncode, 86, child.stderr)
        self.assertEqual(self.bridge.store.get_record(self.record_id).fingerprint, before)
        self.assertEqual(self.child(command="recover").returncode, 0)
        self.assert_synced()

    def test_D_actual_exit_after_post_resumes_same_task_without_post(self):
        child = self.child("FAIL_AFTER_REMOTE_POST")
        self.assertEqual(child.returncode, 86, child.stderr)
        task = self.tasks()[-1]
        self.assertTrue(task["remote_task_id"])
        self.assertEqual(task["status"], "processing")
        count = len(self.mock.state.upsert_batches)
        self.assertEqual(self.child(command="recover").returncode, 0)
        self.assertIn(task["remote_task_id"], self.mock.state.progress_calls)
        self.assertEqual(len(self.mock.state.upsert_batches), count)
        self.assert_synced()

    def test_E_expired_processing_lease(self):
        self.mock.state.http_status = 503
        self.bridge.excel_patch(self.args())
        with self.bridge.store.connection() as connection:
            connection.execute("UPDATE outbox_tasks SET status='processing',locked_at=?,worker_id='dead' WHERE status='retry'", (time.time() - 601,))
        self.mock.state.http_status = 0
        self.bridge.outbox.run_until_idle()
        self.assert_synced()

    def test_F_old_retry_superseded_without_posting_old_version(self):
        self.mock.state.http_status = 503
        self.bridge.excel_patch(self.args("版本一"))
        old_id = self.tasks()[-1]["id"]
        self.bridge.excel_patch(self.args("版本二"))
        self.mock.state.http_status = 0
        posts = len(self.mock.state.upsert_batches)
        self.bridge.outbox.run_until_idle()
        self.assertEqual(len(self.mock.state.upsert_batches), posts + 1)
        self.assertEqual(next(t for t in self.tasks() if t["id"] == old_id)["status"], "superseded")
        self.assert_synced("版本二")

    def test_G_actual_exit_after_delete_before_create(self):
        child = self.child("FAIL_AFTER_REMOTE_DELETE")
        self.assertEqual(child.returncode, 86, child.stderr)
        self.assertEqual(len(self.mock.state.entries), 2)
        self.assertEqual(self.child(command="recover").returncode, 0)
        self.assert_synced()

    def test_H_two_real_workers_do_not_duplicate(self):
        self.mock.stop()
        self.bridge.excel_patch(self.args())
        self.mock.restart()
        results = []
        threads = [threading.Thread(target=lambda: results.append(self.child(command="recover"))) for _ in range(2)]
        posts = len(self.mock.state.upsert_batches)
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(40)
        self.assertEqual([r.returncode for r in results], [0, 0])
        self.assertEqual(len(self.mock.state.upsert_batches), posts + 1)
        self.assert_synced()

    def test_I_401_blocked_not_infinite_retry(self):
        self.mock.state.http_status = 401
        result = self.bridge.excel_patch(self.args())
        self.assertEqual(result["status"], "partial")
        task = self.tasks()[-1]
        self.assertEqual((task["status"], task["error_category"], task["attempt_count"]), ("blocked", "authorization", 1))
        self.bridge.outbox.run_until_idle()
        self.assertEqual(self.tasks()[-1]["attempt_count"], 1)

    def test_J_500_backoff_and_attempt_limit(self):
        self.bridge.outbox.config = OutboxConfig(retry_delays=(5, 15))
        self.mock.state.http_status = 500
        start = time.time()
        self.bridge.excel_patch(self.args())
        task = self.tasks()[-1]
        self.assertEqual((task["status"], task["attempt_count"]), ("retry", 1))
        self.assertGreaterEqual(task["next_retry_at"], start + 5)
        with self.bridge.store.connection() as connection:
            connection.execute("UPDATE outbox_tasks SET next_retry_at=0,attempt_count=7 WHERE id=?", (task["id"],))
        self.bridge.outbox.run_until_idle()
        self.assertEqual(self.tasks()[-1]["status"], "failed")

    def test_partial_batch_tracks_successes_individually(self):
        self.mock.state.partial_fail_indexes = {1}
        result = self.bridge.excel_patch({"file": str(self.path), "selector": {"Price": {"gt": 0}}, "operation": {"column": "ReviewStatus", "type": "set", "value": "批量"}})
        self.assertEqual(result["rag_sync"], {"completed": 2, "pending": 1, "failed": 0})
        self.mock.state.partial_fail_indexes.clear()
        self.bridge.outbox.run_until_idle()
        self.assertEqual(self.mock.state.upsert_batches[-1], 1)
        self.assertEqual(len(self.mock.state.entries), 3)

    def test_post_response_lost_resolves_by_record_and_fingerprint(self):
        child = self.child("FAIL_AFTER_REMOTE_ACCEPT_BEFORE_CHECKPOINT")
        self.assertEqual(child.returncode, 86, child.stderr)
        self.assertIsNone(self.tasks()[-1]["remote_task_id"])
        posts = len(self.mock.state.upsert_batches)
        self.assertEqual(self.child(command="recover").returncode, 0)
        self.assertEqual(len(self.mock.state.upsert_batches), posts)
        self.assert_synced()

    def test_remote_progress_expired_does_not_resubmit(self):
        self.assertEqual(self.child("FAIL_AFTER_REMOTE_POST").returncode, 86)
        self.mock.state.tasks.clear()
        posts = len(self.mock.state.upsert_batches)
        self.assertEqual(self.child(command="recover").returncode, 0)
        self.assertEqual(len(self.mock.state.upsert_batches), posts)
        self.assert_synced()

    def test_sqlite_commit_survives_actual_process_exit(self):
        self.assertEqual(self.child("FAIL_AFTER_SQLITE_UPDATE").returncode, 86)
        self.assertEqual(self.tasks()[-1]["status"], "pending")
        self.assertEqual(self.child(command="recover").returncode, 0)
        self.assert_synced()

    def test_deleted_record_keeps_remote_identity_in_tombstone(self):
        old_entry = self.bridge.store.get_record(self.record_id).weknora_entry_id
        workbook = load_workbook(self.path)
        workbook.active.delete_rows(2)
        workbook.save(self.path)
        workbook.close()
        self.mock.state.http_status = 503
        result = self.bridge.excel_index({"file": str(self.path)})
        self.assertEqual(result["deleted"], 1)
        self.assertIsNone(self.bridge.store.get_record(self.record_id))
        self.assertEqual(json.loads(self.tasks()[-1]["payload_json"])["old_entry_id"], old_entry)
        self.mock.state.http_status = 0
        self.bridge.outbox.run_until_idle()
        self.assertNotIn(old_entry, self.mock.state.entries)

    def test_reconcile_missing_entry_repairs_completed_task(self):
        record = self.bridge.store.get_record(self.record_id)
        self.mock.state.entries.pop(record.weknora_entry_id)
        report = reconcile(self.bridge.store, self.bridge.outbox)
        self.assertEqual(report["remote_missing"], 1)
        self.bridge.outbox.run_until_idle()
        self.assertEqual(len(self.mock.state.entries), 3)
        posts = len(self.mock.state.upsert_batches)
        self.bridge.outbox.run_until_idle()
        self.assertEqual(posts, len(self.mock.state.upsert_batches))

    def test_existing_v0_database_migrates_without_locator_rewrite(self):
        legacy = self.root / "legacy.db"
        with sqlite3.connect(legacy) as connection:
            connection.executescript(SCHEMA)
            connection.execute("INSERT INTO files VALUES ('f','test.xlsx','test.xlsx',1,1,'old','ready','{}')")
            connection.execute("INSERT INTO records VALUES ('r','f','s',2,'{}','','fp','{}','text',NULL,NULL,123,'synced',NULL,'old')")
        connection.close()
        for _ in range(2):
            store = LocatorStore(legacy)
            with store.connection() as connection:
                self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 4)
                self.assertEqual(tuple(connection.execute("SELECT record_id,fingerprint,weknora_entry_id,updated_at FROM records").fetchone()), ('r','fp',123,'old'))

    def test_batch_425_uses_three_posts_and_per_record_status(self):
        create_workbook(self.path, 425)
        self.bridge.excel_index({"file": str(self.path)})
        before_posts = len(self.mock.state.upsert_batches)
        before_deletes = len(self.mock.state.delete_batches)
        started = time.perf_counter()
        args = {"file": str(self.path), "selector": {"Price": {"gt": 0}}, "operation": {"column": "ReviewStatus", "type": "set", "value": "425批量恢复"}}
        from excel_bridge.approvals import ApprovalStore
        self.assertEqual(self.bridge.excel_patch(args)['status'], 'waiting_confirmation')
        approvals = ApprovalStore(self.bridge.store)
        row = approvals.list_pending()[0]
        approvals.approve(row['approval_id'], row['plan_hash'], actor='test-admin')
        result = self.bridge.excel_patch(args)
        self.assertEqual(result["rag_sync"], {"completed": 425, "pending": 0, "failed": 0})
        self.assertEqual(self.mock.state.upsert_batches[before_posts:], [200, 200, 25])
        self.assertEqual(self.mock.state.delete_batches[before_deletes:], [200, 200, 25])
        self.assertEqual(len(self.mock.state.entries), 425)
        print(f"OUTBOX_PATCH_425_SECONDS={time.perf_counter() - started:.3f}")

    def test_old_inflight_task_drains_and_cleans_before_new_version(self):
        self.assertEqual(self.child("FAIL_AFTER_REMOTE_POST").returncode, 86)
        before_posts = len(self.mock.state.upsert_batches)
        self.bridge.excel_patch(self.args("更新版本"))
        self.assertEqual(len(self.mock.state.upsert_batches), before_posts + 1)
        self.assert_synced("更新版本")
        self.assertEqual(self.tasks()[-2]["status"], "superseded")

    def test_unknown_post_absence_blocks_instead_of_blind_repost(self):
        self.assertEqual(self.child("FAIL_AFTER_REMOTE_ACCEPT_BEFORE_CHECKPOINT").returncode, 86)
        record_entries = [i for i,e in self.mock.state.entries.items() if f"record_id={self.record_id}" in e["answers"]]
        for entry in record_entries:
            self.mock.state.entries.pop(entry)
        posts = len(self.mock.state.upsert_batches)
        self.bridge.outbox.run_until_idle()
        self.assertEqual(self.tasks()[-1]["status"], "blocked")
        self.assertEqual(self.tasks()[-1]["error_category"], "uncertain")
        self.assertEqual(len(self.mock.state.upsert_batches), posts)

    def test_keyless_after_save_crash_preserves_record_identity(self):
        path = self.root / "无业务键.xlsx"
        keyless_file(path)
        self.bridge.excel_index({"file": str(path)})
        self.path = path
        self.record_id = self.bridge.excel_query({"file": str(path), "query": "", "filters": {"Country": "EIRE"}})["matches"][0]["record_id"]
        self.assertEqual(self.child("FAIL_AFTER_EXCEL_SAVE").returncode, 86)
        self.assertEqual(self.child(command="recover").returncode, 0)
        record = self.bridge.store.get_record(self.record_id)
        self.assertEqual(record.data["ReviewStatus"], "已恢复")
        self.assertEqual(record.rag_status, "synced")
        result = self.bridge.excel_index({"file": str(path), "force_reindex": True})
        self.assertEqual((result["added"], result["deleted"], result["indexed"]), (0, 0, 0))

    def test_external_excel_change_fences_old_queued_content(self):
        self.mock.state.http_status = 503
        self.bridge.excel_patch(self.args())
        workbook = load_workbook(self.path)
        workbook.active["C2"] = "Excel事实已更新"
        workbook.save(self.path)
        workbook.close()
        self.mock.state.http_status = 0
        self.bridge.outbox.run_until_idle()
        self.assert_synced()
        record = self.bridge.store.get_record(self.record_id)
        self.assertEqual(record.data["Description"], "Excel事实已更新")
        self.assertIn("Excel事实已更新", self.mock.state.entries[record.weknora_entry_id]["standard_question"])

    def test_missing_excel_reported_even_when_outbox_was_empty(self):
        self.path.rename(self.root / "moved.xlsx")
        result = self.bridge.outbox.run_until_idle()
        self.assertEqual(result["local_reconcile"]["blocked_files"], 1)
        self.assertTrue(result["local_reconcile"]["errors"])
        with self.bridge.store.connection() as connection:
            self.assertEqual(connection.execute("SELECT status FROM files").fetchone()[0], "reconcile_blocked")


if __name__ == "__main__":
    unittest.main()
