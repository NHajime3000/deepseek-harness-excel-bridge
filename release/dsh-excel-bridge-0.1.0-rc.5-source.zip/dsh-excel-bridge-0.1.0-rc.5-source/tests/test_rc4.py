import copy
import json
import tempfile
import unittest
import os
import subprocess
import sys
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from excel_bridge.approvals import ApprovalStore, digest
from excel_bridge.compiler import MultistageCompiler, CompilerTransport
from excel_bridge.config import BridgeConfig, WeknoraConfig, WorkflowConfig
from excel_bridge.plan_ir import PlanError
from excel_bridge.procedure import ProcedureEngine
from excel_bridge.recipes import RecipeMemory
from excel_bridge.resolver import RecipeResolver
from excel_bridge.service import ExcelBridge
from excel_bridge.sop import SopCompiler
from excel_bridge.reconcile import file_hash
from tests.test_workflow import fixture, simple_plan, approve


class RC4Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.file = self.root / 'B.xlsx'
        fixture(self.file, renamed=True)
        self.config = BridgeConfig(self.root, WeknoraConfig(enabled=False),
            workflow=WorkflowConfig(procedure_enabled=True, recipe_enabled=True))
        self.bridge = ExcelBridge(self.config)
        self.memory = RecipeMemory(self.bridge.store)
        self.args = {'instruction': '按上次物流投诉处理方法', 'files': [str(self.file)]}

    def tearDown(self):
        self.temp.cleanup()

    def call(self, args=None, session='trusted-session'):
        return self.bridge.procedure_run(args or self.args, session_key=session)

    def test_model_cannot_supply_any_internal_or_confirmation_argument(self):
        before = file_hash(self.file)
        for key in ('run_id', 'recipe_id', 'procedure_id', 'mapping', 'plan_json', 'confirm', 'session_key', 'approval_token'):
            self.assertEqual(self.call({**self.args, key: 'invented'})['status'], 'invalid_arguments')
        self.assertEqual(file_hash(self.file), before)

    def test_missing_instruction_stops_without_reading_excel(self):
        self.assertEqual(self.call({'files': [str(self.file)]})['status'], 'invalid_arguments')

    def test_wrong_file_is_not_guessed(self):
        self.assertEqual(self.call({**self.args, 'files': ['invented.xlsx']})['status'], 'invalid_file')

    def test_no_trusted_session_never_uses_shared_fallback(self):
        self.assertEqual(self.call(session=None)['status'], 'needs_review')

    def test_no_history_does_not_silently_compile_reuse(self):
        with patch.object(SopCompiler, 'ingest', side_effect=AssertionError('must not compile')):
            self.assertEqual(self.call()['status'], 'no_recipe_match')

    def test_two_similar_recipes_stop(self):
        self.memory.create(simple_plan())
        self.memory.create(simple_plan())
        result = self.call()
        self.assertEqual(result['status'], 'needs_review', result)
        self.assertLessEqual(len(result['candidates']), 3)
        self.assertNotIn('recipe_id', json.dumps(result))

    def test_low_confidence_stops(self):
        with patch.object(self.memory, 'search', return_value=[{'name':'weak','score':.69,'mapping_status':'mapped'}]):
            self.assertEqual(RecipeResolver(self.memory).resolve('x', [])['status'], 'needs_review')

    def test_history_synonyms_and_inline_file_path_do_not_dilute_intent(self):
        plan = simple_plan(); plan['name'] = plan['intent'] = '物流延迟、配送异常、快递丢件复核'
        self.memory.create(plan, 'history')
        result = RecipeResolver(self.memory).resolve('按上次物流投诉的方式处理这个表：E:/tests/new-table.xlsx。', ['客诉描述','处理标记'])
        self.assertEqual(result['status'], 'resolved', result)

    def test_topic_word_in_unrelated_long_template_is_not_high_confidence(self):
        plan = simple_plan(); plan['name'] = plan['intent'] = '物流库存供应发票税务审计账龄促销额度退款审批预算'
        self.memory.create(plan)
        result = RecipeResolver(self.memory).resolve('按上次物流投诉的方式处理这个表', ['客诉描述','处理标记'])
        self.assertEqual(result['status'], 'needs_review', result)

    def test_missing_fields_require_mapping(self):
        self.memory.create(simple_plan())
        result = RecipeResolver(self.memory).resolve('物流投诉处理', ['ID', '客诉描述'])
        self.assertEqual(result['status'], 'needs_mapping', result)

    def test_ambiguous_fields_require_mapping(self):
        self.memory.create(simple_plan())
        result = RecipeResolver(self.memory).resolve('物流投诉处理', ['ComplaintText', '客诉描述', '处理标记'])
        self.assertEqual(result['status'], 'needs_mapping', result)

    def test_resolver_binds_ids_and_resumes_only_after_admin_approval(self):
        self.memory.create(simple_plan())
        before = file_hash(self.file)
        first = self.call()
        self.assertEqual(first['status'], 'waiting_confirmation', first)
        self.assertEqual(first['mapping'], {'complaint_text': '客诉描述', 'review_status': '处理标记'})
        self.assertNotIn('run_id', json.dumps(first))
        self.assertEqual(self.call()['status'], 'waiting_confirmation')
        self.assertEqual(file_hash(self.file), before)
        pending = ApprovalStore(self.bridge.store).list_pending()
        self.assertEqual(len(pending), 1)
        ApprovalStore(self.bridge.store).approve(pending[0]['approval_id'], pending[0]['plan_hash'], actor='test-admin')
        result = self.call()
        self.assertEqual(result['status'], 'completed', result)
        after = file_hash(self.file)
        self.assertEqual(self.call()['status'], 'completed')
        self.assertEqual(file_hash(self.file), after)

    def test_session_isolation_does_not_share_approval(self):
        self.memory.create(simple_plan())
        self.call(session='one')
        self.call(session='two')
        self.assertEqual(len(ApprovalStore(self.bridge.store).list_pending()), 2)

    def test_changed_instruction_does_not_resume_old_approved_run(self):
        self.memory.create(simple_plan())
        self.call()
        row = ApprovalStore(self.bridge.store).list_pending()[0]
        ApprovalStore(self.bridge.store).approve(row['approval_id'], row['plan_hash'], actor='test-admin')
        before = file_hash(self.file)
        changed = {**self.args, 'instruction': '物流投诉处理，但把价格翻倍'}
        self.assertEqual(self.call(changed)['status'], 'needs_review')
        self.assertEqual(file_hash(self.file), before)

    def test_plan_tamper_invalidates_approval(self):
        engine = ProcedureEngine(self.bridge)
        preview = engine.prepare(self.file, simple_plan())
        approve(self.bridge.store, preview)
        before = file_hash(self.file)
        with self.bridge.store.connection() as db:
            plan = simple_plan(); plan['steps'][1]['value'] = 'changed'
            db.execute('UPDATE procedure_runs SET plan_json=? WHERE run_id=?', (json.dumps(plan), preview['run_id']))
        result = engine.resume(preview['run_id'], confirm=True)
        self.assertEqual(result['status'], 'needs_review')
        self.assertEqual(result['approval_state'], 'INVALIDATED')
        self.assertEqual(file_hash(self.file), before)

    def test_mapping_and_target_tamper_each_invalidate_approval(self):
        for field in ('mapping_json', 'items'):
            with self.subTest(field=field):
                engine = ProcedureEngine(self.bridge)
                preview = engine.prepare(self.file, simple_plan())
                approve(self.bridge.store, preview)
                with self.bridge.store.connection() as db:
                    if field == 'mapping_json':
                        db.execute("UPDATE procedure_runs SET mapping_json='{}' WHERE run_id=?", (preview['run_id'],))
                    else:
                        db.execute("DELETE FROM procedure_items WHERE run_id=? AND step_id='write'", (preview['run_id'],))
                self.assertEqual(engine.resume(preview['run_id'], confirm=True)['status'], 'needs_review')

    def test_wrong_hash_cannot_be_approved(self):
        self.memory.create(simple_plan()); self.call()
        row = ApprovalStore(self.bridge.store).list_pending()[0]
        with self.assertRaises(PlanError):
            ApprovalStore(self.bridge.store).approve(row['approval_id'], 'wrong', actor='admin')

    def test_bulk_patch_approval_is_backend_enforced(self):
        bridge = ExcelBridge(replace(self.config, workflow=replace(self.config.workflow, preview_threshold=2)))
        bridge.excel_index({'file': str(self.file)})
        args = {'file': str(self.file), 'selector': {'Price': {'gt': 0}},
                'operation': {'column': 'Price', 'type': 'numeric_add', 'value': 1}}
        before = file_hash(self.file)
        preview = bridge.excel_patch(args)
        self.assertEqual(preview['status'], 'waiting_confirmation')
        self.assertEqual(file_hash(self.file), before)
        with self.assertRaises(ValueError): bridge.excel_patch({**args, 'confirm': True})
        row = ApprovalStore(bridge.store).list_pending()[0]
        ApprovalStore(bridge.store).approve(row['approval_id'], row['plan_hash'], actor='admin')
        self.assertEqual(bridge.excel_patch(args)['modified'], 3)

    def test_bulk_operation_change_invalidates_old_approval(self):
        bridge = ExcelBridge(replace(self.config, workflow=replace(self.config.workflow, preview_threshold=2)))
        bridge.excel_index({'file': str(self.file)})
        args = {'file': str(self.file), 'selector': {'Price': {'gt': 0}}, 'operation': {'column': 'Price', 'type': 'numeric_add', 'value': 1}}
        bridge.excel_patch(args)
        row = ApprovalStore(bridge.store).list_pending()[0]
        ApprovalStore(bridge.store).approve(row['approval_id'], row['plan_hash'], actor='admin')
        args['operation']['value'] = 2
        self.assertEqual(bridge.excel_patch(args)['status'], 'waiting_confirmation')
        with self.bridge.store.connection() as db:
            self.assertEqual(db.execute('SELECT state FROM workflow_approvals WHERE approval_id=?', (row['approval_id'],)).fetchone()[0], 'INVALIDATED')

    def test_complex_actual_exit_preserves_approval_and_remote_convergence(self):
        from tests.workspace_mock import WorkspaceMock
        from excel_bridge.config import OutboxConfig
        mock = WorkspaceMock()
        try:
            config = replace(self.config, weknora=WeknoraConfig(base_url=mock.base_url, tenant_id='test',
                embedding_model_id='embedding', poll_interval=.001), outbox=OutboxConfig(retry_delays=(0,)))
            bridge = ExcelBridge(config)
            engine = ProcedureEngine(bridge, semantic_reviewer=lambda *_: self.fail('Deterministic steps must not call a model'))
            plan = {'ir_version':1,'name':'Branch recovery','required_roles':['price'], 'steps':[
                {'id':'eligible','type':'filter','condition':{'price':{'gt':0}}},
                {'id':'split','type':'branch','source':'eligible','condition':{'price':{'gt':5}},'then':'high','else':'low'},
                {'id':'high','type':'patch','source':'split.then','role':'price','operation':'numeric_add','value':2},
                {'id':'low','type':'patch','source':'split.else','role':'price','operation':'numeric_add','value':1},
                {'id':'join','type':'select','source':['high','low'],'roles':['price']},
                {'id':'check','type':'verify','source':'join','condition':{'price':{'gt':0}}},
                {'id':'count','type':'aggregate','source':'check','metric':'count'},
                {'id':'export','type':'export_summary','source':'count'}]}
            preview = engine.prepare(self.file, plan)
            approve(bridge.store, preview)
            approval_hash = preview['plan_hash']
            env = {**os.environ,'PYTHONUTF8':'1','EXCEL_BRIDGE_WORKSPACE':str(self.root),
                   'EXCEL_BRIDGE_WEKNORA_ENABLED':'true','EXCEL_BRIDGE_WEKNORA_BASE_URL':mock.base_url,
                   'EXCEL_BRIDGE_WEKNORA_TENANT_ID':'test','EXCEL_BRIDGE_EMBEDDING_MODEL_ID':'embedding',
                   'EXCEL_BRIDGE_TEST_FAULTS':'1','EXCEL_BRIDGE_FAIL_AT':'PROCEDURE_AFTER_PATCH_3'}
            child = subprocess.run([sys.executable,'-m','excel_bridge.workflow_cli','resume'],
                input=json.dumps({'run_id':preview['run_id']}),text=True,encoding='utf-8',capture_output=True,env=env,timeout=45)
            self.assertEqual(child.returncode,86,child.stdout+child.stderr)
            result = ProcedureEngine(ExcelBridge(config)).resume(preview['run_id'])
            self.assertEqual(result['status'],'completed',result)
            self.assertEqual(result['sync_status'],'synced')
            self.assertFalse(any(result['outbox'][s] for s in ('pending','processing','retry','failed','blocked')))
            from openpyxl import load_workbook
            book=load_workbook(self.file,read_only=True)
            self.assertEqual([r[3] for r in list(book.active.values)[1:]],[3.95,14,6]);book.close()
            with bridge.store.connection() as db:
                row=db.execute("SELECT plan_hash,state FROM workflow_approvals WHERE subject=?",(preview['run_id'],)).fetchone()
                self.assertEqual((row['plan_hash'],row['state']),(approval_hash,'COMPLETED'))
            self.assertEqual(len(list(config.backup_dir.glob('*.xlsx'))),2)
            after=file_hash(self.file)
            engine.resume(preview['run_id'])
            self.assertEqual(file_hash(self.file),after)
        finally:
            mock.stop()


class CompilerPassTests(RC4Tests):
    # Do not inherit the API tests a second time; loaded explicitly below.
    def rule(self):
        return {'condition': '', 'action': 'set review_status to review', 'exceptions': [], 'roles': ['review_status'],
                'semantic': False, 'order': 0, 'depends_on': [], 'paragraphs': [0]}

    def test_multistage_checkpoint_does_not_reread_document_during_assembly(self):
        source = self.root / 'sop.txt'; source.write_text('Set ReviewStatus to review.', encoding='utf-8')
        pid = SopCompiler(self.bridge.store, self.config.workflow).ingest(source)
        calls = []
        def complete(stage, system, payload, schema):
            calls.append((stage, payload))
            if stage == 'extract': return {'rules': [self.rule()], 'descriptions': [], 'needs_review': []}, {}
            if stage == 'assemble':
                self.assertEqual(set(payload), {'rule'})
                return {'required_roles': ['review_status'], 'steps': [{'id':'s1','type':'patch','role':'review_status','operation':'set','value':'review'}],
                        'coverage':[{'paragraph':0,'kind':'rule','steps':['s1']}], 'needs_review': []}, {}
            return {'supported': True, 'reason': ''}, {}
        compiler = MultistageCompiler(self.bridge.store, self.config.workflow, complete)
        self.assertEqual(compiler.compile_next(pid)['status'], 'compiling')
        self.assertEqual(compiler.compile_next(pid)['status'], 'validated')
        compiler.compile_next(pid)
        self.assertEqual([c[0] for c in calls], ['extract', 'extract_check', 'assemble', 'coverage'])

    def test_missing_paragraph_is_not_silently_accepted(self):
        with self.assertRaises(PlanError):
            MultistageCompiler.validate_extraction({'rules':[self.rule()], 'descriptions':[], 'needs_review':[]},
                [{'paragraph':0,'text':'a'},{'paragraph':1,'text':'b'}], 0)

    def test_dependency_forward_reference_rejected(self):
        rule = self.rule(); rule['depends_on'] = [1]
        with self.assertRaises(PlanError):
            MultistageCompiler.validate_extraction({'rules':[rule], 'descriptions':[], 'needs_review':[]}, [{'paragraph':0,'text':'a'}], 0)

    def test_exact_rule_merge_retains_all_provenance(self):
        a = {**self.rule(), 'rule_id':'a','provenance':[{'chunk':0,'paragraph':0}]}
        b = {**self.rule(), 'paragraphs':[1], 'rule_id':'b','provenance':[{'chunk':1,'paragraph':1}]}
        merged = MultistageCompiler.merge_rules([[a],[b]])
        self.assertEqual(len(merged), 1)
        self.assertEqual(len(merged[0]['provenance']), 2)

    def test_disabled_compiler_makes_no_http_request(self):
        config = replace(self.config.workflow, compiler_provider='manual_review')
        with patch('urllib.request.urlopen', side_effect=AssertionError('no HTTP')):
            with self.assertRaises(PlanError): CompilerTransport(config)('extract', '', {}, {})


def load_tests(loader, tests, pattern):
    suite = unittest.TestSuite(loader.loadTestsFromTestCase(RC4Tests))
    for name in CompilerPassTests.__dict__:
        if name.startswith('test_'): suite.addTest(CompilerPassTests(name))
    return suite
