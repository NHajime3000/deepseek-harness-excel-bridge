from __future__ import annotations

import tempfile
import os
import unittest
from pathlib import Path
from unittest.mock import patch

from openpyxl import Workbook, load_workbook

from excel_bridge import BridgeConfig, ExcelBridge, WeknoraConfig
from excel_bridge.utils import extract_record_id, validate_filters
from tests.mock_weknora import MockWeknora
from tests.test_bridge import bridge_for, create_workbook


def keyless_file(path: Path) -> None:
    workbook = Workbook()
    workbook.active.append(["Description", "Country"])
    workbook.active.append(["CHRISTMAS BALL", "EIRE"])
    workbook.active.append(["WOODEN STAR", "France"])
    workbook.save(path)
    workbook.close()


class RegressionTests(unittest.TestCase):
    def test_unknown_filter_column_reports_actual_columns(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "columns.xlsx"
            create_workbook(path, 3)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            with self.assertRaisesRegex(ValueError, "Unknown filter column.*Available columns.*Description"):
                bridge.excel_query({"file": str(path), "query": "Christmas", "filters": {"product_name": {"contains": "Christmas"}}})
            self.assertEqual(mock.state.search_calls, 0)

    def test_invalid_contains_is_rejected_instead_of_silent_no_matches(self):
        with self.assertRaisesRegex(ValueError, "contains must be a string"):
            validate_filters({"Description": {"contains": ["christmas"]}})
        with self.assertRaisesRegex(ValueError, "unsupported filter"):
            validate_filters({"Price": {"lessthan": 5}})
        validate_filters({"Description": {"contains": "christmas"}, "Price": {"lt": 5}})

    def test_short_windows_replace_lock_is_retried(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "lock.xlsx"
            create_workbook(path, 3)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            actual_replace = os.replace
            attempts = 0
            def temporarily_locked(source, destination):
                nonlocal attempts
                attempts += 1
                if attempts < 3:
                    raise PermissionError("simulated short file handle lock")
                return actual_replace(source, destination)
            with patch("excel_bridge.patcher.os.replace", side_effect=temporarily_locked):
                result = bridge.excel_patch({"file": str(path), "selector": {"Country": "France"}, "operation": {"column": "Price", "type": "numeric_add", "value": 1}})
            self.assertEqual(attempts, 3)
            self.assertEqual(result["modified"], 1)
            self.assertTrue(Path(result["backup"]).exists())

    def test_keyless_numeric_patch_survives_excel_roundtrip(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "float.xlsx"
            workbook = Workbook()
            workbook.active.append(["Description", "Price"])
            workbook.active.append(["CHRISTMAS BALL", 2.95])
            workbook.active.append(["WOODEN STAR", 10.0])
            workbook.save(path)
            workbook.close()
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            before = bridge.excel_query({"file": str(path), "query": "", "filters": {"Price": {"gt": 0}}})
            result = bridge.excel_patch({"file": str(path), "selector": {"Price": {"gt": 0}}, "operation": {"column": "Price", "type": "numeric_multiply", "value": 1.1}})
            self.assertEqual(result["modified"], 2)
            recheck = bridge.excel_index({"file": str(path), "force_reindex": True})
            self.assertEqual((recheck["indexed"], recheck["deleted"], recheck["unchanged"]), (0, 0, 2))
            after = bridge.excel_query({"file": str(path), "query": "", "filters": {"Price": {"gt": 0}}})
            self.assertEqual([item["record_id"] for item in before["matches"]], [item["record_id"] for item in after["matches"]])

    def test_existing_composite_key_is_not_rediscovered_after_delete(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "keys.xlsx"
            workbook = Workbook()
            sheet = workbook.active
            sheet.append(["Invoice", "StockCode", "Description"])
            for row in [[1, "A", "Christmas"], [1, "B", "Star"], [2, "A", "Tree"]]:
                sheet.append(row)
            workbook.save(path)
            workbook.close()
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            original = bridge.excel_query({"file": str(path), "query": "", "filters": {"Description": "Christmas"}})["matches"][0]
            self.assertEqual(set(original["key"]), {"Invoice", "StockCode"})
            workbook = load_workbook(path)
            workbook.active.delete_rows(3)
            workbook.save(path)
            workbook.close()
            recheck = bridge.excel_index({"file": str(path), "force_reindex": True})
            self.assertEqual((recheck["added"], recheck["deleted"], recheck["unchanged"]), (0, 1, 2))
            after = bridge.excel_query({"file": str(path), "query": "", "filters": {"Description": "Christmas"}})["matches"][0]
            self.assertEqual(after["record_id"], original["record_id"])

    def test_selector_cannot_hide_duplicate_key_outside_filters(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "duplicate.xlsx"
            create_workbook(path, 3)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            workbook = load_workbook(path)
            row = [cell.value for cell in workbook.active[2]]
            row[-1] = "Germany"
            workbook.active.append(row)
            workbook.save(path)
            workbook.close()
            result = bridge.excel_patch({"file": str(path), "selector": {"Country": "France"}, "operation": {"column": "Price", "type": "numeric_add", "value": 1}})
            self.assertEqual(result["modified"], 0)
            self.assertEqual(result["failures"][0]["status"], "ambiguous")

    def test_answer_record_id_contract(self):
        record_id = "rec_0123456789abcdef01234567"
        self.assertEqual(extract_record_id([f"record_id={record_id}"]), record_id)
        self.assertEqual(extract_record_id(f"[excel-record:{record_id}]"), record_id)

    def test_keyless_external_edit_is_new_identity_not_row_guess(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "keyless.xlsx"
            keyless_file(path)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            old = bridge.excel_query({"file": str(path), "query": "", "filters": {"Country": "EIRE"}})["matches"][0]
            workbook = load_workbook(path)
            workbook.active["A2"] = "REPLACEMENT PRODUCT"
            workbook.save(path)
            workbook.close()
            result = bridge.excel_index({"file": str(path), "force_reindex": True})
            self.assertEqual((result["added"], result["deleted"], result["updated"]), (1, 1, 0))
            new = bridge.excel_query({"file": str(path), "query": "", "filters": {"Country": "EIRE"}})["matches"][0]
            self.assertNotEqual(old["record_id"], new["record_id"])

    def test_keyless_original_reappearing_does_not_steal_patched_id(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "keyless.xlsx"
            keyless_file(path)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            old = bridge.excel_query({"file": str(path), "query": "", "filters": {"Country": "EIRE"}})["matches"][0]
            bridge.excel_patch({"file": str(path), "operations": [{"record_id": old["record_id"], "column": "ReviewStatus", "operation": "set", "value": "待评估"}]})
            workbook = load_workbook(path)
            workbook.active.append(["CHRISTMAS BALL", "EIRE", None])
            workbook.save(path)
            workbook.close()
            result = bridge.excel_index({"file": str(path), "force_reindex": True})
            self.assertEqual((result["added"], result["unchanged"]), (1, 2))
            after = bridge.excel_query({"file": str(path), "query": "", "filters": {"ReviewStatus": "待评估"}})
            self.assertEqual(after["matches"][0]["record_id"], old["record_id"])

    def test_patch_rejects_record_from_another_file(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            bridge = bridge_for(root, mock)
            for name in ("one.xlsx", "two.xlsx"):
                create_workbook(root / name, 3)
                bridge.excel_index({"file": str(root / name)})
            record = bridge.excel_query({"file": "one.xlsx", "query": "", "filters": {"Country": "France"}})["matches"][0]
            result = bridge.excel_patch({"file": "two.xlsx", "operations": [{"record_id": record["record_id"], "column": "Price", "operation": "numeric_add", "value": 1}]})
            self.assertEqual(result["modified"], 0)
            self.assertEqual(result["failures"][0]["status"], "not_found")

    def test_index_repairs_failed_rag_even_if_file_unchanged(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "repair.xlsx"
            create_workbook(path, 3)
            bridge = bridge_for(root, mock)
            bridge.excel_index({"file": str(path)})
            record = bridge.excel_query({"file": path.name, "query": "", "filters": {"Country": "France"}})["matches"][0]
            # All delivery now uses Outbox. Inject at the actual preflight boundary.
            with patch("excel_bridge.weknora_client.WeknoraClient.verify_knowledge_base", side_effect=RuntimeError("simulated outage")):
                result = bridge.excel_patch({"file": path.name, "operations": [{"record_id": record["record_id"], "column": "ReviewStatus", "operation": "set", "value": "待评估"}]})
            self.assertEqual(result["status"], "partial")
            self.assertEqual(bridge.store.get_record(record["record_id"]).rag_status, "error")
            before = len(mock.state.upsert_batches)
            with bridge.store.connection() as connection:
                connection.execute("UPDATE outbox_tasks SET next_retry_at=0 WHERE status='retry'")
            bridge.excel_index({"file": str(path)})
            self.assertEqual(len(mock.state.upsert_batches), before + 1)
            self.assertEqual(mock.state.upsert_batches[-1], 1)
            self.assertEqual(bridge.store.get_record(record["record_id"]).rag_status, "synced")

    def test_local_only_index_syncs_when_weknora_enabled_later(self):
        with tempfile.TemporaryDirectory() as temporary, MockWeknora() as mock:
            root = Path(temporary)
            path = root / "local.xlsx"
            create_workbook(path, 3)
            local = ExcelBridge(BridgeConfig(workspace=root, weknora=WeknoraConfig(enabled=False)))
            local.excel_index({"file": str(path)})
            bridge_for(root, mock).excel_index({"file": str(path)})
            self.assertEqual(mock.state.upsert_batches, [3])


if __name__ == "__main__":
    unittest.main()
