import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from openpyxl import Workbook, load_workbook
from excel_bridge import ExcelBridge
from excel_bridge.config import BridgeConfig, WeknoraConfig, WorkflowConfig, OutboxConfig
from excel_bridge.plan_ir import PlanError, validate_plan, bind_parameters
from excel_bridge.procedure import ProcedureEngine
from excel_bridge.recipes import RecipeMemory
from excel_bridge.reconcile import file_hash
from excel_bridge.sop import extract_document, SopCompiler
from excel_bridge.approvals import ApprovalStore
from tests.workspace_mock import WorkspaceMock


def simple_plan():
    return {'ir_version': 1, 'name': '物流投诉复核', 'intent': '物流投诉处理',
            'required_roles': ['complaint_text', 'review_status'], 'parameters': {'status': '需要复核'},
            'steps': [{'id': 'find', 'type': 'filter', 'condition': {'complaint_text': {'contains': '物流'}}},
                      {'id': 'write', 'type': 'patch', 'source': 'find', 'role': 'review_status', 'operation': 'set', 'value': '${status}'},
                      {'id': 'count', 'type': 'aggregate', 'source': 'write', 'metric': 'count'}]}


def fixture(path, renamed=False):
    book = Workbook()
    book.active.append(['ID', '客诉描述' if renamed else 'ComplaintText', '处理标记' if renamed else 'ReviewStatus', 'Price'])
    book.active.append([1, '物流延迟 未送达', '未处理', 2.95])
    book.active.append([2, '商品质量问题', '未处理', 12])
    book.active.append([3, '物流丢件 快递异常', '未处理', 5])
    book.save(path)
    book.close()


def approve(store, preview):
    approvals = ApprovalStore(store)
    row = next(r for r in approvals.list_pending() if r['subject'] == preview['run_id'])
    approvals.approve(row['approval_id'], row['plan_hash'], actor='test-administrator')


class PlanTests(unittest.TestCase):
    def test_valid_parameterized_plan(self):
        self.assertEqual(bind_parameters(simple_plan(), {'status': '待评估'})['steps'][1]['value'], '待评估')

    def test_rejects_unknown_step(self):
        p = simple_plan(); p['steps'][0]['type'] = 'shell'
        with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_cycle(self):
        p = simple_plan(); p['steps'][0]['source'] = 'count'
        with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_old_locators(self):
        for key in ['record_id', 'row', 'file', 'knowledge_base_id']:
            p = simple_plan(); p[key] = 'old'
            with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_unknown_role(self):
        p = simple_plan(); p['steps'][1]['role'] = 'invented'
        with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_bad_branch_target(self):
        p = simple_plan(); p['steps'][0] = {'id': 'branch', 'type': 'branch', 'condition': {'review_status': 'x'}, 'then': 'missing', 'else': 'count'}
        with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_compound_patch_value(self):
        p = simple_plan(); p['steps'][1]['value'] = {'text': 'bad'}
        with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_formula_payload(self):
        p = simple_plan(); p['steps'][1]['value'] = '=HYPERLINK("https://invalid")'
        with self.assertRaises(PlanError): validate_plan(p)

    def test_rejects_semantic_search_after_write(self):
        p = simple_plan()
        p['steps'].append({'id':'late','type':'semantic_query','role':'complaint_text','query':'物流'})
        with self.assertRaises(PlanError): validate_plan(p)


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.file = self.root / 'A.xlsx'
        fixture(self.file)
        self.config = BridgeConfig(self.root, WeknoraConfig(enabled=False),
            workflow=WorkflowConfig(procedure_enabled=True, recipe_enabled=True))
        self.bridge = ExcelBridge(self.config)
        self.engine = ProcedureEngine(self.bridge)

    def tearDown(self):
        self.temp.cleanup()

    def values(self):
        book = load_workbook(self.file, read_only=True)
        values = list(book.active.values)
        book.close()
        return values

    def test_preview_is_read_only_and_requires_confirmation(self):
        before = file_hash(self.file)
        preview = self.engine.prepare(self.file, simple_plan())
        self.assertEqual(preview['status'], 'waiting_confirmation')
        self.assertEqual(preview['matched'], 2)
        self.assertEqual(self.engine.resume(preview['run_id'])['status'], 'waiting_confirmation')
        self.assertEqual(file_hash(self.file), before)
        self.assertEqual(self.engine.resume(preview['run_id'], confirm=True)['status'], 'waiting_confirmation')
        approve(self.bridge.store, preview)
        result = self.engine.resume(preview['run_id'], confirm=True)
        self.assertEqual(result['status'], 'completed', result)
        self.assertEqual([r[2] for r in self.values()[1:]], ['需要复核', '未处理', '需要复核'])
        after = file_hash(self.file)
        self.engine.resume(preview['run_id'], confirm=True)
        self.assertEqual(file_hash(self.file), after)

    def test_recipe_reuse_maps_renamed_columns(self):
        rid = self.engine.memory.create(simple_plan())
        a = self.engine.prepare(self.file, simple_plan(), recipe_id=rid)
        approve(self.bridge.store, a)
        self.engine.resume(a['run_id'], confirm=True)
        second = self.root / 'B.xlsx'; fixture(second, renamed=True)
        matches = self.engine.memory.search('按上次物流投诉处理方法', ['ID', '客诉描述', '处理标记', 'Price'])
        self.assertEqual(matches[0]['recipe_id'], rid)
        b = self.engine.prepare(second, simple_plan(), recipe_id=rid)
        approve(self.bridge.store, b)
        self.assertEqual(b['mapping']['complaint_text'], '客诉描述')
        self.assertEqual(b['mapping']['review_status'], '处理标记')
        self.assertEqual(self.engine.resume(b['run_id'], confirm=True)['status'], 'completed')
        # Local-only diagnostics cannot activate a template claiming remote sync.
        self.assertEqual(self.engine.memory.get(rid)['status'], 'draft')
        with self.bridge.store.connection() as db:
            a_ids = {r[0] for r in db.execute("SELECT record_id FROM procedure_items WHERE run_id=? AND step_id='write'", (a['run_id'],))}
            b_ids = {r[0] for r in db.execute("SELECT record_id FROM procedure_items WHERE run_id=? AND step_id='write'", (b['run_id'],))}
        self.assertTrue(a_ids.isdisjoint(b_ids))
        template = self.engine.memory.get(rid)['plan_json']
        self.assertNotIn(str(self.root), template)
        self.assertNotIn('rec_', template)

    def test_missing_role_blocks_writes(self):
        p = simple_plan(); p['required_roles'].append('amount')
        before = file_hash(self.file)
        self.assertEqual(self.engine.prepare(self.file, p)['status'], 'needs_mapping')
        self.assertEqual(file_hash(self.file), before)

    def test_ambiguous_alias_is_not_guessed(self):
        r = self.engine.memory.resolve(['price'], ['Price', '单价'])
        self.assertEqual(r['status'], 'needs_mapping')

    def test_changed_source_blocks_confirm(self):
        preview = self.engine.prepare(self.file, simple_plan())
        approve(self.bridge.store, preview)
        book = load_workbook(self.file); book.active['D2'] = 999; book.save(self.file); book.close()
        result = self.engine.resume(preview['run_id'], confirm=True)
        self.assertEqual(result['status'], 'blocked')
        self.assertEqual(self.values()[1][2], '未处理')

    def test_step_budget_persists_progress(self):
        bridge = ExcelBridge(replace(self.config, workflow=replace(self.config.workflow, steps_per_call=1)))
        engine = ProcedureEngine(bridge)
        preview = engine.prepare(self.file, simple_plan())
        approve(bridge.store, preview)
        first = engine.resume(preview['run_id'], confirm=True)
        self.assertEqual(first['steps_completed'], 1)
        engine.resume(preview['run_id'])
        self.assertEqual(engine.resume(preview['run_id'])['status'], 'completed')

    def test_six_steps_process_exit_does_not_repeat_arithmetic(self):
        p = {'ir_version': 1, 'name': 'Six step checkpoint', 'required_roles': ['price'], 'steps': []}
        for i in range(1, 7):
            p['steps'].append({'id': f's{i}', 'type': 'patch', 'role': 'price', 'operation': 'numeric_add', 'value': 1})
        preview = self.engine.prepare(self.file, p)
        approve(self.bridge.store, preview)
        env = {**os.environ, 'EXCEL_BRIDGE_WORKSPACE': str(self.root), 'EXCEL_BRIDGE_WEKNORA_ENABLED': 'false',
               'EXCEL_BRIDGE_PROCEDURE_ENABLED': 'true', 'EXCEL_BRIDGE_TEST_FAULTS': '1',
               'EXCEL_BRIDGE_FAIL_AT': 'PROCEDURE_AFTER_PATCH_4', 'PYTHONUTF8': '1'}
        child = subprocess.run([sys.executable, '-m', 'excel_bridge.workflow_cli', 'resume'],
                               input=json.dumps({'run_id': preview['run_id'], 'confirm': True}),
                               text=True, encoding='utf-8', capture_output=True, env=env, timeout=45)
        self.assertEqual(child.returncode, 86, child.stdout + child.stderr)
        self.assertEqual(self.values()[1][3], 6.95)
        result = ProcedureEngine(ExcelBridge(self.config)).resume(preview['run_id'])
        self.assertEqual(result['status'], 'completed', result)
        self.assertEqual(self.values()[1][3], 8.95)
        self.assertEqual(len(list(self.config.backup_dir.glob('*.xlsx'))), 6)

    def test_migration_v2_preserves_original_tables(self):
        self.bridge.excel_index({'file': str(self.file)})
        with self.bridge.store.connection() as db:
            rows = [tuple(r) for r in db.execute('SELECT * FROM records ORDER BY record_id')]
            db.execute('PRAGMA user_version=2')
        other = ExcelBridge(self.config)
        with other.store.connection() as db:
            self.assertEqual(db.execute('PRAGMA user_version').fetchone()[0], 4)
            self.assertEqual(rows, [tuple(r) for r in db.execute('SELECT * FROM records ORDER BY record_id')])

    def test_bounded_markdown_chunks(self):
        path = self.root / 'sop.md'
        path.write_text('\n'.join(f'规则{i}：说明文字。' for i in range(100)), encoding='utf-8')
        chunks = extract_document(path, 200)
        self.assertGreater(len(chunks), 2)
        self.assertEqual(sum(len(c) for c in chunks), 100)
        self.assertTrue(all(sum(len(p['text']) for p in c) <= 200 for c in chunks))

    def test_compiler_requires_paragraph_coverage(self):
        with self.assertRaises(PlanError):
            SopCompiler._validate_fragment({'steps': [], 'coverage': [], 'required_roles': []}, [{'paragraph': 0, 'text': '规则'}])

    def test_semantic_review_is_batched_and_never_assumes_recall_is_match(self):
        sizes=[]
        def complete(system,payload):
            sizes.append(len(payload['candidates']))
            return {'decisions':[{'index':c['index'],'match':'物流' in c['text']} for c in payload['candidates']]}, {}
        compiler=SopCompiler(self.bridge.store,self.config.workflow,complete)
        accepted=compiler.review_candidates('物流问题',['物流延迟','颜色问题']*10)
        self.assertEqual(accepted,list(range(0,20,2)))
        self.assertEqual(sizes,[8,8,4])

    def test_incomplete_semantic_review_blocks(self):
        compiler=SopCompiler(self.bridge.store,self.config.workflow,lambda *args: ({'decisions':[]},{}))
        with self.assertRaises(PlanError): compiler.review_candidates('物流问题',['尚未送达'])

    def test_unknown_run_id_explains_safe_first_call(self):
        result=self.bridge.procedure_run({'files':[str(self.file)],'run_id':'invented'})
        self.assertEqual(result['status'],'invalid_arguments')
        self.assertIn('只传 instruction 和 files', result['message'])

    def test_compiler_checkpoint_and_validation(self):
        from tests.test_rc4 import CompilerPassTests
        from excel_bridge.compiler import MultistageCompiler
        path = self.root / 'sop.txt'; path.write_text('把处理状态标为需要复核', encoding='utf-8')
        count = []
        def complete(stage, system, payload, schema):
            count.append(len(json.dumps(payload)))
            if stage in {'extract_check','coverage'}: return {'supported': True}, {'prompt_tokens': 100}
            if stage == 'extract':
                rule = CompilerPassTests.rule(self)
                return {'rules':[rule], 'descriptions':[], 'needs_review':[]}, {'prompt_tokens':100}
            return {'required_roles': ['review_status'], 'steps': [{'id': 's1', 'type': 'patch', 'role': 'review_status', 'operation': 'set', 'value': '需要复核'}],
                    'coverage': [{'paragraph': 0, 'kind': 'rule', 'steps': ['s1']}], 'needs_review': []}, {'prompt_tokens': 100}
        parser = SopCompiler(self.bridge.store, self.config.workflow)
        pid = parser.ingest(path)
        compiler = MultistageCompiler(self.bridge.store, self.config.workflow, complete)
        self.assertEqual(compiler.compile_next(pid)['status'], 'compiling')
        self.assertEqual(compiler.compile_next(pid)['status'], 'validated')
        compiler.compile_next(pid)
        self.assertEqual(len(count), 4)
        self.assertEqual(parser.ingest(path), pid)

    def test_docx_paragraph_and_table_order(self):
        from docx import Document
        path = self.root / 'sop.docx'
        doc = Document(); doc.add_heading('处理规则', 1)
        doc.add_paragraph('金额超过阈值进入人工复核。')
        table = doc.add_table(rows=1, cols=2)
        table.cell(0, 0).text = '阈值'; table.cell(0, 1).text = '5000'
        doc.add_paragraph('最后统计数量。'); doc.save(path)
        text = [p['text'] for c in extract_document(path) for p in c]
        self.assertEqual(text, ['处理规则', '金额超过阈值进入人工复核。', '阈值 | 5000', '最后统计数量。'])

    def test_branch_boundary_union_and_counts(self):
        p = {'ir_version':1,'name':'Boundary','required_roles':['price','review_status'], 'steps':[
            {'id':'b','type':'branch','condition':{'price':{'gt':5}},'then':'high','else':'low'},
            {'id':'high','type':'patch','source':'b.then','role':'review_status','operation':'set','value':'high'},
            {'id':'low','type':'patch','source':'b.else','role':'review_status','operation':'set','value':'ordinary'},
            {'id':'total','type':'aggregate','source':['high','low'],'metric':'count'}]}
        preview = self.engine.prepare(self.file, p)
        self.assertEqual(preview['steps'][0]['then_count'], 1)
        self.assertEqual(preview['steps'][-1]['value'], 3)
        approve(self.bridge.store, preview)
        self.engine.resume(preview['run_id'], confirm=True)
        self.assertEqual([r[2] for r in self.values()[1:]], ['ordinary','high','ordinary'])

    def test_recipe_failure_is_counted_once(self):
        rid = self.engine.memory.create(simple_plan())
        preview = self.engine.prepare(self.file, simple_plan(), recipe_id=rid)
        approve(self.bridge.store, preview)
        book = load_workbook(self.file); book.active['D2'] = 42; book.save(self.file); book.close()
        for _ in range(2): self.engine.resume(preview['run_id'], confirm=True)
        self.assertEqual(self.engine.memory.get(rid)['failure_count'], 1)

    def test_interrupted_write_cannot_hide_external_edit(self):
        p = simple_plan()
        preview = self.engine.prepare(self.file, p)
        approve(self.bridge.store, preview)
        env = {**os.environ, 'EXCEL_BRIDGE_WORKSPACE': str(self.root), 'EXCEL_BRIDGE_WEKNORA_ENABLED': 'false',
               'EXCEL_BRIDGE_PROCEDURE_ENABLED': 'true', 'EXCEL_BRIDGE_TEST_FAULTS': '1',
               'EXCEL_BRIDGE_FAIL_AT': 'PROCEDURE_AFTER_PATCH_2', 'PYTHONUTF8': '1'}
        child = subprocess.run([sys.executable, '-m', 'excel_bridge.workflow_cli', 'resume'],
                               input=json.dumps({'run_id':preview['run_id'],'confirm':True}),
                               text=True, encoding='utf-8', capture_output=True, env=env, timeout=45)
        self.assertEqual(child.returncode, 86, child.stdout + child.stderr)
        book = load_workbook(self.file); book.active['D3'] = 999; book.save(self.file); book.close()
        self.assertEqual(self.engine.resume(preview['run_id'])['status'], 'blocked')
        self.assertEqual(self.values()[2][3], 999)


class WorkflowRemoteTests(unittest.TestCase):
    def test_semantic_uses_file_kb_and_patch_outbox_converges(self):
        with tempfile.TemporaryDirectory() as temporary:
            mock = WorkspaceMock()
            try:
                root = Path(temporary); path = root / 'complaints.xlsx'; fixture(path)
                config = BridgeConfig(root, WeknoraConfig(base_url=mock.base_url, tenant_id='test', embedding_model_id='embedding', poll_interval=.001),
                                      OutboxConfig(retry_delays=(0,), lock_timeout=0), workflow=WorkflowConfig(procedure_enabled=True, recipe_enabled=True))
                bridge = ExcelBridge(config); engine = ProcedureEngine(bridge, semantic_reviewer=lambda query, texts: list(range(len(texts))))
                p = simple_plan(); p['steps'][0] = {'id': 'find', 'type': 'semantic_query', 'role': 'complaint_text', 'query': '物流'}
                preview = engine.prepare(path, p, source_type='sop')
                approve(bridge.store, preview)
                result = engine.resume(preview['run_id'], confirm=True)
                self.assertEqual(result['status'], 'completed', result)
                self.assertEqual(result['outbox']['pending'], 0)
                self.assertEqual(mock.creates, 1)
                self.assertGreater(mock.states[bridge.workspaces.get(str(path))['knowledge_base_id']].search_calls, 0)
                self.assertEqual(bridge.workspaces.get(str(path))['kb_status'], 'ready')
                engine.resume(preview['run_id'])
                with bridge.store.connection() as db:
                    recipes = db.execute('SELECT * FROM recipes').fetchall()
                    self.assertEqual(len(recipes), 1)
                    self.assertEqual((recipes[0]['source_type'],recipes[0]['status'],recipes[0]['success_count']), ('sop','draft',1))
                    template = db.execute('SELECT plan_json FROM recipe_versions').fetchone()[0]
                    self.assertNotIn(str(path), template)
                    self.assertNotIn('rec_', template)
                    self.assertIn('${write_value_', template)
            finally:
                mock.stop()
