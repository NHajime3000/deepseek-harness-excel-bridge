import json
import os
import subprocess
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from openpyxl import load_workbook
from excel_bridge import ExcelBridge
from excel_bridge.config import BridgeConfig, WeknoraConfig, OutboxConfig
from excel_bridge.workspace import WorkspaceError
from tests.test_bridge import create_workbook
from tests.workspace_mock import WorkspaceMock


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mock = WorkspaceMock()
        self.path = self.root / '新的销售表.xlsx'
        create_workbook(self.path, 3)
        self.config = BridgeConfig(self.root, WeknoraConfig(base_url=self.mock.base_url,
            tenant_id='one-tenant', embedding_model_id='one-embedding', poll_interval=.001),
            OutboxConfig(retry_delays=(0,), lock_timeout=0))
        self.bridge = ExcelBridge(self.config)

    def tearDown(self):
        self.mock.stop()
        self.temp.cleanup()

    def query(self, path=None, query='圣诞装饰品', **args):
        return self.bridge.excel_query({'file':str(path or self.path), 'query':query, **args})

    def mapping(self, path=None):
        return self.bridge.workspaces.get(str(path or self.path))

    def state(self, path=None):
        return self.mock.states[self.mapping(path)['knowledge_base_id']]

    def child(self, tool='excel_query', args=None, fault=None, maintenance=None):
        env = {**os.environ, 'PYTHONUTF8':'1', 'EXCEL_BRIDGE_WORKSPACE':str(self.root),
            'EXCEL_BRIDGE_WEKNORA_BASE_URL':self.mock.base_url, 'EXCEL_BRIDGE_WEKNORA_TENANT_ID':'one-tenant',
            'EXCEL_BRIDGE_EMBEDDING_MODEL_ID':'one-embedding', 'EXCEL_BRIDGE_WEKNORA_KNOWLEDGE_BASE_ID':'',
            'WEKNORA_KNOWLEDGE_BASE_ID':'', 'EXCEL_BRIDGE_WEKNORA_API_KEY':'', 'WEKNORA_API_KEY':'',
            'EXCEL_BRIDGE_OUTBOX_RETRY_DELAYS':'0', 'EXCEL_BRIDGE_OUTBOX_LOCK_TIMEOUT':'0',
            'EXCEL_BRIDGE_POLL_INTERVAL':'.001'}
        if fault:
            env.update(EXCEL_BRIDGE_TEST_FAULTS='1', EXCEL_BRIDGE_FAIL_AT=fault)
        cmd = [sys.executable, '-m', 'excel_bridge.maintenance', *maintenance] if maintenance else [sys.executable, '-m', 'excel_bridge.cli', tool]
        return subprocess.run(cmd, input=json.dumps(args or {'file':str(self.path), 'query':'圣诞'}),
            text=True, encoding='utf-8', capture_output=True, env=env, timeout=45)

    def test_A_new_query_creates_and_indexes(self):
        result = self.query()
        self.assertEqual(result['status'], 'ok', result)
        self.assertGreater(result['count'], 0)
        self.assertEqual(len(self.state().entries), 3)
        self.assertEqual(self.mapping()['kb_status'], 'ready')
        self.assertNotIn(self.mapping()['knowledge_base_id'], json.dumps(result))
        self.assertNotIn(str(self.root), self.mapping()['knowledge_base_name'])

    def test_B_repeat_three_queries_no_new_kb_or_embeddings(self):
        for _ in range(3):
            self.assertEqual(self.query()['status'], 'ok')
        self.assertEqual(self.mock.creates, 1)
        self.assertEqual(self.state().upsert_batches, [3])

    def test_C_fresh_process_reuses_binding(self):
        self.query()
        result = self.child()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['status'], 'ok')
        self.assertEqual(self.mock.creates, 1)

    def two_files(self):
        self.query()
        second = self.root / '其他.xlsx'
        create_workbook(second, 3)
        self.query(second)
        return second

    def test_D_two_file_isolation(self):
        second = self.two_files()
        a, b = self.query(), self.query(second)
        self.assertEqual(self.mock.creates, 2)
        self.assertNotEqual(self.mapping()['knowledge_base_id'], self.mapping(second)['knowledge_base_id'])
        self.assertTrue(set(x['record_id'] for x in a['matches']).isdisjoint(x['record_id'] for x in b['matches']))

    def test_E_patch_A_does_not_change_B(self):
        second = self.two_files()
        before = json.dumps(self.state(second).entries, sort_keys=True)
        record_id = self.query()['matches'][0]['record_id']
        patched = self.bridge.excel_patch({'file':str(self.path), 'operations':[
            {'record_id':record_id, 'column':'ReviewStatus', 'operation':'set', 'value':'待评估'}]})
        self.assertEqual(patched['modified'], 1)
        self.assertEqual(self.query(query='待评估')['count'], 1)
        self.assertEqual(json.dumps(self.state(second).entries, sort_keys=True), before)
        self.assertEqual(len(self.state().entries), 3)
        with self.bridge.store.connection() as connection:
            scopes = [json.loads(r[0])['scope']['kb_id'] for r in connection.execute('SELECT payload_json FROM outbox_tasks WHERE file_id=?', (self.mapping()['file_id'],))]
        self.assertEqual(set(scopes), {self.mapping()['knowledge_base_id']})

    def test_F_external_change_incremental_and_delete_row(self):
        self.query()
        book = load_workbook(self.path)
        book.active['C2'] = 'CHRISTMAS NEW DECORATION'
        book.save(self.path)
        book.close()
        self.assertEqual(self.query()['status'], 'ok')
        self.assertEqual(self.state().upsert_batches, [3, 1])
        book = load_workbook(self.path)
        book.active.delete_rows(3)
        book.save(self.path)
        book.close()
        self.query()
        self.assertEqual(len(self.state().entries), 2)
        self.assertEqual(self.mock.creates, 1)

    def test_G_actual_process_exit_after_KB_create_before_bind(self):
        crashed = self.child(fault='FAIL_AFTER_KB_CREATE')
        self.assertNotEqual(crashed.returncode, 0)
        self.assertEqual(self.mock.creates, 1)
        self.assertIsNone(self.mapping()['knowledge_base_id'])
        recovered = self.child()
        self.assertEqual(recovered.returncode, 0, recovered.stderr)
        self.assertEqual(json.loads(recovered.stdout)['status'], 'ok')
        self.assertEqual(self.mock.creates, 1)

    def test_H_CLI_delete_workspace_preserves_B_and_audit(self):
        second = self.two_files()
        kb = self.mapping()['knowledge_base_id']
        child = self.child(maintenance=['workspace-delete', '--file', str(self.path)])
        self.assertEqual(json.loads(child.stdout)['status'], 'deleted', child.stderr)
        self.assertNotIn(kb, self.mock.kbs)
        self.assertEqual(self.mapping()['kb_status'], 'deleted')
        self.assertEqual(self.query()['category'], 'deleted')
        self.assertEqual(self.query(second)['status'], 'ok')
        self.assertGreater(self.bridge.outbox.get_outbox_stats()['completed'], 0)

    def test_I_missing_file_orphaned_never_deletes_kb(self):
        self.query()
        self.path.unlink()
        report = self.bridge.workspaces.reconcile()
        self.assertEqual(report['workspaces'][0]['reason'], 'local_file_missing')
        self.assertEqual(self.mapping()['kb_status'], 'orphaned')
        self.assertEqual(len(self.mock.kbs), 1)

    def test_J_proven_move_preserves_record_ids_and_kb(self):
        before = self.query()
        mapping = dict(self.mapping())
        target = self.root / '移动后的表.xlsx'
        self.path.rename(target)
        self.bridge.workspaces.reconcile()
        self.bridge.workspaces.rebind(mapping['file_id'], str(target))
        after = self.query(target)
        self.assertEqual([x['record_id'] for x in before['matches']], [x['record_id'] for x in after['matches']])
        self.assertEqual(self.mapping(target)['knowledge_base_id'], mapping['knowledge_base_id'])
        self.assertEqual(self.state(target).upsert_batches, [3])

    def test_J_ambiguous_copy_rebind_blocked(self):
        self.query()
        other = self.root / '副本.xlsx'
        other.write_bytes(self.path.read_bytes())
        with self.assertRaises(WorkspaceError):
            self.bridge.workspaces.rebind(str(self.path), str(other))

    def test_K_offline_intent_then_resume(self):
        self.mock.stop()
        self.assertEqual(self.query()['status'], 'workspace_error')
        self.assertEqual(self.mapping()['phase'], 'prepared')
        self.mock.restart()
        self.assertEqual(self.query()['status'], 'ok')
        self.assertEqual(self.mock.creates, 1)

    def test_delete_failed_then_process_crash_recovery(self):
        self.query()
        self.mock.delete_status = 503
        self.assertEqual(self.bridge.workspaces.delete_workspace(str(self.path))['status'], 'deleting')
        self.assertIsNotNone(self.mapping()['knowledge_base_id'])
        self.mock.delete_status = 0
        result = self.child(maintenance=['workspace-delete', '--file', str(self.path)], fault='FAIL_AFTER_KB_DELETE')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(len(self.mock.kbs), 0)
        self.assertEqual(self.bridge.workspaces.delete_workspace(str(self.path))['status'], 'deleted')

    def test_config_change_does_not_reroute_tasks(self):
        self.query()
        other = ExcelBridge(replace(self.config, weknora=replace(self.config.weknora, tenant_id='other-tenant')))
        result = other.excel_query({'file':str(self.path), 'query':'圣诞'})
        self.assertEqual(result['category'], 'configuration')
        self.assertEqual(self.mock.creates, 1)
        self.assertEqual(self.state().upsert_batches, [3])

    def test_large_query_returns_explicit_state_without_creating_kb(self):
        create_workbook(self.path, 1001)
        self.assertEqual(self.query()['status'], 'indexing_required')
        self.assertEqual(self.mock.creates, 0)

    def test_ambiguous_creation_does_not_blindly_post_again(self):
        self.child(fault='FAIL_AFTER_KB_CREATE')
        kb = dict(next(iter(self.mock.kbs.values())))
        self.mock.kbs['duplicate'] = {**kb, 'id':'duplicate'}
        self.assertEqual(self.query()['category'], 'conflict')
        self.assertEqual(self.mock.creates, 1)

    def test_no_embedding_configuration_retains_intent(self):
        self.bridge = ExcelBridge(replace(self.config, weknora=replace(self.config.weknora, embedding_model_id=None)))
        self.assertEqual(self.query()['category'], 'configuration')
        self.assertEqual(self.mock.creates, 0)
        self.assertEqual(self.mapping()['kb_status'], 'error')

    def test_model_object_value_rejected_before_workbook_changes(self):
        match = self.query()['matches'][0]
        before = self.path.read_bytes()
        result = self.bridge.excel_patch({'file':str(self.path), 'operations':[{
            'record_id':match['record_id'], 'column':'ReviewStatus', 'operation':'set', 'value':{'待评估':True}}]})
        self.assertEqual(result['modified'], 0)
        self.assertEqual(result['status'], 'error')
        self.assertIn('string, number', result['failures'][0]['error'])
        self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual(self.state().upsert_batches, [3])

    def test_filter_expression_not_silently_used_as_semantic_query(self):
        self.query()
        calls = self.state().search_calls
        with self.assertRaisesRegex(ValueError, 'not a filter expression'):
            self.query(query="Country eq 'France'")
        self.assertEqual(self.state().search_calls, calls)
        self.assertEqual(self.query(query='', filters={'Country':'France'})['count'], 1)
