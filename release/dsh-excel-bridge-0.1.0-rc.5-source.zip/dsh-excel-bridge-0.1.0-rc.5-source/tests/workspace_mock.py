"""Tenant KB CRUD simulator, separate from the unchanged legacy FAQ mock."""
import json
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from tests.mock_weknora import MockState


class WorkspaceMock:
    def __init__(self):
        self.kbs, self.states = {}, {}
        self.creates = 0
        self.status = 0
        self.delete_status = 0
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass

            def body(self):
                return json.loads(self.rfile.read(int(self.headers.get('Content-Length', 0))) or b'{}')

            def send(self, status, data):
                raw = json.dumps({'success':status < 400, 'data':data}).encode()
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def dispatch(self):
                if owner.status:
                    return self.send(owner.status, {})
                path = urlsplit(self.path).path
                root = '/api/v1/knowledge-bases'
                if path == root:
                    if self.command == 'GET':
                        return self.send(200, list(owner.kbs.values()))
                    if self.command == 'POST':
                        body = self.body()
                        identity = str(uuid.uuid4())
                        owner.kbs[identity] = {**body, 'id':identity}
                        owner.states[identity] = MockState()
                        owner.creates += 1
                        return self.send(201, owner.kbs[identity])
                if path.startswith('/api/v1/faq/import/progress/'):
                    task_id = path.rsplit('/', 1)[1]
                    for state in owner.states.values():
                        if task_id in state.tasks:
                            return self.send(200, state.tasks[task_id])
                    return self.send(404, {})
                suffix = path.removeprefix(root + '/').split('/')
                kb_id = suffix[0]
                kb = owner.kbs.get(kb_id)
                if not kb:
                    return self.send(404, {})
                state = owner.states[kb_id]
                if len(suffix) == 1:
                    if self.command == 'DELETE':
                        if owner.delete_status:
                            return self.send(owner.delete_status, {})
                        del owner.kbs[kb_id]
                        return self.send(200, {})
                    return self.send(200, kb)
                if state.http_status:
                    return self.send(state.http_status, {})
                if suffix[1:] == ['faq', 'search']:
                    body = self.body()
                    return self.send(200, state.search(body['query_text'], body.get('match_count', 10)))
                if suffix[1:3] == ['faq', 'entries']:
                    if self.command == 'POST':
                        return self.send(200, {'task_id':state.upsert(self.body())})
                    if self.command == 'DELETE':
                        state.delete(self.body().get('ids', []))
                        return self.send(200, {})
                    if len(suffix) == 4:
                        entry = state.entries.get(int(suffix[3]))
                        return self.send(200 if entry else 404, entry or {})
                    query = parse_qs(urlsplit(self.path).query)
                    keyword = query.get('keyword', [''])[0]
                    entries = [e for e in state.entries.values() if not keyword or any(keyword in a for a in e['answers'])]
                    return self.send(200, {'data':entries[:int(query.get('page_size', [10])[0])], 'total':len(entries)})
                self.send(404, {})

            do_GET = do_POST = do_DELETE = dispatch

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.running = True

    @property
    def base_url(self):
        return f'http://127.0.0.1:{self.server.server_port}/api/v1'

    def stop(self):
        if self.running:
            self.server.shutdown()
            self.server.server_close()
            self.thread.join(3)
            self.running = False

    def restart(self):
        self.server = ThreadingHTTPServer(self.server.server_address, self.server.RequestHandlerClass)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.running = True
